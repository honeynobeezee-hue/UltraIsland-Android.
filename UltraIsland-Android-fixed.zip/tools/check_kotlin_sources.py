#!/usr/bin/env python3
"""Pemeriksaan statis cepat untuk sumber Kotlin Android (tanpa compiler).

Gagal (exit 1) bila menemukan: file .kt kosong, file tanpa `package`, package tidak sesuai folder,
atau import internal (com.ultraisland.pro.*) yang tidak punya deklarasi. Pemeriksaan ini TIDAK
menggantikan kompilasi Gradle; tujuannya memberi umpan balik cepat dan jelas.
"""
import collections, os, re, sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else "android/app/src/main/java"
EXTRA = sys.argv[2:]  # folder tambahan (mis. src/test/java) yang ikut sebagai "universe"
BASE = "com.ultraisland.pro"
GENERATED = {f"{BASE}.R", f"{BASE}.BuildConfig"}
DECL = re.compile(r'^\s*(?:@\w+(?:\([^)]*\))?\s*)*(?:(?:public|internal|private|data|sealed|enum|abstract|open|inline|value|annotation|const|lateinit|suspend|operator|infix|override)\s+)*(?:class|object|interface|typealias|fun|val|var)\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?(\w+)', re.M)

errors, decls, files = [], collections.defaultdict(set), []
for base in [ROOT] + EXTRA:
    for d, _, fs in os.walk(base):
        for f in fs:
            if f.endswith(".kt"):
                files.append((base, os.path.join(d, f)))
for base, p in files:
    rel = os.path.relpath(p, base)
    if os.path.getsize(p) == 0:
        errors.append(f"FILE KOSONG (0 byte): {rel}"); continue
    t = open(p, encoding="utf-8", errors="ignore").read()
    m = re.search(r"^package\s+([\w.]+)", t, re.M)
    if not m:
        errors.append(f"TIDAK ADA 'package': {rel}"); continue
    if base == ROOT and m.group(1) != ".".join(os.path.dirname(rel).split(os.sep)):
        errors.append(f"PACKAGE != FOLDER: {rel} -> {m.group(1)}")
    decls[m.group(1)].update(DECL.findall(t))
for base, p in files:
    if os.path.getsize(p) == 0:
        continue
    t = open(p, encoding="utf-8", errors="ignore").read()
    for imp in re.findall(r"^import\s+(com\.ultraisland\.pro\.[\w.]+)(?:\s+as\s+\w+)?\s*$", t, re.M):
        if imp in GENERATED:
            continue
        parts = imp.split(".")
        pk, name = ".".join(parts[:-1]), parts[-1]
        if name in decls.get(pk, ()):
            continue
        if len(parts) > 2 and parts[-2] in decls.get(".".join(parts[:-2]), ()):
            continue
        errors.append(f"IMPORT TIDAK TERSELESAIKAN: {imp}  (di {os.path.relpath(p, base)})")
print(f"Diperiksa {len(files)} file Kotlin.")
for e in errors:
    print("::error::" + e)
print("HASIL:", "GAGAL" if errors else "OK")
sys.exit(1 if errors else 0)
