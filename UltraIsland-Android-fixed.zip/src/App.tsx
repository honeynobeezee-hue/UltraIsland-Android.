import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Sliders, 
  Terminal, 
  Layers, 
  FileCode, 
  Sparkles, 
  Activity, 
  ChevronRight, 
  Info,
  CheckCircle,
  Play,
  Share2,
  ExternalLink,
  LayoutDashboard
} from 'lucide-react';
import { IslandSettings, IslandState, LiveActivity, LogEntry } from './types';
import { VirtualPhone } from './components/VirtualPhone';
import { SmartIslandStudio } from './components/SmartIslandStudio';
import { SmartIslandAppView } from './components/SmartIslandAppView';
import { TestFlightPanel } from './components/TestFlightPanel';
import { CodebaseExplorer } from './components/CodebaseExplorer';
import { DiagnosticsLogView } from './components/DiagnosticsLogView';

const DEFAULT_SETTINGS: IslandSettings = {
  enabled: true,
  overlayEngine: 'ACCESSIBILITY_OVERLAY',
  displayMode: 'CUTOUT_MERGE',
  mergeStyle: 'MERGE',
  cutoutHoleShape: 'CENTER_HOLE',
  cutoutWidth: 105,
  cutoutHeight: 34,
  centreXOffset: 0,
  topYOffset: 11,
  cornerRadius: 22,
  minClosedWidth: 100,
  marginHorizontal: 16,
  animationStyle: 'IOS_SPRING',
  animationSpeedMultiplier: 1.0,
  hapticEnabled: true,
  hapticIntensity: 2,
  showGlowFlash: true,
  showOutlineBorder: true,
  ambientShadow: true,
  glassmorphicBlur: false,
  dynamicAlbumColor: true,
  autoHideWhenIdle: false,
  hideInFullscreen: true,
  showOnLockscreen: true,
  autoExpandNewNotification: true,
  antiSpamCooldownSeconds: 30,

  // Phase 6A Defaults
  backgroundOpacity: 0.95,
  backgroundBlurRadius: 16,
  cardBlurEnabled: true,
  albumBackdropBlur: true,
  colorTheme: 'NOIR_OLED',
  gradientEnabled: false,
  gradientSecondColorHex: '#8A2BE2',
  ambientDropShadow: true,
  ledColorHex: '#00FF66',
  perActivityTextScale: 1.0,
  perActivityCornerRadius: 24,
  alternateByOrientation: false,
  landscapeCutoutWidth: 120,
  landscapeCutoutHeight: 34,
  landscapeTopYOffset: 8,
  activePresetName: 'iPhone 15 Pro',
  fontOption: 'SYSTEM',
  mixFonts: false,
  showHourTick: true,
  clockFormatStyle: 'HH:mm',
  springDamping: 0.72,
  springStiffness: 380,
  speedMultiplierPortrait: 1.0,
  speedMultiplierLandscape: 1.0
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'app_ui' | 'studio' | 'testflight' | 'code' | 'logs' | 'roadmap'>('simulator');
  const [settings, setSettings] = useState<IslandSettings>(DEFAULT_SETTINGS);
  const [activeActivities, setActiveActivities] = useState<LiveActivity[]>([]);
  const [isExpandedByUser, setIsExpandedByUser] = useState<boolean>(false);
  const [isFullScreenCard, setIsFullScreenCard] = useState<boolean>(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);

  // Add Log Helper
  const addLog = (level: 'DEBUG' | 'INFO' | 'WARN' | 'ERROR', tag: string, message: string) => {
    const entry: LogEntry = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
      level,
      tag,
      message
    };
    setLogs(prev => [entry, ...prev.slice(0, 499)]);
  };

  // Initial startup log
  useEffect(() => {
    addLog('INFO', 'UltraIslandApp', 'UltraIsland Pro initialized (Phase 0 & 1 Engine Active)');
    addLog('INFO', 'AccessibilityService', 'Connected to TYPE_ACCESSIBILITY_OVERLAY host');
    addLog('INFO', 'CutoutDetector', 'DisplayCutout detected: Center Hole bounds (105x34dp at top 11dp)');
    addLog('INFO', 'ShizukuBridge', 'Shizuku IPC binder attached (v13.1.5)');
  }, []);

  // Compute Current State Machine State based on Activities and User Interaction
  const getCurrentState = (): IslandState => {
    if (!settings.enabled) return { type: 'HIDDEN' };

    const sorted = [...activeActivities].sort((a, b) => {
      const prio: Record<string, number> = {
        CALL: 7,
        NAVIGATION: 6,
        QUICK_LAUNCHER: 5.8,
        TIMER: 5,
        RIDE: 4.8,
        MEDIA: 4,
        NOTIFICATION: 3,
        CHARGING: 2,
        WEATHER: 1.5,
        CALENDAR: 1.2,
        IDLE_WIDGET: 1
      };
      const pDiff = (prio[b.type] || 0) - (prio[a.type] || 0);
      return pDiff !== 0 ? pDiff : b.timestamp - a.timestamp;
    });

    if (sorted.length === 0) {
      return { type: 'IDLE' };
    }

    if (isFullScreenCard) {
      return { type: 'FULLSCREEN', activity: sorted[0] };
    }

    if (isExpandedByUser) {
      return { type: 'EXPANDED', activity: sorted[0] };
    }

    if (sorted.length === 1) {
      return { type: 'COMPACT', activity: sorted[0] };
    }

    // Two or more activities -> Dual Mode
    return { type: 'DUAL', primary: sorted[0], secondary: sorted[1] };
  };

  const currentState = getCurrentState();

  // Handlers
  const handleAddActivity = (activity: LiveActivity, autoExpand: boolean = false) => {
    addLog('INFO', 'StateMachine', `Activity posted: ${activity.title} (${activity.type})`);
    setActiveActivities(prev => {
      const filtered = prev.filter(a => a.id !== activity.id);
      return [activity, ...filtered];
    });

    if (autoExpand) {
      setIsExpandedByUser(true);
      addLog('DEBUG', 'StateMachine', `Auto-expanded card for: ${activity.title}`);
    }
  };

  const handleRemoveActivity = (id: string) => {
    const act = activeActivities.find(a => a.id === id);
    if (act) {
      addLog('INFO', 'StateMachine', `Activity removed: ${act.title}`);
    }
    setActiveActivities(prev => prev.filter(a => a.id !== id));
    setIsExpandedByUser(false);
    setIsFullScreenCard(false);
  };

  const handleClearAll = () => {
    addLog('INFO', 'StateMachine', 'Cleared all active activities -> Return to IDLE pill');
    setActiveActivities([]);
    setIsExpandedByUser(false);
    setIsFullScreenCard(false);
  };

  const handleSwapDual = () => {
    if (activeActivities.length >= 2) {
      addLog('DEBUG', 'StateMachine', 'Swapped primary & secondary activities in dual mode');
      setActiveActivities(prev => [prev[1], prev[0], ...prev.slice(2)]);
    }
  };

  const handleToggleExpand = () => {
    if (isExpandedByUser) {
      addLog('DEBUG', 'StateMachine', 'Collapsed expanded card to pill');
      setIsExpandedByUser(false);
      setIsFullScreenCard(false);
    } else {
      if (activeActivities.length > 0) {
        addLog('DEBUG', 'StateMachine', 'User expanded island to card');
        setIsExpandedByUser(true);
      } else {
        // Idle expansion demo
        handleAddActivity({
          id: 'demo_media',
          type: 'MEDIA',
          title: 'Midnight Reverie',
          subtitle: 'Original Soundscapes • Synthwave',
          accentColorHex: '#E0245E',
          iconType: 'media',
          timestamp: Date.now(),
          progress: 0.42
        }, true);
      }
    }
  };

  const handleQuickTest = (type: 'call' | 'music' | 'timer' | 'notif' | 'charging') => {
    switch (type) {
      case 'call':
        handleAddActivity({
          id: 'call_test',
          type: 'CALL',
          title: 'Incoming Call',
          subtitle: 'Jane Doe (+1 555-0199)',
          accentColorHex: '#34C759',
          iconType: 'call',
          timestamp: Date.now()
        }, true);
        break;
      case 'music':
        handleAddActivity({
          id: 'music_test',
          type: 'MEDIA',
          title: 'Midnight Reverie',
          subtitle: 'Original Soundscapes • Synthwave',
          accentColorHex: '#E0245E',
          iconType: 'media',
          timestamp: Date.now(),
          progress: 0.55
        }, false);
        break;
      case 'timer':
        handleAddActivity({
          id: 'timer_test',
          type: 'TIMER',
          title: 'Kitchen Timer',
          subtitle: '04:59 remaining',
          accentColorHex: '#FF9500',
          iconType: 'timer',
          timestamp: Date.now()
        }, false);
        break;
      case 'notif':
        handleAddActivity({
          id: `notif_${Date.now()}`,
          type: 'NOTIFICATION',
          title: 'Chat • Alex',
          subtitle: 'UltraIsland Pro looks insane!',
          accentColorHex: '#388AF6',
          iconType: 'notification',
          timestamp: Date.now()
        }, settings.autoExpandNewNotification);
        break;
      case 'charging':
        handleAddActivity({
          id: 'charging_test',
          type: 'CHARGING',
          title: 'Super Fast Charging',
          subtitle: '85% • 12m to full',
          accentColorHex: '#FFD600',
          iconType: 'charging',
          timestamp: Date.now()
        }, false);
        break;
    }
  };

  return (
    <div className="min-h-screen bg-[#07080a] text-zinc-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Navbar */}
      <header className="sticky top-0 z-50 bg-[#0c0e12]/95 backdrop-blur-md border-b border-zinc-800/80 px-4 lg:px-8 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-black text-sm tracking-tight text-white">UltraIsland Pro</span>
                <span className="text-[10px] px-1.5 py-0.2 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded font-mono font-semibold">
                  v1.0.0
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 hidden sm:block">Dynamic Island for Android • SmartIsland Superset</p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center space-x-1 overflow-x-auto bg-zinc-900/80 p-1 rounded-2xl border border-zinc-800">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition ${
                activeTab === 'simulator' 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Simulator</span>
            </button>

            <button
              onClick={() => setActiveTab('app_ui')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition ${
                activeTab === 'app_ui' 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>SmartIsland App UI</span>
            </button>

            <button
              onClick={() => setActiveTab('studio')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition ${
                activeTab === 'studio' 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Settings Studio</span>
            </button>

            <button
              onClick={() => setActiveTab('testflight')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition ${
                activeTab === 'testflight' 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Test Flight</span>
              {activeActivities.length > 0 && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse ml-0.5" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition ${
                activeTab === 'code' 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Android Code</span>
            </button>

            <button
              onClick={() => setActiveTab('logs')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition ${
                activeTab === 'logs' 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Logs</span>
              {logs.length > 0 && (
                <span className="text-[10px] text-zinc-500 font-mono ml-0.5">({logs.length})</span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('roadmap')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition ${
                activeTab === 'roadmap' 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Matrix & Parity</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 lg:p-8">
        
        {/* TAB 1: SIMULATOR & INTERACTIVE DEVICE */}
        {activeTab === 'simulator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Phone Display (5 cols) */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <VirtualPhone
                settings={settings}
                state={currentState}
                onExpand={handleToggleExpand}
                onCollapse={() => {
                  setIsExpandedByUser(false);
                  setIsFullScreenCard(false);
                }}
                onSwapDual={handleSwapDual}
                onUpdateSettings={setSettings}
                onTriggerBroadcast={(act) => handleAddActivity(act, true)}
                onAction={(action) => {
                  addLog('INFO', 'UserInteraction', `Card action triggered: ${action}`);
                  if (action === 'decline' || action === 'answer') {
                    handleRemoveActivity('call_test');
                  }
                }}
              />
            </div>

            {/* Live Controller Dashboard (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Quick Status Banner */}
              <div className="p-5 rounded-2xl bg-zinc-900/70 border border-zinc-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                    <span className="text-xs font-mono font-bold text-white uppercase">
                      Current State: <span className="text-blue-400">{currentState.type}</span>
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400 mt-1">
                    Tap the dynamic island on the phone screen to expand or collapse.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleToggleExpand}
                    className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition shadow-md"
                  >
                    {isExpandedByUser ? 'Collapse to Pill' : 'Expand Card'}
                  </button>
                  {activeActivities.length > 0 && (
                    <button
                      onClick={handleClearAll}
                      className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold transition"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>

              {/* Quick Trigger Bar */}
              <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-300 uppercase tracking-wider">Instant Activity Triggers</span>
                  <span className="text-[11px] text-zinc-500">Add to priority queue</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  <button
                    onClick={() => handleQuickTest('call')}
                    className="p-3 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-500/30 text-left transition"
                  >
                    <div className="text-xs font-bold text-emerald-400">Incoming Call</div>
                    <div className="text-[10px] text-zinc-400">Priority 7 (Preempts all)</div>
                  </button>

                  <button
                    onClick={() => handleQuickTest('music')}
                    className="p-3 rounded-xl bg-pink-950/40 hover:bg-pink-900/50 border border-pink-500/30 text-left transition"
                  >
                    <div className="text-xs font-bold text-pink-400">Media Player</div>
                    <div className="text-[10px] text-zinc-400">Audio wave + controls</div>
                  </button>

                  <button
                    onClick={() => handleQuickTest('timer')}
                    className="p-3 rounded-xl bg-amber-950/40 hover:bg-amber-900/50 border border-amber-500/30 text-left transition"
                  >
                    <div className="text-xs font-bold text-amber-400">Timer 04:59</div>
                    <div className="text-[10px] text-zinc-400">Priority 5</div>
                  </button>

                  <button
                    onClick={() => handleQuickTest('notif')}
                    className="p-3 rounded-xl bg-blue-950/40 hover:bg-blue-900/50 border border-blue-500/30 text-left transition"
                  >
                    <div className="text-xs font-bold text-blue-400">Chat Ping</div>
                    <div className="text-[10px] text-zinc-400">Auto-expand notification</div>
                  </button>

                  <button
                    onClick={() => handleQuickTest('charging')}
                    className="p-3 rounded-xl bg-yellow-950/40 hover:bg-yellow-900/50 border border-yellow-500/30 text-left transition"
                  >
                    <div className="text-xs font-bold text-yellow-400">Fast Charge 67W</div>
                    <div className="text-[10px] text-zinc-400">Battery status pill</div>
                  </button>

                  <button
                    onClick={() => {
                      handleQuickTest('call');
                      handleQuickTest('music');
                    }}
                    className="p-3 rounded-xl bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/30 text-left transition"
                  >
                    <div className="text-xs font-bold text-purple-400">Dual Mode Test</div>
                    <div className="text-[10px] text-zinc-400">Split pill + bubble</div>
                  </button>
                </div>
              </div>

              {/* Quick Cutout Controls on Simulator View */}
              <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-300 uppercase tracking-wider">Quick Geometry Calibration</span>
                  <button
                    onClick={() => setActiveTab('studio')}
                    className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center space-x-1"
                  >
                    <span>Full Studio</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <div className="flex justify-between mb-1 text-zinc-400">
                      <span>Cutout Width</span>
                      <span className="text-blue-400 font-mono font-bold">{settings.cutoutWidth} dp</span>
                    </div>
                    <input 
                      type="range" min={70} max={200} value={settings.cutoutWidth}
                      onChange={e => setSettings(s => ({ ...s, cutoutWidth: Number(e.target.value) }))}
                      className="w-full accent-blue-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between mb-1 text-zinc-400">
                      <span>Cutout Height</span>
                      <span className="text-blue-400 font-mono font-bold">{settings.cutoutHeight} dp</span>
                    </div>
                    <input 
                      type="range" min={24} max={50} value={settings.cutoutHeight}
                      onChange={e => setSettings(s => ({ ...s, cutoutHeight: Number(e.target.value) }))}
                      className="w-full accent-blue-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between mb-1 text-zinc-400">
                      <span>Centre X Offset</span>
                      <span className="text-blue-400 font-mono font-bold">{settings.centreXOffset} dp</span>
                    </div>
                    <input 
                      type="range" min={-100} max={100} value={settings.centreXOffset}
                      onChange={e => setSettings(s => ({ ...s, centreXOffset: Number(e.target.value) }))}
                      className="w-full accent-blue-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between mb-1 text-zinc-400">
                      <span>Top Y Position</span>
                      <span className="text-blue-400 font-mono font-bold">{settings.topYOffset} dp</span>
                    </div>
                    <input 
                      type="range" min={0} max={40} value={settings.topYOffset}
                      onChange={e => setSettings(s => ({ ...s, topYOffset: Number(e.target.value) }))}
                      className="w-full accent-blue-500 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Engine Architecture Highlights */}
              <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 text-xs text-zinc-400 space-y-2">
                <div className="font-bold text-white flex items-center space-x-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Phase 0 & 1 Verification Status: GREEN</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 text-[11px]">
                  <div className="p-2 rounded-lg bg-zinc-900 border border-zinc-800">
                    <div className="font-semibold text-zinc-300">Accessibility Service</div>
                    <div className="text-emerald-400">TYPE_ACCESSIBILITY_OVERLAY</div>
                  </div>
                  <div className="p-2 rounded-lg bg-zinc-900 border border-zinc-800">
                    <div className="font-semibold text-zinc-300">Spring Physics</div>
                    <div className="text-purple-400">Damping 0.72 • Stiffness 380</div>
                  </div>
                  <div className="p-2 rounded-lg bg-zinc-900 border border-zinc-800">
                    <div className="font-semibold text-zinc-300">Cutout Detection</div>
                    <div className="text-blue-400">DisplayCutout insets</div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB: SMARTISLAND ANDROID APP UI (MATERIAL 3) */}
        {activeTab === 'app_ui' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="border-b border-zinc-800 pb-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <span>SmartIsland Android App Interface</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 font-semibold border border-blue-500/30">
                    Jetpack Compose Material 3
                  </span>
                </h2>
                <p className="text-xs text-zinc-400 mt-1">
                  Antarmuka aplikasi Android lengkap dengan kartu Wireless ADB, System Settings Restorer, 10 QS Tiles, dan Broadcast API.
                </p>
              </div>

              <button
                onClick={() => setActiveTab('simulator')}
                className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 transition self-start sm:self-auto"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Lihat di Simulator Phone</span>
              </button>
            </div>

            <SmartIslandAppView
              settings={settings}
              onUpdateSettings={setSettings}
              onTriggerBroadcast={(act) => {
                handleAddActivity(act, true);
                setActiveTab('simulator');
              }}
              compactMode={false}
            />
          </div>
        )}

        {/* TAB 2: SMARTISLAND SETTINGS STUDIO */}
        {activeTab === 'studio' && (
          <SmartIslandStudio
            settings={settings}
            onUpdateSettings={(updater) => setSettings(updater)}
            onTriggerTest={handleQuickTest}
            onResetSettings={() => setSettings(DEFAULT_SETTINGS)}
          />
        )}

        {/* TAB 3: TEST FLIGHT MATRIX */}
        {activeTab === 'testflight' && (
          <TestFlightPanel
            currentState={currentState}
            activeActivities={activeActivities}
            onAddActivity={handleAddActivity}
            onRemoveActivity={handleRemoveActivity}
            onClearAll={handleClearAll}
            onSwapDual={handleSwapDual}
            onToggleExpand={handleToggleExpand}
          />
        )}

        {/* TAB 4: ANDROID SOURCE CODE EXPLORER */}
        {activeTab === 'code' && (
          <CodebaseExplorer />
        )}

        {/* TAB 5: RING BUFFER DIAGNOSTICS LOGS */}
        {activeTab === 'logs' && (
          <DiagnosticsLogView
            logs={logs}
            onClearLogs={() => setLogs([])}
          />
        )}

        {/* TAB 6: ROADMAP & PARITY MATRIX */}
        {activeTab === 'roadmap' && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="border-b border-zinc-800 pb-4">
              <h2 className="text-xl font-bold text-white">Feature Parity Matrix & Roadmap Status</h2>
              <p className="text-xs text-zinc-400 mt-1">
                Superset tracking combining SmartIsland (S), Island (I), Islandify (Y), OmniLand (O), ExpressiveCutout (E), and Tooler (T).
              </p>
            </div>

            {/* Phase completion summary */}
            <div className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white">Project Status: 100% Production Ready (Phases 0–7 Complete)</span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-xs font-bold flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" /> Verified & Shipped
                </span>
              </div>
              <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                <div className="w-full h-full bg-emerald-500 rounded-full" />
              </div>
              <div className="text-xs text-zinc-400">
                All 8 architectural phases (Phase 0 Foundation, Phase 1 Overlay & Physics, Phase 2 Notifications & Heads-Up, Phase 3 Media & Timer, Phase 4 Battery & Connectivity, Phase 5 Navigation & Weather, Phase 6 Studio Settings, and Phase 7 Tools/API/Privileged System Control) are fully implemented in native Kotlin Jetpack Compose and verified.
              </div>
            </div>

            {/* Matrix Table */}
            <div className="rounded-2xl bg-zinc-900 border border-zinc-800 overflow-hidden text-xs">
              <div className="p-4 bg-zinc-800/60 font-bold text-white flex justify-between">
                <span>Feature / Capability</span>
                <span>Status & Source</span>
              </div>
              <div className="divide-y divide-zinc-800 text-zinc-300">
                {[
                  { name: 'Overlay AccessibilityService + TYPE_ACCESSIBILITY_OVERLAY', source: 'S, I, Y, O, E', status: 'Completed (Fase 1)' },
                  { name: 'Overlay SYSTEM_ALERT_WINDOW fallback + FGS specialUse', source: 'S, I, Y, O, E', status: 'Completed (Fase 1)' },
                  { name: 'Hardware Cutout Detection (DisplayCutout insets)', source: 'S, E', status: 'Completed (Fase 1)' },
                  { name: 'Cutout Geometry Calibration (X/Y/W/H/Radius/Margin)', source: 'S, E', status: 'Completed (Fase 1)' },
                  { name: 'Presets: Center Hole, Wide Island, Separate, Floating', source: 'S, O', status: 'Completed (Fase 1)' },
                  { name: 'State Machine: Hidden > Idle > Compact > Dual > Expanded', source: 'S, Y, E', status: 'Completed (Fase 1)' },
                  { name: 'Priority Queue (Call > Nav > Timer > Media > Notif > Charge)', source: 'S, Y', status: 'Completed (Fase 1)' },
                  { name: 'Dual Mode split pill & swipe-to-swap gesture', source: 'S, Y', status: 'Completed (Fase 1)' },
                  { name: 'iOS Spring Physics (Damping 0.72, Stiffness 380)', source: 'E, S, O', status: 'Completed (Fase 1)' },
                  { name: 'Glow Flash, Outline Border, Ambient Shadow', source: 'Y, S', status: 'Completed (Fase 1)' },
                  { name: 'SmartIsland Studio UI layout & Live Preview on Top', source: 'S', status: 'Completed (Fase 6)' },
                  { name: 'Shizuku API integration & Privileged Shell Runner', source: 'S, E, T', status: 'Completed (Fase 0 & 7)' },
                  { name: 'Notification Listener + Quick Reply / Dismiss', source: 'All', status: 'Completed (Fase 2)' },
                  { name: 'Media Controls + Live Soundwave Visualizer', source: 'Y, O, S', status: 'Completed (Fase 3)' },
                  { name: 'System Activities (Charging, Bluetooth, WiFi, Hotspot, DND)', source: 'Y, S, E', status: 'Completed (Fase 4)' },
                  { name: 'Navigation & Ride Tracking (Maps, Waze, Uber, Turn-by-Turn)', source: 'Y, S', status: 'Completed (Fase 5)' },
                  { name: 'Wireless ADB Wizard & Pairing Tool', source: 'T', status: 'Completed (Fase 7)' },
                  { name: 'System Settings Restorer (Heads-Up, Daltonizer, DNS)', source: 'T', status: 'Completed (Fase 7)' },
                  { name: 'Public Live Activity API & Tasker/MacroDroid Intent Receiver', source: 'S, Y', status: 'Completed (Fase 7)' },
                  { name: '10-Slot Quick Settings Tile Customization Matrix', source: 'T, S', status: 'Completed (Fase 7)' }
                ].map((row, i) => (
                  <div key={i} className="p-3.5 flex items-center justify-between hover:bg-zinc-800/30 transition">
                    <div>
                      <div className="font-medium text-white">{row.name}</div>
                      <div className="text-[11px] text-zinc-500">Origin: {row.source}</div>
                    </div>
                    <span className="text-[11px] px-2 py-0.5 rounded font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                      {row.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/80 py-4 px-6 text-center text-xs text-zinc-500 bg-[#090b0e]">
        UltraIsland Studio Pro • Next-Generation Dynamic Island Engine for Android 8–16 • 100% Shipped & Verified
      </footer>
    </div>
  );
}
