export type DisplayMode = 'CUTOUT_MERGE' | 'FLOATING';

export type MergeStyle = 'MERGE' | 'SEPARATE' | 'WIDE' | 'CENTER_HOLE';

export type AnimationStyle = 
  | 'IOS_SPRING'
  | 'MATERIAL_EXPRESSIVE'
  | 'BOUNCY'
  | 'SMOOTH_LINEAR'
  | 'MINIMAL'
  | 'INSTANT';

export type OverlayEngine = 'ACCESSIBILITY_OVERLAY' | 'SYSTEM_ALERT_WINDOW';

export type CutoutHoleShape = 'CENTER_HOLE' | 'PILL_HOLE' | 'LEFT_PUNCH' | 'WATERDROP' | 'NONE';

export interface IslandSettings {
  enabled: boolean;
  overlayEngine: OverlayEngine;
  displayMode: DisplayMode;
  mergeStyle: MergeStyle;
  cutoutHoleShape: CutoutHoleShape;

  // Geometry (dp)
  cutoutWidth: number;
  cutoutHeight: number;
  centreXOffset: number;
  topYOffset: number;
  cornerRadius: number;
  minClosedWidth: number;
  marginHorizontal: number;

  // Phase 6A: Appearance & Opacity
  backgroundOpacity?: number;
  backgroundBlurRadius?: number;
  cardBlurEnabled?: boolean;
  albumBackdropBlur?: boolean;
  colorTheme?: 'NOIR_OLED' | 'DARK_GREY' | 'MATERIAL_YOU_DYNAMIC' | 'IOS_MINIMAL' | 'NEON_CYAN';
  gradientEnabled?: boolean;
  gradientSecondColorHex?: string;
  ambientDropShadow?: boolean;
  ledColorHex?: string;
  perActivityTextScale?: number;
  perActivityCornerRadius?: number;

  // Phase 6A: Layout & Orientation
  alternateByOrientation?: boolean;
  landscapeCutoutWidth?: number;
  landscapeCutoutHeight?: number;
  landscapeTopYOffset?: number;
  activePresetName?: string;

  // Phase 6A: Fonts & Clock
  fontOption?: 'SYSTEM' | 'LED_DOT_5X7' | 'MONOSPACE' | 'SERIF' | 'CUSTOM';
  mixFonts?: boolean;
  showHourTick?: boolean;
  clockFormatStyle?: string;

  // Phase 6A: Animations & Spring Physics
  springDamping?: number;
  springStiffness?: number;
  speedMultiplierPortrait?: number;
  speedMultiplierLandscape?: number;

  // Animation
  animationStyle: AnimationStyle;
  animationSpeedMultiplier: number;
  hapticEnabled: boolean;
  hapticIntensity: number;

  // Visual
  showGlowFlash: boolean;
  showOutlineBorder: boolean;
  ambientShadow: boolean;
  glassmorphicBlur: boolean;
  dynamicAlbumColor: boolean;

  // Behavior
  autoHideWhenIdle: boolean;
  hideInFullscreen: boolean;
  showOnLockscreen: boolean;
  autoExpandNewNotification: boolean;
  antiSpamCooldownSeconds: number;
}

export type ActivityType = 
  | 'CALL'
  | 'NAVIGATION'
  | 'RIDE'
  | 'WEATHER'
  | 'CALENDAR'
  | 'QUICK_LAUNCHER'
  | 'TIMER'
  | 'MEDIA'
  | 'NOTIFICATION'
  | 'CHARGING'
  | 'IDLE_WIDGET';

export interface LiveActivity {
  id: string;
  type: ActivityType;
  title: string;
  subtitle: string;
  accentColorHex: string;
  iconType: string;
  timestamp: number;
  durationSeconds?: number;
  progress?: number;
  isOngoing?: boolean;
}

export type IslandState = 
  | { type: 'HIDDEN' }
  | { type: 'IDLE'; isSplitPill?: boolean; widgetText?: string; widgetSubtext?: string }
  | { type: 'COMPACT'; activity: LiveActivity }
  | { type: 'DUAL'; primary: LiveActivity; secondary: LiveActivity }
  | { type: 'EXPANDED'; activity: LiveActivity }
  | { type: 'FULLSCREEN'; activity: LiveActivity };

export interface LogEntry {
  id: string;
  timestamp: number;
  level: 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';
  tag: string;
  message: string;
}

export interface AndroidCodeFile {
  path: string;
  title: string;
  module: 'root' | 'app' | 'core' | 'engine' | 'services' | 'privileged' | 'ui' | 'test';
  language: 'kotlin' | 'xml' | 'groovy' | 'toml';
  description: string;
  content: string;
}
