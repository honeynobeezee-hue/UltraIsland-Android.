import { AndroidCodeFile } from '../types';

export const ANDROID_FILES: AndroidCodeFile[] = [
  {
    path: 'gradle.properties',
    title: 'gradle.properties',
    module: 'root',
    language: 'groovy',
    description: 'Gradle JVM and AndroidX configuration.',
    content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official`
  },
  {
    path: 'settings.gradle.kts',
    title: 'settings.gradle.kts',
    module: 'root',
    language: 'kotlin',
    description: 'Root project settings and repository resolution rules.',
    content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "UltraIslandPro"
include(":app")`
  },
  {
    path: 'build.gradle.kts',
    title: 'build.gradle.kts (root)',
    module: 'root',
    language: 'kotlin',
    description: 'Root build script with AGP 8.6.1 and Kotlin 2.0.20.',
    content: `plugins {
    id("com.android.application") version "8.6.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}`
  },
  {
    path: 'app/build.gradle.kts',
    title: 'app/build.gradle.kts',
    module: 'app',
    language: 'kotlin',
    description: 'Single-module app build config with Compose BOM 2024.09.00 and Shizuku 13.1.5.',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.ultraisland.pro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ultraisland.pro"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.activity:activity-compose:1.9.2")

    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
}`
  },
  {
    path: 'app/proguard-rules.pro',
    title: 'proguard-rules.pro',
    module: 'app',
    language: 'groovy',
    description: 'ProGuard keep rules for Shizuku.',
    content: `-keep class dev.rikka.shizuku.** { *; }
-dontwarn dev.rikka.shizuku.**`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    title: 'AndroidManifest.xml',
    module: 'app',
    language: 'xml',
    description: 'Complete manifest declaring IslandAccessibilityService, MainActivity, and ShizukuProvider.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:name=".UltraIslandApp"
        android:allowBackup="true"
        android:icon="@android:drawable/sym_def_app_icon"
        android:label="@string/app_name"
        android:roundIcon="@android:drawable/sym_def_app_icon"
        android:supportsRtl="true"
        android:theme="@style/Theme.UltraIsland">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:theme="@style/Theme.UltraIsland">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".services.accessibility.IslandAccessibilityService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

        <provider
            android:name="rikka.shizuku.ShizukuProvider"
            android:authorities="\${applicationId}.shizuku"
            android:multiprocess="false"
            android:enabled="true"
            android:exported="true"
            android:permission="android.permission.INTERACT_ACROSS_USERS_FULL" />

    </application>

</manifest>`
  },
  {
    path: 'app/src/main/res/xml/accessibility_service_config.xml',
    title: 'accessibility_service_config.xml',
    module: 'services',
    language: 'xml',
    description: 'Accessibility Service XML configuration for full screen overlay capability.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeWindowStateChanged|typeWindowContentChanged"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:accessibilityFlags="flagDefault|flagRetrieveInteractiveWindows|flagIncludeNotImportantViews|flagRequestTouchExplorationMode"
    android:canRetrieveWindowContent="true"
    android:canRequestTouchExplorationMode="false"
    android:description="@string/accessibility_service_description"
    android:notificationTimeout="50"
    android:settingsActivity="com.ultraisland.pro.MainActivity" />`
  },
  {
    path: 'app/src/main/res/values/strings.xml',
    title: 'strings.xml',
    module: 'app',
    language: 'xml',
    description: 'String resources for app and accessibility service.',
    content: `<resources>
    <string name="app_name">UltraIsland Pro</string>
    <string name="accessibility_service_description">UltraIsland Pro uses Accessibility Service to render the seamless Dynamic Island overlay over status bar and lockscreen.</string>
</resources>`
  },
  {
    path: 'app/src/main/res/values/themes.xml',
    title: 'themes.xml',
    module: 'app',
    language: 'xml',
    description: 'App base theme.',
    content: `<resources>
    <style name="Theme.UltraIsland" parent="android:Theme.Material.NoActionBar">
        <item name="android:statusBarColor">#000000</item>
        <item name="android:navigationBarColor">#000000</item>
        <item name="android:windowBackground">#090A0D</item>
    </style>
</resources>`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/UltraIslandApp.kt',
    title: 'UltraIslandApp.kt',
    module: 'app',
    language: 'kotlin',
    description: 'Application class initializing DataStore SettingsRepository and Shizuku listeners.',
    content: `package com.ultraisland.pro

import android.app.Application
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.privileged.PrivilegedManager

class UltraIslandApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SettingsRepository.init(this)
        PrivilegedManager.shizuku.registerListeners()
    }
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/core/datastore/SettingsRepository.kt',
    title: 'SettingsRepository.kt',
    module: 'core',
    language: 'kotlin',
    description: 'DataStore Preferences with exact keys: island_enabled, width_dp, height_dp, offset_x, offset_y, corner_radius, anim_speed, haptic_enabled.',
    content: `package com.ultraisland.pro.core.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "island_settings")

data class IslandSettingsState(
    val islandEnabled: Boolean = true,
    val widthDp: Int = 110,
    val heightDp: Int = 36,
    val offsetX: Int = 0,
    val offsetY: Int = 12,
    val cornerRadius: Int = 24,
    val animSpeed: Float = 1.0f,
    val hapticEnabled: Boolean = true
)

object SettingsRepository {
    private lateinit var appContext: Context

    private val KEY_ISLAND_ENABLED = booleanPreferencesKey("island_enabled")
    private val KEY_WIDTH_DP = intPreferencesKey("width_dp")
    private val KEY_HEIGHT_DP = intPreferencesKey("height_dp")
    private val KEY_OFFSET_X = intPreferencesKey("offset_x")
    private val KEY_OFFSET_Y = intPreferencesKey("offset_y")
    private val KEY_CORNER_RADIUS = intPreferencesKey("corner_radius")
    private val KEY_ANIM_SPEED = floatPreferencesKey("anim_speed")
    private val KEY_HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    val settingsFlow: Flow<IslandSettingsState> by lazy {
        appContext.dataStore.data.map { prefs ->
            IslandSettingsState(
                islandEnabled = prefs[KEY_ISLAND_ENABLED] ?: true,
                widthDp = prefs[KEY_WIDTH_DP] ?: 110,
                heightDp = prefs[KEY_HEIGHT_DP] ?: 36,
                offsetX = prefs[KEY_OFFSET_X] ?: 0,
                offsetY = prefs[KEY_OFFSET_Y] ?: 12,
                cornerRadius = prefs[KEY_CORNER_RADIUS] ?: 24,
                animSpeed = prefs[KEY_ANIM_SPEED] ?: 1.0f,
                hapticEnabled = prefs[KEY_HAPTIC_ENABLED] ?: true
            )
        }
    }

    suspend fun updateSettings(transform: (IslandSettingsState) -> IslandSettingsState) {
        appContext.dataStore.edit { prefs ->
            val current = IslandSettingsState(
                islandEnabled = prefs[KEY_ISLAND_ENABLED] ?: true,
                widthDp = prefs[KEY_WIDTH_DP] ?: 110,
                heightDp = prefs[KEY_HEIGHT_DP] ?: 36,
                offsetX = prefs[KEY_OFFSET_X] ?: 0,
                offsetY = prefs[KEY_OFFSET_Y] ?: 12,
                cornerRadius = prefs[KEY_CORNER_RADIUS] ?: 24,
                animSpeed = prefs[KEY_ANIM_SPEED] ?: 1.0f,
                hapticEnabled = prefs[KEY_HAPTIC_ENABLED] ?: true
            )
            val updated = transform(current)
            prefs[KEY_ISLAND_ENABLED] = updated.islandEnabled
            prefs[KEY_WIDTH_DP] = updated.widthDp
            prefs[KEY_HEIGHT_DP] = updated.heightDp
            prefs[KEY_OFFSET_X] = updated.offsetX
            prefs[KEY_OFFSET_Y] = updated.offsetY
            prefs[KEY_CORNER_RADIUS] = updated.cornerRadius
            prefs[KEY_ANIM_SPEED] = updated.animSpeed
            prefs[KEY_HAPTIC_ENABLED] = updated.hapticEnabled
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/privileged/PrivilegedBridge.kt',
    title: 'PrivilegedBridge.kt',
    module: 'privileged',
    language: 'kotlin',
    description: 'Interface for privileged shell operations with backend status.',
    content: `package com.ultraisland.pro.privileged

interface PrivilegedBridge {
    val backendName: String
    fun isAvailable(): Boolean
    fun hasPermission(): Boolean
    fun requestPermission()
    suspend fun exec(command: String): Result<String>
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/privileged/ShizukuBridge.kt',
    title: 'ShizukuBridge.kt',
    module: 'privileged',
    language: 'kotlin',
    description: 'Shizuku implementation of PrivilegedBridge with timeout and process execution.',
    content: `package com.ultraisland.pro.privileged

import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

class ShizukuBridge : PrivilegedBridge {
    override val backendName: String = "Shizuku"
    private var binderAlive = false

    fun registerListeners() {
        try {
            Shizuku.addBinderReceivedListenerSticky { binderAlive = true }
            Shizuku.addBinderDeadListener { binderAlive = false }
        } catch (t: Throwable) {
            Log.e("ShizukuBridge", "Failed to register Shizuku listeners", t)
        }
    }

    override fun isAvailable(): Boolean = try { Shizuku.pingBinder() } catch (t: Throwable) { false }

    override fun hasPermission(): Boolean = try {
        isAvailable() && !Shizuku.isPre_V11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) { false }

    override fun requestPermission() {
        try {
            if (isAvailable() && !hasPermission()) Shizuku.requestPermission(101)
        } catch (t: Throwable) {
            Log.e("ShizukuBridge", "Failed to request permission", t)
        }
    }

    override suspend fun exec(command: String): Result<String> = withContext(Dispatchers.IO) {
        if (!hasPermission()) return@withContext Result.failure(IllegalStateException("Shizuku permission not granted"))
        try {
            val result = withTimeoutOrNull(5000L) {
                val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                val output = process.inputStream.bufferedReader().use { it.readText() }
                val error = process.errorStream.bufferedReader().use { it.readText() }
                val exitCode = process.waitFor()
                if (exitCode == 0) output.trim() else throw RuntimeException("Command failed ($exitCode): $error")
            }
            if (result != null) Result.success(result) else Result.failure(RuntimeException("Command timed out"))
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }
}

class ManualFallbackBridge : PrivilegedBridge {
    override val backendName: String = "Manual (Non-privileged)"
    override fun isAvailable(): Boolean = true
    override fun hasPermission(): Boolean = false
    override fun requestPermission() {}
    override suspend fun exec(command: String): Result<String> =
        Result.failure(UnsupportedOperationException("Manual backend requires user action via Settings or PC ADB"))
}

object PrivilegedManager {
    val shizuku = ShizukuBridge()
    val manual = ManualFallbackBridge()
    fun getActiveBridge(): PrivilegedBridge = if (shizuku.isAvailable()) shizuku else manual
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/engine/statemachine/IslandStateMachine.kt',
    title: 'IslandStateMachine.kt',
    module: 'engine',
    language: 'kotlin',
    description: 'State machine for Hidden, Idle, Compact, and Expanded states.',
    content: `package com.ultraisland.pro.engine.statemachine

import com.ultraisland.pro.engine.activity.LiveActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface IslandState {
    data object Hidden : IslandState
    data object Idle : IslandState
    data class Compact(val activity: LiveActivity) : IslandState
    data class Expanded(val activity: LiveActivity) : IslandState
}

object IslandStateMachine {
    private val _state = MutableStateFlow<IslandState>(IslandState.Idle)
    val state: StateFlow<IslandState> = _state.asStateFlow()
    private var currentActivity: LiveActivity? = null

    fun postActivity(activity: LiveActivity) {
        currentActivity = activity
        _state.value = IslandState.Compact(activity)
    }

    fun clearActivity() {
        currentActivity = null
        _state.value = IslandState.Idle
    }

    fun toggleExpand() {
        when (val current = _state.value) {
            is IslandState.Compact -> _state.value = IslandState.Expanded(current.activity)
            is IslandState.Expanded -> _state.value = IslandState.Compact(current.activity)
            is IslandState.Idle -> {
                val demo = LiveActivity("idle_demo", "UltraIsland Pro", "Dynamic Island Active", colorHex = "#388AF6")
                currentActivity = demo
                _state.value = IslandState.Expanded(demo)
            }
            is IslandState.Hidden -> {}
        }
    }

    fun setHidden(hidden: Boolean) {
        if (hidden) {
            _state.value = IslandState.Hidden
        } else {
            val act = currentActivity
            _state.value = if (act != null) IslandState.Compact(act) else IslandState.Idle
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/engine/overlay/IslandOverlayManager.kt',
    title: 'IslandOverlayManager.kt',
    module: 'engine',
    language: 'kotlin',
    description: 'WindowManager host mounting ComposeView as TYPE_ACCESSIBILITY_OVERLAY.',
    content: `package com.ultraisland.pro.engine.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.ultraisland.pro.core.datastore.IslandSettingsState
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.engine.render.IslandOverlayRoot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

object IslandOverlayManager {
    private var windowManager: WindowManager? = null
    private var composeView: ComposeView? = null
    private var isAttached = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun attach(context: Context) {
        if (isAttached) return
        try {
            windowManager = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
            val layoutParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                x = 0
                y = 0
            }

            val lifecycleOwner = object : LifecycleOwner, SavedStateRegistryOwner {
                val registry = LifecycleRegistry(this).apply { currentState = Lifecycle.State.RESUMED }
                val controller = SavedStateRegistryController.create(this).apply { performRestore(null) }
                override val lifecycle: Lifecycle get() = registry
                override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
            }

            composeView = ComposeView(context).apply {
                setViewTreeLifecycleOwner(lifecycleOwner)
                setViewTreeSavedStateRegistryOwner(lifecycleOwner)
                setContent { IslandOverlayRoot(settings = IslandSettingsState()) }
            }

            windowManager?.addView(composeView, layoutParams)
            isAttached = true

            scope.launch {
                SettingsRepository.settingsFlow.collectLatest { settings ->
                    composeView?.setContent { IslandOverlayRoot(settings = settings) }
                }
            }
        } catch (t: Throwable) {
            Log.e("IslandOverlayManager", "Failed to mount accessibility overlay", t)
        }
    }

    fun detach() {
        if (!isAttached) return
        try {
            composeView?.let { windowManager?.removeView(it) }
            composeView = null
            isAttached = false
        } catch (e: Exception) {
            Log.e("IslandOverlayManager", "Error detaching", e)
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/services/accessibility/IslandAccessibilityService.kt',
    title: 'IslandAccessibilityService.kt',
    module: 'services',
    language: 'kotlin',
    description: 'Accessibility Service lifecycle managing overlay mount and configuration changes.',
    content: `package com.ultraisland.pro.services.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.res.Configuration
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.ultraisland.pro.engine.overlay.IslandOverlayManager

class IslandAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i("IslandAccessibility", "Accessibility service connected")
        IslandOverlayManager.attach(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        Log.d("IslandAccessibility", "Configuration changed: orientation=\${newConfig.orientation}")
    }

    override fun onDestroy() {
        IslandOverlayManager.detach()
        super.onDestroy()
    }
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/MainActivity.kt',
    title: 'MainActivity.kt',
    module: 'app',
    language: 'kotlin',
    description: 'Main activity with Home, Test, and Setup screens without Hilt.',
    content: `package com.ultraisland.pro

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.core.datastore.IslandSettingsState
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.core.designsystem.UltraIslandTheme
import com.ultraisland.pro.engine.activity.LiveActivity
import com.ultraisland.pro.engine.statemachine.IslandState
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import com.ultraisland.pro.privileged.PrivilegedManager
import com.ultraisland.pro.services.accessibility.IslandAccessibilityService
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UltraIslandTheme {
                MainAppScreen()
            }
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/privileged/PrivilegedCommandRegistry.kt',
    title: 'PrivilegedCommandRegistry.kt',
    module: 'privileged',
    language: 'kotlin',
    description: 'Strict whitelist and command template verification for privileged shell execution.',
    content: `package com.ultraisland.pro.privileged

object PrivilegedCommandRegistry {
    const val CMD_SCREENSHOT = "input keyevent 120"
    const val CMD_LOCK_SCREEN = "input keyevent 26"
    const val CMD_WIFI_ENABLE = "svc wifi enable"
    const val CMD_WIFI_DISABLE = "svc wifi disable"
    const val CMD_BT_ENABLE = "svc bluetooth enable"
    const val CMD_BT_DISABLE = "svc bluetooth disable"
    // Whitelist verification prevents arbitrary shell injection
    fun isCommandAllowed(command: String): Boolean = ...
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/privileged/SystemSettingsRestorer.kt',
    title: 'SystemSettingsRestorer.kt',
    module: 'privileged',
    language: 'kotlin',
    description: 'Tracks system setting modifications (old value, new value) and provides full rollback.',
    content: `package com.ultraisland.pro.privileged

object SystemSettingsRestorer {
    suspend fun recordAndSet(context: Context, bridge: PrivilegedBridge, namespace: String, key: String, newValue: String): Result<String>
    suspend fun restoreAll(context: Context, bridge: PrivilegedBridge): Result<Int>
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/privileged/wireless/AdbWirelessManager.kt',
    title: 'AdbWirelessManager.kt',
    module: 'privileged',
    language: 'kotlin',
    description: 'On-device local wireless ADB pairing wizard and socket executor.',
    content: `package com.ultraisland.pro.privileged.wireless

object AdbWirelessManager {
    suspend fun pairAndConnect(pairingPort: Int, pairingCode: String, connectPort: Int? = null): Result<Boolean>
    suspend fun execCommand(command: String): Result<String>
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/tools/KeepScreenOnService.kt',
    title: 'KeepScreenOnService.kt',
    module: 'services',
    language: 'kotlin',
    description: 'Foreground keep-awake service with WakeLock and persistent notification.',
    content: `package com.ultraisland.pro.tools

class KeepScreenOnService : Service() {
    // Manages PowerManager.WakeLock and ongoing status notification
}`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/tools/tiles/StandardTileServices.kt',
    title: 'StandardTileServices.kt',
    module: 'services',
    language: 'kotlin',
    description: 'Quick Settings tiles: Screenshot, Keep Awake, Volume, Battery Protect, DNS, Grayscale, Lock.',
    content: `package com.ultraisland.pro.tools.tiles

class ToggleIslandTileService : TileService()
class ScreenshotTileService : TileService()
class KeepScreenOnTileService : TileService()
class VolumeModeTileService : TileService()
class BatteryOptimizationTileService : TileService()
class PrivateDnsTileService : TileService()
class GrayscaleTileService : TileService()
class LockScreenTileService : TileService()`
  },
  {
    path: 'app/src/main/java/com/ultraisland/pro/api/IslandApiReceiver.kt',
    title: 'IslandApiReceiver.kt',
    module: 'app',
    language: 'kotlin',
    description: 'Public API receiver protected by signature permission POST_ISLAND_ACTIVITY.',
    content: `package com.ultraisland.pro.api

class IslandApiReceiver : BroadcastReceiver() {
    // Actions: ACTION_POST_ACTIVITY, ACTION_DISMISS_ACTIVITY
}`
  }
];
