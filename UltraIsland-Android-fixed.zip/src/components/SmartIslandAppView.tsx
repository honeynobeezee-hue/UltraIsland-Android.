import React, { useState } from 'react';
import { 
  Terminal, 
  Shield, 
  Settings, 
  Sliders, 
  RefreshCw, 
  Send, 
  CheckCircle, 
  AlertTriangle, 
  Copy, 
  Check, 
  Power, 
  Sparkles, 
  Volume2, 
  Moon, 
  Lock, 
  Search, 
  Smartphone, 
  BatteryCharging, 
  Radio, 
  Wifi, 
  Music, 
  Compass, 
  CloudSun, 
  Eye, 
  Bell, 
  ChevronRight, 
  X, 
  Info, 
  Zap,
  ArrowRight,
  ExternalLink
} from 'lucide-react';
import { IslandSettings, LiveActivity } from '../types';

interface SmartIslandAppViewProps {
  settings: IslandSettings;
  onUpdateSettings: (updater: (prev: IslandSettings) => IslandSettings) => void;
  onTriggerBroadcast?: (activity: LiveActivity) => void;
  compactMode?: boolean; // When rendered inside phone frame
}

export const SmartIslandAppView: React.FC<SmartIslandAppViewProps> = ({
  settings,
  onUpdateSettings,
  onTriggerBroadcast,
  compactMode = false
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'pro_tools' | 'geometry' | 'notifications' | 'media' | 'system'>('all');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Pro Tool States
  const [adbIp, setAdbIp] = useState('192.168.1.104');
  const [adbPort, setAdbPort] = useState('38491');
  const [pairingCode, setPairingCode] = useState('482910');
  const [isAdbPaired, setIsAdbPaired] = useState(true);
  const [shizukuStatus, setShizukuStatus] = useState<'RUNNING' | 'STOPPED'>('RUNNING');

  // System Settings Restorer States
  const [systemAudit, setSystemAudit] = useState({
    headsUp: true,
    daltonizer: false,
    privateDns: 'dns.google',
    stayAwake: false
  });
  const [restorerToast, setRestorerToast] = useState<string | null>(null);

  // Live Activity Broadcast Builder
  const [apiTitle, setApiTitle] = useState('Delivery Order #402');
  const [apiSubtitle, setApiSubtitle] = useState('Driver 2 mins away');
  const [apiIcon, setApiIcon] = useState('Car');
  const [apiColor, setApiColor] = useState('#10B981');
  const [apiPriority, setApiPriority] = useState(2);

  // 10 QS Tiles Matrix
  const [qsTiles, setQsTiles] = useState([
    { id: 1, name: 'Toggle Island', action: 'TOGGLE_ISLAND', active: true, color: '#3B82F6' },
    { id: 2, name: 'Screenshot', action: 'TAKE_SCREENSHOT', active: true, color: '#10B981' },
    { id: 3, name: 'Keep Screen Awake', action: 'KEEP_AWAKE', active: true, color: '#F59E0B' },
    { id: 4, name: 'Sound / Vibrate', action: 'VOLUME_CYCLE', active: true, color: '#8B5CF6' },
    { id: 5, name: 'Battery Saver', action: 'BATTERY_SAVER', active: false, color: '#EC4899' },
    { id: 6, name: 'Private DNS', action: 'TOGGLE_DNS', active: true, color: '#06B6D4' },
    { id: 7, name: 'Grayscale Mode', action: 'DALTONIZER_TOGGLE', active: false, color: '#64748B' },
    { id: 8, name: 'Lock Screen', action: 'LOCK_DEVICE', active: true, color: '#EF4444' },
    { id: 9, name: 'App Shortcut 1', action: 'OPEN_APP', active: false, color: '#6366F1' },
    { id: 10, name: 'Quick Note', action: 'CUSTOM_INTENT', active: false, color: '#14B8A6' },
  ]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleSendBroadcast = () => {
    if (onTriggerBroadcast) {
      const activity: LiveActivity = {
        id: `broadcast_${Date.now()}`,
        type: 'RIDE',
        title: apiTitle,
        subtitle: apiSubtitle,
        accentColorHex: apiColor,
        iconType: 'car',
        timestamp: Date.now(),
        progress: 0.75
      };
      onTriggerBroadcast(activity);
    }
  };

  const resetSystemSettings = () => {
    setSystemAudit({
      headsUp: true,
      daltonizer: false,
      privateDns: 'off',
      stayAwake: false
    });
    setRestorerToast('Semua nilai sistem berhasil dikembalikan ke standar bawaan pabrik!');
    setTimeout(() => setRestorerToast(null), 3000);
  };

  return (
    <div className={`w-full bg-[#121316] text-zinc-100 flex flex-col font-sans select-none ${compactMode ? 'h-full overflow-y-auto text-xs' : 'rounded-3xl border border-zinc-800 p-6'}`}>
      
      {/* Top Android Material 3 Status & Search Bar */}
      <div className={`sticky top-0 z-20 bg-[#121316]/95 backdrop-blur-md pb-3 border-b border-zinc-800/80 ${compactMode ? 'pt-2 px-3' : 'pt-0 px-0'}`}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-bold text-xs">
              UI
            </div>
            <div>
              <h1 className={`${compactMode ? 'text-xs' : 'text-base'} font-bold text-white tracking-tight`}>
                UltraIsland Pro
              </h1>
              <p className="text-[10px] text-zinc-400">Settings & Privileged Tools Hub</p>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-semibold flex items-center gap-1">
            <CheckCircle className="w-3 h-3" /> Ready
          </span>
        </div>

        {/* Live Search Bar */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari fitur (ADB, DNS, Tiles, Cutout, Notif)..."
            className="w-full bg-zinc-900/90 border border-zinc-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-blue-500 transition"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Category Chips */}
        <div className="flex items-center gap-1.5 mt-2.5 overflow-x-auto pb-1 no-scrollbar text-[11px]">
          {[
            { id: 'all', label: 'Semua' },
            { id: 'pro_tools', label: '🛠️ Pro Tools' },
            { id: 'geometry', label: '📐 Cutout' },
            { id: 'notifications', label: '🔔 Notifikasi' },
            { id: 'media', label: '🎵 Media' },
            { id: 'system', label: '⚡ Sistem' }
          ].map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition ${
                activeCategory === cat.id
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-zinc-800/80 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Scrollable Content */}
      <div className={`space-y-4 pt-3 ${compactMode ? 'px-3 pb-20' : 'px-1 pb-4'}`}>
        
        {/* PRIVILEGED ENGINE STATUS BANNER */}
        <div className="p-3 rounded-2xl bg-gradient-to-r from-blue-950/40 via-zinc-900 to-indigo-950/40 border border-blue-500/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-white text-xs">Accessibility & Shizuku Service</div>
              <div className="text-[10px] text-zinc-400">Zero-permission overlay aktif & tersambung</div>
            </div>
          </div>
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
        </div>

        {/* ========================================================
            CARD 1: WIRELESS ADB WIZARD (Fase 7 Pro)
           ======================================================== */}
        {(activeCategory === 'all' || activeCategory === 'pro_tools') && (
          <div className="p-3.5 rounded-2xl bg-zinc-900/90 border border-zinc-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span className="font-bold text-white text-xs">ADB Wireless Wizard</span>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                isAdbPaired ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
              }`}>
                {isAdbPaired ? 'Connected' : 'Unpaired'}
              </span>
            </div>

            <p className="text-[11px] text-zinc-400">
              Otorisasi izin <code className="text-zinc-300 font-mono text-[10px]">WRITE_SECURE_SETTINGS</code> secara nirkabel langsung di perangkat tanpa perlu PC.
            </p>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 rounded-xl bg-zinc-950/70 border border-zinc-800/80">
                <div className="text-[10px] text-zinc-500">Pairing Port:</div>
                <div className="font-mono text-zinc-200 font-bold">{adbPort}</div>
              </div>
              <div className="p-2 rounded-xl bg-zinc-950/70 border border-zinc-800/80">
                <div className="text-[10px] text-zinc-500">Pairing Code:</div>
                <div className="font-mono text-emerald-400 font-bold">{pairingCode}</div>
              </div>
            </div>

            {/* Quick Command Box */}
            <div className="p-2 rounded-xl bg-black border border-zinc-800 flex items-center justify-between font-mono text-[10px] text-zinc-300">
              <span className="truncate mr-2">adb pair {adbIp}:{adbPort} {pairingCode}</span>
              <button
                onClick={() => handleCopy(`adb pair ${adbIp}:${adbPort} ${pairingCode}`, 'pair_cmd')}
                className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-white transition"
                title="Salin Perintah ADB"
              >
                {copiedText === 'pair_cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            <div className="flex gap-2 pt-1">
              <button 
                onClick={() => setIsAdbPaired(!isAdbPaired)}
                className="flex-1 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-[11px] transition"
              >
                {isAdbPaired ? 'Refresh Koneksi' : 'Lakukan Pairing'}
              </button>
              <button 
                onClick={() => setShizukuStatus(shizukuStatus === 'RUNNING' ? 'STOPPED' : 'RUNNING')}
                className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium text-[11px] transition"
              >
                Shizuku: {shizukuStatus}
              </button>
            </div>
          </div>
        )}

        {/* ========================================================
            CARD 2: SYSTEM SETTINGS RESTORER (Fase 7 Pro)
           ======================================================== */}
        {(activeCategory === 'all' || activeCategory === 'pro_tools' || activeCategory === 'system') && (
          <div className="p-3.5 rounded-2xl bg-zinc-900/90 border border-zinc-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-white text-xs">System Settings Restorer</span>
              </div>
              <span className="text-[10px] text-zinc-400 font-mono">Audit 4 Keys</span>
            </div>

            <p className="text-[11px] text-zinc-400">
              Periksa dan pulihkan konfigurasi sistem Android yang dimodifikasi oleh modul pulau.
            </p>

            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
                <div>
                  <div className="font-medium text-white text-[11px]">Heads-Up Notifications</div>
                  <div className="text-[10px] text-zinc-500 font-mono">heads_up_notifications_enabled</div>
                </div>
                <button
                  onClick={() => setSystemAudit(p => ({ ...p, headsUp: !p.headsUp }))}
                  className={`w-10 h-5 rounded-full transition p-0.5 flex items-center ${
                    systemAudit.headsUp ? 'bg-blue-600 justify-end' : 'bg-zinc-700 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow" />
                </button>
              </div>

              <div className="flex items-center justify-between p-2 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
                <div>
                  <div className="font-medium text-white text-[11px]">Daltonizer (Grayscale)</div>
                  <div className="text-[10px] text-zinc-500 font-mono">accessibility_display_daltonizer</div>
                </div>
                <button
                  onClick={() => setSystemAudit(p => ({ ...p, daltonizer: !p.daltonizer }))}
                  className={`w-10 h-5 rounded-full transition p-0.5 flex items-center ${
                    systemAudit.daltonizer ? 'bg-blue-600 justify-end' : 'bg-zinc-700 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow" />
                </button>
              </div>

              <div className="flex items-center justify-between p-2 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
                <div>
                  <div className="font-medium text-white text-[11px]">Private DNS Provider</div>
                  <div className="text-[10px] text-zinc-500 font-mono">private_dns_mode: {systemAudit.privateDns}</div>
                </div>
                <button
                  onClick={() => setSystemAudit(p => ({ ...p, privateDns: p.privateDns === 'off' ? 'dns.google' : 'off' }))}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    systemAudit.privateDns !== 'off' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-zinc-800 text-zinc-400'
                  }`}
                >
                  {systemAudit.privateDns !== 'off' ? 'Active' : 'Disabled'}
                </button>
              </div>
            </div>

            {restorerToast && (
              <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-semibold flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5" />
                {restorerToast}
              </div>
            )}

            <button
              onClick={resetSystemSettings}
              className="w-full py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-semibold text-[11px] flex items-center justify-center gap-1.5 transition"
            >
              <RefreshCw className="w-3 h-3 text-amber-400" />
              <span>Reset Semua ke Default Pabrik</span>
            </button>
          </div>
        )}

        {/* ========================================================
            CARD 3: PUBLIC LIVE ACTIVITY BROADCAST API (Fase 7 Pro)
           ======================================================== */}
        {(activeCategory === 'all' || activeCategory === 'pro_tools') && (
          <div className="p-3.5 rounded-2xl bg-zinc-900/90 border border-zinc-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Send className="w-4 h-4 text-blue-400" />
                <span className="font-bold text-white text-xs">Public Live Activity Broadcast API</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 text-[10px] font-bold">
                Live Intent
              </span>
            </div>

            <p className="text-[11px] text-zinc-400">
              Kirim sinyal Intent broadcast langsung dari aplikasi luar (Tasker, MacroDroid, atau ADB terminal) untuk menampilkan Live Activity di Dynamic Island.
            </p>

            <div className="space-y-2 text-[11px]">
              <div>
                <label className="text-[10px] text-zinc-400 font-medium">Judul Event / Activity:</label>
                <input
                  type="text"
                  value={apiTitle}
                  onChange={(e) => setApiTitle(e.target.value)}
                  className="w-full mt-1 bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-white text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 font-medium">Subteks / Status:</label>
                <input
                  type="text"
                  value={apiSubtitle}
                  onChange={(e) => setApiSubtitle(e.target.value)}
                  className="w-full mt-1 bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-white text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex gap-2">
                <div className="flex-1">
                  <label className="text-[10px] text-zinc-400 font-medium">Warna Aksen:</label>
                  <div className="flex items-center gap-1.5 mt-1">
                    {['#10B981', '#3B82F6', '#F59E0B', '#EC4899', '#8B5CF6'].map(col => (
                      <button
                        key={col}
                        onClick={() => setApiColor(col)}
                        className={`w-6 h-6 rounded-full transition ${apiColor === col ? 'ring-2 ring-white scale-110' : 'opacity-80'}`}
                        style={{ backgroundColor: col }}
                      />
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-[10px] text-zinc-400 font-medium">Prioritas (1-5):</label>
                  <select
                    value={apiPriority}
                    onChange={(e) => setApiPriority(Number(e.target.value))}
                    className="mt-1 bg-zinc-950 border border-zinc-800 rounded-lg px-2 py-1 text-white text-xs"
                  >
                    {[1, 2, 3, 4, 5].map(p => (
                      <option key={p} value={p}>Prioritas {p}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Test Trigger Button */}
            <button
              onClick={handleSendBroadcast}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 transition active:scale-[0.98]"
            >
              <Zap className="w-4 h-4 fill-white" />
              <span>⚡ Kirim Test Broadcast ke Pulau</span>
            </button>
          </div>
        )}

        {/* ========================================================
            CARD 4: 10-SLOT QUICK TOOLS TILE MATRIX (Fase 7 Pro)
           ======================================================== */}
        {(activeCategory === 'all' || activeCategory === 'pro_tools') && (
          <div className="p-3.5 rounded-2xl bg-zinc-900/90 border border-zinc-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-purple-400" />
                <span className="font-bold text-white text-xs">10-Slot Quick Settings Tiles</span>
              </div>
              <span className="text-[10px] text-zinc-400 font-mono">
                {qsTiles.filter(t => t.active).length} Aktif
              </span>
            </div>

            <p className="text-[11px] text-zinc-400">
              Konfigurasi 10 ubin Quick Settings Android untuk akses kilat kontrol sistem dan fitur pulau.
            </p>

            <div className="grid grid-cols-2 gap-2">
              {qsTiles.slice(0, 6).map((tile) => (
                <div 
                  key={tile.id} 
                  onClick={() => {
                    setQsTiles(prev => prev.map(t => t.id === tile.id ? { ...t, active: !t.active } : t));
                  }}
                  className={`p-2 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                    tile.active 
                      ? 'bg-zinc-800/90 border-blue-500/50 text-white' 
                      : 'bg-zinc-950/60 border-zinc-800/80 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <div 
                      className="w-2.5 h-2.5 rounded-full shrink-0" 
                      style={{ backgroundColor: tile.active ? tile.color : '#52525b' }} 
                    />
                    <span className="font-medium text-[11px] truncate">{tile.name}</span>
                  </div>
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${tile.active ? 'bg-blue-500/20 text-blue-300' : 'bg-zinc-800 text-zinc-500'}`}>
                    #{tile.id}
                  </span>
                </div>
              ))}
            </div>

            {/* Tile Presets */}
            <div className="flex items-center gap-1.5 pt-1 text-[10px]">
              <span className="text-zinc-500 font-medium">Presets:</span>
              <button 
                onClick={() => setQsTiles(prev => prev.map((t, idx) => ({ ...t, active: idx < 4 })))}
                className="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition"
              >
                Essentials (4)
              </button>
              <button 
                onClick={() => setQsTiles(prev => prev.map(t => ({ ...t, active: true })))}
                className="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition"
              >
                Aktifkan Semua (10)
              </button>
            </div>
          </div>
        )}

        {/* ========================================================
            CARD 5: CUTOUT GEOMETRY CALIBRATION (Fase 1 & 6)
           ======================================================== */}
        {(activeCategory === 'all' || activeCategory === 'geometry') && (
          <div className="p-3.5 rounded-2xl bg-zinc-900/90 border border-zinc-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-blue-400" />
                <span className="font-bold text-white text-xs">Kalibrasi Geometri Cutout</span>
              </div>
              <span className="text-[10px] text-zinc-400 font-mono">
                {settings.cutoutWidth}x{settings.cutoutHeight}dp
              </span>
            </div>

            <div className="space-y-2.5 text-[11px]">
              <div>
                <div className="flex justify-between text-[10px] text-zinc-400 mb-1">
                  <span>Lebar Minimum Pulau:</span>
                  <span className="font-mono text-white">{settings.cutoutWidth} dp</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="160"
                  value={settings.cutoutWidth}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    onUpdateSettings(s => ({ ...s, cutoutWidth: val, minClosedWidth: val }));
                  }}
                  className="w-full accent-blue-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-[10px] text-zinc-400 mb-1">
                  <span>Tinggi Cutout:</span>
                  <span className="font-mono text-white">{settings.cutoutHeight} dp</span>
                </div>
                <input
                  type="range"
                  min="24"
                  max="52"
                  value={settings.cutoutHeight}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    onUpdateSettings(s => ({ ...s, cutoutHeight: val }));
                  }}
                  className="w-full accent-blue-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-[10px] text-zinc-400 mb-1">
                  <span>Posisi Y (Jarak dari Atas):</span>
                  <span className="font-mono text-white">{settings.topYOffset} dp</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="30"
                  value={settings.topYOffset}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    onUpdateSettings(s => ({ ...s, topYOffset: val }));
                  }}
                  className="w-full accent-blue-500"
                />
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
