import React, { useState } from 'react';
import { 
  Sliders, 
  Sparkles, 
  Eye, 
  Layers, 
  ShieldAlert, 
  CheckCircle2, 
  Copy, 
  Check, 
  Maximize2, 
  Smartphone, 
  Zap, 
  Compass, 
  RotateCcw,
  Palette,
  Volume2,
  Terminal,
  Activity
} from 'lucide-react';
import { IslandSettings, AnimationStyle, MergeStyle, DisplayMode, CutoutHoleShape } from '../types';

interface SmartIslandStudioProps {
  settings: IslandSettings;
  onUpdateSettings: (updater: (prev: IslandSettings) => IslandSettings) => void;
  onTriggerTest: (type: 'call' | 'music' | 'timer' | 'notif' | 'charging') => void;
  onResetSettings: () => void;
}

export const SmartIslandStudio: React.FC<SmartIslandStudioProps> = ({
  settings,
  onUpdateSettings,
  onTriggerTest,
  onResetSettings
}) => {
  // Simulated permissions state
  const [permissions, setPermissions] = useState({
    accessibility: true,
    overlaySaw: true,
    shizuku: true,
    notificationListener: true,
    batteryOptimization: true
  });

  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const hasAnyMissingCorePermission = !permissions.accessibility && !permissions.overlaySaw;

  return (
    <div className="space-y-6 pb-12 max-w-2xl mx-auto">
      {/* 1. Header & Welcome Headline */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-zinc-800 pb-5">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-blue-500/10 text-blue-400 border border-blue-500/30 rounded-md">
              Phase 0 & 1 Ready
            </span>
            <span className="text-xs text-zinc-500">Android 8–16</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">Welcome to UltraIsland Studio</h1>
          <p className="text-xs text-zinc-400">
            Smart Island Studio layout • Superset engine combining SmartIsland, Islandify, ExpressiveCutout & Tooler
          </p>
        </div>

        <button
          onClick={onResetSettings}
          className="self-start sm:self-auto px-3 py-1.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-700/80 border border-zinc-700/50 text-zinc-300 text-xs font-medium flex items-center space-x-1.5 transition"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Presets</span>
        </button>
      </div>

      {/* 2. Top Live Preview Stage */}
      <div className="rounded-[28px] bg-gradient-to-b from-zinc-900/90 to-zinc-950 p-6 border border-zinc-800/80 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Eye className="w-4 h-4 text-blue-400" />
            <span className="text-xs font-bold text-blue-400 tracking-wider uppercase">Live Studio Preview</span>
          </div>
          <span className="text-[11px] text-zinc-500 font-mono">
            {settings.cutoutWidth}×{settings.cutoutHeight}dp • Radius: {settings.cornerRadius}dp
          </span>
        </div>

        {/* Live Pill Simulation in Studio */}
        <div className="py-6 flex flex-col items-center justify-center bg-zinc-950/70 rounded-2xl border border-zinc-800/50">
          <div 
            className="relative flex items-center justify-between px-3 transition-all cursor-pointer bg-black"
            style={{
              width: `${settings.cutoutWidth}px`,
              height: `${settings.cutoutHeight}px`,
              borderRadius: `${settings.cornerRadius}px`,
              boxShadow: settings.ambientShadow ? '0 10px 25px rgba(0,0,0,0.8), 0 0 1px rgba(255,255,255,0.2)' : 'none',
              border: settings.showOutlineBorder ? '1px solid rgba(255,255,255,0.18)' : 'none'
            }}
          >
            <div className="w-2.5 h-2.5 rounded-full bg-zinc-900 border border-zinc-800 shadow-inner" />
            <span className="text-[10px] font-semibold text-zinc-400 tracking-tight">UltraIsland</span>
            <div className="w-2 h-2 rounded-full bg-emerald-500/80 animate-pulse" />
          </div>

          <div className="mt-4 flex items-center gap-2">
            <button 
              onClick={() => onTriggerTest('music')}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium transition"
            >
              Test Music Pill
            </button>
            <button 
              onClick={() => onTriggerTest('call')}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium transition"
            >
              Test Call Card
            </button>
            <button 
              onClick={() => onTriggerTest('timer')}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium transition"
            >
              Test Timer
            </button>
          </div>
        </div>
        <p className="text-[11px] text-zinc-500 mt-2 text-center">
          Pill morphs organically in real time according to calibration sliders below.
        </p>
      </div>

      {/* 3. Action Required Banner */}
      {hasAnyMissingCorePermission ? (
        <div className="rounded-[24px] bg-red-950/40 border border-red-500/30 p-5 shadow-lg">
          <div className="flex items-start space-x-3">
            <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="text-sm font-bold text-red-400">Action Required: Overlay Permission Missing</h3>
              <p className="text-xs text-zinc-300 mt-1">
                UltraIsland Pro requires Accessibility Service (primary) or System Alert Window (fallback) to render above the Android status bar and lockscreen.
              </p>
              
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  onClick={() => setPermissions(p => ({ ...p, accessibility: true }))}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold shadow-md transition"
                >
                  Grant Accessibility Service (Simulated)
                </button>
                <button
                  onClick={() => setPermissions(p => ({ ...p, overlaySaw: true }))}
                  className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold transition"
                >
                  Grant System Alert Window
                </button>
              </div>

              {/* ADB command helper */}
              <div className="mt-3 bg-black/60 rounded-xl p-3 border border-red-900/30 font-mono text-[11px] flex items-center justify-between text-zinc-300">
                <span className="truncate pr-2">
                  adb shell settings put secure enabled_accessibility_services com.ultraisland.pro/.services.accessibility.IslandAccessibilityService
                </span>
                <button
                  onClick={() => copyToClipboard('adb shell settings put secure enabled_accessibility_services com.ultraisland.pro/com.ultraisland.pro.services.accessibility.IslandAccessibilityService && adb shell settings put secure accessibility_enabled 1', 'adb1')}
                  className="p-1 hover:text-white transition"
                  title="Copy ADB command"
                >
                  {copiedCmd === 'adb1' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="rounded-[22px] bg-emerald-950/20 border border-emerald-500/20 p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <div>
              <div className="text-xs font-bold text-emerald-400">All Core Permissions Active</div>
              <div className="text-[11px] text-zinc-400">Accessibility Service Overlay active • Zero battery drain event architecture</div>
            </div>
          </div>
          <button
            onClick={() => setPermissions(p => ({ ...p, accessibility: false, overlaySaw: false }))}
            className="text-[11px] text-zinc-500 hover:text-zinc-300 underline"
          >
            Simulate Revoke
          </button>
        </div>
      )}

      {/* 4. SECTION CARD: Hardware Cutout Calibration */}
      <div className="rounded-[24px] bg-zinc-900/80 border border-zinc-800 p-6 space-y-5 shadow-lg">
        <div className="flex items-center space-x-3 border-b border-zinc-800/60 pb-3">
          <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center">
            <Smartphone className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Cutout & Display Calibration</h2>
            <p className="text-xs text-zinc-400">Fine-tune island geometry to match your phone's camera hole</p>
          </div>
        </div>

        {/* Preset Buttons */}
        <div>
          <label className="text-xs font-semibold text-zinc-300 mb-2 block">Quick Phone Presets</label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { name: 'Pixel 8 / 9', w: 105, h: 34, r: 22, y: 11, shape: 'CENTER_HOLE' as CutoutHoleShape },
              { name: 'Wide Island', w: 135, h: 36, r: 24, y: 10, shape: 'PILL_HOLE' as CutoutHoleShape },
              { name: 'Galaxy S24', w: 100, h: 32, r: 20, y: 12, shape: 'CENTER_HOLE' as CutoutHoleShape },
              { name: 'Floating Mode', w: 115, h: 36, r: 26, y: 18, shape: 'NONE' as CutoutHoleShape }
            ].map(preset => (
              <button
                key={preset.name}
                onClick={() => onUpdateSettings(s => ({
                  ...s,
                  cutoutWidth: preset.w,
                  cutoutHeight: preset.h,
                  cornerRadius: preset.r,
                  topYOffset: preset.y,
                  cutoutHoleShape: preset.shape,
                  displayMode: preset.shape === 'NONE' ? 'FLOATING' : 'CUTOUT_MERGE'
                }))}
                className="py-2 px-3 rounded-xl bg-zinc-800/80 hover:bg-zinc-700/80 border border-zinc-700/40 text-xs text-zinc-200 font-medium transition text-center"
              >
                {preset.name}
              </button>
            ))}
          </div>
        </div>

        {/* Sliders */}
        <div className="space-y-4 pt-2">
          {/* Cutout Width */}
          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-zinc-300 font-medium">Cutout Width (Closed Pill)</span>
              <span className="text-blue-400 font-bold font-mono">{settings.cutoutWidth} dp</span>
            </div>
            <input 
              type="range" 
              min={70} 
              max={220} 
              value={settings.cutoutWidth} 
              onChange={e => onUpdateSettings(s => ({ ...s, cutoutWidth: Number(e.target.value) }))}
              className="w-full accent-blue-500 cursor-pointer"
            />
            <p className="text-[11px] text-zinc-500 mt-1">Width of the pill when enclosing the camera hole at idle.</p>
          </div>

          {/* Cutout Height */}
          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-zinc-300 font-medium">Cutout Height</span>
              <span className="text-blue-400 font-bold font-mono">{settings.cutoutHeight} dp</span>
            </div>
            <input 
              type="range" 
              min={24} 
              max={54} 
              value={settings.cutoutHeight} 
              onChange={e => onUpdateSettings(s => ({ ...s, cutoutHeight: Number(e.target.value) }))}
              className="w-full accent-blue-500 cursor-pointer"
            />
          </div>

          {/* Centre X Offset */}
          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-zinc-300 font-medium">Centre X Offset</span>
              <span className="text-blue-400 font-bold font-mono">{settings.centreXOffset > 0 ? `+${settings.centreXOffset}` : settings.centreXOffset} dp</span>
            </div>
            <input 
              type="range" 
              min={-120} 
              max={120} 
              value={settings.centreXOffset} 
              onChange={e => onUpdateSettings(s => ({ ...s, centreXOffset: Number(e.target.value) }))}
              className="w-full accent-blue-500 cursor-pointer"
            />
            <p className="text-[11px] text-zinc-500 mt-1">Shift island left/right for off-center or corner punch holes.</p>
          </div>

          {/* Top Y Position */}
          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-zinc-300 font-medium">Top Y Position</span>
              <span className="text-blue-400 font-bold font-mono">{settings.topYOffset} dp</span>
            </div>
            <input 
              type="range" 
              min={0} 
              max={50} 
              value={settings.topYOffset} 
              onChange={e => onUpdateSettings(s => ({ ...s, topYOffset: Number(e.target.value) }))}
              className="w-full accent-blue-500 cursor-pointer"
            />
          </div>

          {/* Corner Radius */}
          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-zinc-300 font-medium">Squircle Corner Radius</span>
              <span className="text-blue-400 font-bold font-mono">{settings.cornerRadius} dp</span>
            </div>
            <input 
              type="range" 
              min={12} 
              max={38} 
              value={settings.cornerRadius} 
              onChange={e => onUpdateSettings(s => ({ ...s, cornerRadius: Number(e.target.value) }))}
              className="w-full accent-blue-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* 5. SECTION CARD: Animation & Motion Physics */}
      <div className="rounded-[24px] bg-zinc-900/80 border border-zinc-800 p-6 space-y-5 shadow-lg">
        <div className="flex items-center space-x-3 border-b border-zinc-800/60 pb-3">
          <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Spring Physics & Motion</h2>
            <p className="text-xs text-zinc-400">Authentic iOS spring equation (damping ≈ 0.72, stiffness ≈ 380)</p>
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold text-zinc-300 mb-2 block">Animation Style</label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'IOS_SPRING' as AnimationStyle, label: 'iOS Spring', desc: 'Damp 0.72 • Stiff 380' },
              { id: 'MATERIAL_EXPRESSIVE' as AnimationStyle, label: 'Expressive', desc: 'Material 3 M3' },
              { id: 'BOUNCY' as AnimationStyle, label: 'Bouncy', desc: 'Playful elasticity' },
              { id: 'SMOOTH_LINEAR' as AnimationStyle, label: 'Linear', desc: 'Consistent speed' },
              { id: 'MINIMAL' as AnimationStyle, label: 'Snappy', desc: '160ms instant' },
              { id: 'INSTANT' as AnimationStyle, label: 'Zero Duration', desc: 'No animation' }
            ].map(style => (
              <button
                key={style.id}
                onClick={() => onUpdateSettings(s => ({ ...s, animationStyle: style.id }))}
                className={`p-3 rounded-2xl border text-left transition ${
                  settings.animationStyle === style.id
                    ? 'bg-blue-600/20 border-blue-500 text-white'
                    : 'bg-zinc-800/60 border-zinc-700/40 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <div className="text-xs font-bold">{style.label}</div>
                <div className="text-[10px] text-zinc-500">{style.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Speed Slider */}
        <div>
          <div className="flex justify-between text-xs mb-1.5">
            <span className="text-zinc-300 font-medium">Motion Speed Multiplier</span>
            <span className="text-purple-400 font-bold font-mono">{settings.animationSpeedMultiplier.toFixed(2)}x</span>
          </div>
          <input 
            type="range" 
            min={0.5} 
            max={2.5} 
            step={0.1}
            value={settings.animationSpeedMultiplier} 
            onChange={e => onUpdateSettings(s => ({ ...s, animationSpeedMultiplier: Number(e.target.value) }))}
            className="w-full accent-purple-500 cursor-pointer"
          />
        </div>

        {/* Haptic Toggle */}
        <div className="flex items-center justify-between pt-2">
          <div>
            <div className="text-xs font-semibold text-white">Light Haptic Feedback</div>
            <div className="text-[11px] text-zinc-400">Subtle vibration pulse on expand, collapse, and swipe</div>
          </div>
          <input
            type="checkbox"
            checked={settings.hapticEnabled}
            onChange={e => onUpdateSettings(s => ({ ...s, hapticEnabled: e.target.checked }))}
            className="w-5 h-5 accent-blue-500 cursor-pointer"
          />
        </div>
      </div>

      {/* 6. SECTION CARD: Visual Styling & Glow */}
      <div className="rounded-[24px] bg-zinc-900/80 border border-zinc-800 p-6 space-y-4 shadow-lg">
        <div className="flex items-center space-x-3 border-b border-zinc-800/60 pb-3">
          <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
            <Palette className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Visual Appearance & Effects</h2>
            <p className="text-xs text-zinc-400">Islandify glow flashes, outline borders, and ambient drop shadows</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-xs font-semibold text-white">Glow Flash on New Activity</div>
              <div className="text-[11px] text-zinc-400">Illuminates outer border with matching accent color</div>
            </div>
            <input
              type="checkbox"
              checked={settings.showGlowFlash}
              onChange={e => onUpdateSettings(s => ({ ...s, showGlowFlash: e.target.checked }))}
              className="w-5 h-5 accent-blue-500 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-xs font-semibold text-white">Subtle Outline Border</div>
              <div className="text-[11px] text-zinc-400">Crisp continuous border in OLED dark mode</div>
            </div>
            <input
              type="checkbox"
              checked={settings.showOutlineBorder}
              onChange={e => onUpdateSettings(s => ({ ...s, showOutlineBorder: e.target.checked }))}
              className="w-5 h-5 accent-blue-500 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-xs font-semibold text-white">Ambient Elevation Drop Shadow</div>
              <div className="text-[11px] text-zinc-400">Soft realistic depth above running apps and wallpaper</div>
            </div>
            <input
              type="checkbox"
              checked={settings.ambientShadow}
              onChange={e => onUpdateSettings(s => ({ ...s, ambientShadow: e.target.checked }))}
              className="w-5 h-5 accent-blue-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* 7. SECTION CARD: Behavior & Rules */}
      <div className="rounded-[24px] bg-zinc-900/80 border border-zinc-800 p-6 space-y-4 shadow-lg">
        <div className="flex items-center space-x-3 border-b border-zinc-800/60 pb-3">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
            <Activity className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Smart Behavior & Auto-Hide</h2>
            <p className="text-xs text-zinc-400">Fullscreen rules, lockscreen policies, and anti-spam</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-xs font-semibold text-white">Auto-hide in Fullscreen Mode</div>
              <div className="text-[11px] text-zinc-400">Disappears when watching YouTube, Netflix or gaming</div>
            </div>
            <input
              type="checkbox"
              checked={settings.hideInFullscreen}
              onChange={e => onUpdateSettings(s => ({ ...s, hideInFullscreen: e.target.checked }))}
              className="w-5 h-5 accent-blue-500 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-xs font-semibold text-white">Show on Lockscreen</div>
              <div className="text-[11px] text-zinc-400">Enabled via TYPE_ACCESSIBILITY_OVERLAY</div>
            </div>
            <input
              type="checkbox"
              checked={settings.showOnLockscreen}
              onChange={e => onUpdateSettings(s => ({ ...s, showOnLockscreen: e.target.checked }))}
              className="w-5 h-5 accent-blue-500 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-xs font-semibold text-white">Auto-expand New Notifications</div>
              <div className="text-[11px] text-zinc-400">Immediately expands into rich card upon incoming ping</div>
            </div>
            <input
              type="checkbox"
              checked={settings.autoExpandNewNotification}
              onChange={e => onUpdateSettings(s => ({ ...s, autoExpandNewNotification: e.target.checked }))}
              className="w-5 h-5 accent-blue-500 cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
