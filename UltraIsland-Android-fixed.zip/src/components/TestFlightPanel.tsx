import React from 'react';
import { 
  Phone, 
  Music, 
  Timer, 
  Bell, 
  Zap, 
  Navigation, 
  Car, 
  Download, 
  ArrowRightLeft, 
  Trash2, 
  Play, 
  Maximize, 
  Minimize2,
  Layers,
  Sparkles
} from 'lucide-react';
import { LiveActivity, IslandState } from '../types';

interface TestFlightPanelProps {
  currentState: IslandState;
  activeActivities: LiveActivity[];
  onAddActivity: (activity: LiveActivity, autoExpand?: boolean) => void;
  onRemoveActivity: (id: string) => void;
  onClearAll: () => void;
  onSwapDual: () => void;
  onToggleExpand: () => void;
}

export const TestFlightPanel: React.FC<TestFlightPanelProps> = ({
  currentState,
  activeActivities,
  onAddActivity,
  onRemoveActivity,
  onClearAll,
  onSwapDual,
  onToggleExpand
}) => {
  const testScenarios = [
    {
      type: 'CALL' as const,
      name: 'Incoming Phone Call',
      title: 'Incoming Call',
      subtitle: 'Jane Doe (+1 555-0199)',
      accentColorHex: '#34C759',
      priority: 'Priority 7 (Highest)',
      icon: Phone,
      autoExpand: true
    },
    {
      type: 'NAVIGATION' as const,
      name: 'Google Maps Navigation',
      title: 'In 200m Turn Right',
      subtitle: 'Grand Avenue • 14 min ETA',
      accentColorHex: '#4285F4',
      priority: 'Priority 5.5',
      icon: Navigation,
      autoExpand: false
    },
    {
      type: 'RIDE' as const,
      name: 'Grab / Uber Ride Tracking',
      title: 'GrabCar • Toyota Prius',
      subtitle: 'Driver arriving in 4 min (75%)',
      accentColorHex: '#00AA13',
      priority: 'Priority 4.5',
      icon: Car,
      progress: 0.75,
      autoExpand: false
    },
    {
      type: 'CALENDAR' as const,
      name: 'Local Calendar Event',
      title: 'Sprint Planning',
      subtitle: '10:30, in 25 min (Conf Room A)',
      accentColorHex: '#FF9500',
      priority: 'Idle / Widget',
      icon: Bell,
      autoExpand: false
    },
    {
      type: 'WEATHER' as const,
      name: 'Open-Meteo Weather Widget',
      title: '28°C Partly Cloudy',
      subtitle: 'AQI 42 (Good) • Wind 14 km/h',
      accentColorHex: '#FFD600',
      priority: 'Idle / Widget',
      icon: Sparkles,
      autoExpand: false
    },
    {
      type: 'QUICK_LAUNCHER' as const,
      name: 'Quick Utilities Toolbar',
      title: 'Quick Tools Bar',
      subtitle: 'Torch, Calculator, Notes, Apps',
      accentColorHex: '#388AF6',
      priority: 'Utility Tool',
      icon: Layers,
      autoExpand: true
    },
    {
      type: 'NOTIFICATION' as const,
      name: 'App Download Progress',
      title: 'Downloading Update',
      subtitle: '142 MB / 180 MB (78%)',
      accentColorHex: '#30B0C7',
      priority: 'Priority 2',
      icon: Download,
      progress: 0.78,
      autoExpand: false
    },
    {
      type: 'NOTIFICATION' as const,
      name: 'Tasker / Public API Activity',
      title: 'Tasker: Home Arrival',
      subtitle: 'Security armed • 24°C AC set',
      accentColorHex: '#9C27B0',
      priority: 'Priority 3.5 (Public API)',
      icon: Sparkles,
      progress: 0.85,
      autoExpand: true
    }
  ];

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div className="border-b border-zinc-800 pb-4">
        <h2 className="text-xl font-bold text-white">Interactive Test Flight Matrix</h2>
        <p className="text-xs text-zinc-400 mt-1">
          Simulate Android system events, interrupt rules, dual-mode pill splitting, and priority preemption.
        </p>
      </div>

      {/* State Machine Status Bar */}
      <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-3 h-3 rounded-full bg-blue-500 animate-ping" />
          <div>
            <div className="text-xs text-zinc-400 font-mono">CURRENT STATE:</div>
            <div className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              {currentState.type}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {currentState.type === 'DUAL' && (
            <button
              onClick={onSwapDual}
              className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-md transition"
            >
              <ArrowRightLeft className="w-3.5 h-3.5" />
              <span>Swap Dual Activities</span>
            </button>
          )}

          <button
            onClick={onToggleExpand}
            className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-md transition"
          >
            {currentState.type === 'EXPANDED' || currentState.type === 'FULLSCREEN' ? (
              <>
                <Minimize2 className="w-3.5 h-3.5" />
                <span>Collapse</span>
              </>
            ) : (
              <>
                <Maximize className="w-3.5 h-3.5" />
                <span>Expand Card</span>
              </>
            )}
          </button>

          {activeActivities.length > 0 && (
            <button
              onClick={onClearAll}
              className="p-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition"
              title="Clear all activities"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Active Activities Queue */}
      <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800/80 p-5">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-bold text-zinc-300 uppercase tracking-wider">Active Priority Queue ({activeActivities.length})</span>
          <span className="text-[11px] text-zinc-500">Highest priority appears on main pill</span>
        </div>

        {activeActivities.length === 0 ? (
          <div className="text-xs text-zinc-500 py-4 text-center italic">
            Queue is empty. Island is currently in IDLE state. Tap any scenario below to trigger an activity.
          </div>
        ) : (
          <div className="space-y-2">
            {activeActivities.map((act, index) => (
              <div 
                key={act.id} 
                className={`p-3 rounded-xl border flex items-center justify-between ${
                  index === 0 
                    ? 'bg-blue-500/10 border-blue-500/40 text-white' 
                    : index === 1 
                      ? 'bg-purple-500/10 border-purple-500/30 text-zinc-300' 
                      : 'bg-zinc-800/40 border-zinc-700/30 text-zinc-400'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div 
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: act.accentColorHex }}
                  />
                  <div>
                    <div className="text-xs font-bold flex items-center space-x-2">
                      <span>{act.title}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-white/10 font-mono font-normal">
                        {index === 0 ? 'Primary' : index === 1 ? 'Secondary (Dual Bubble)' : 'Queued'}
                      </span>
                    </div>
                    <div className="text-[11px] text-zinc-400">{act.subtitle}</div>
                  </div>
                </div>

                <button
                  onClick={() => onRemoveActivity(act.id)}
                  className="text-xs text-zinc-400 hover:text-red-400 px-2 py-1 rounded hover:bg-white/5 transition"
                >
                  Dismiss
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Trigger Scenarios Grid */}
      <div>
        <h3 className="text-xs font-bold text-zinc-300 uppercase tracking-wider mb-3">Simulate Live Activity Triggers</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {testScenarios.map(sc => {
            const Icon = sc.icon;
            return (
              <button
                key={sc.name}
                onClick={() => onAddActivity({
                  id: `act_${sc.type}_${Date.now()}`,
                  type: sc.type,
                  title: sc.title,
                  subtitle: sc.subtitle,
                  accentColorHex: sc.accentColorHex,
                  iconType: sc.type.toLowerCase(),
                  timestamp: Date.now(),
                  progress: sc.progress
                }, sc.autoExpand)}
                className="p-4 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800/90 border border-zinc-800 hover:border-zinc-700 transition text-left flex items-start space-x-3.5 group shadow-sm"
              >
                <div 
                  className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition group-hover:scale-105"
                  style={{ 
                    backgroundColor: `${sc.accentColorHex}22`,
                    border: `1px solid ${sc.accentColorHex}66`
                  }}
                >
                  <Icon className="w-5 h-5" style={{ color: sc.accentColorHex }} />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-white group-hover:text-blue-400 transition truncate">
                    {sc.name}
                  </div>
                  <div className="text-[11px] text-zinc-400 truncate mt-0.5">
                    {sc.subtitle}
                  </div>
                  <div className="mt-1 flex items-center space-x-2">
                    <span className="text-[10px] text-zinc-500 font-mono">{sc.priority}</span>
                    {sc.autoExpand && (
                      <span className="text-[9px] px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-400 font-semibold">
                        Auto-expands
                      </span>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
