import React, { useState } from 'react';
import { Terminal, Copy, Check, Trash2, Filter } from 'lucide-react';
import { LogEntry } from '../types';

interface DiagnosticsLogViewProps {
  logs: LogEntry[];
  onClearLogs: () => void;
}

export const DiagnosticsLogView: React.FC<DiagnosticsLogViewProps> = ({ logs, onClearLogs }) => {
  const [copied, setCopied] = useState(false);
  const [filterLevel, setFilterLevel] = useState<string>('ALL');

  const filteredLogs = logs.filter(log => {
    if (filterLevel === 'ALL') return true;
    return log.level === filterLevel;
  });

  const copyAllLogs = () => {
    const text = logs.map(l => `${new Date(l.timestamp).toLocaleTimeString()} [${l.level}/${l.tag}] ${l.message}`).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-zinc-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Terminal className="w-5 h-5 text-blue-400" />
            <span>Diagnostics & Ring Buffer Logs</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Real-time state machine transitions, cutout detector calculations, and privileged Shizuku binder calls.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {/* Level filter */}
          <div className="flex items-center bg-zinc-800 rounded-lg p-0.5 text-xs">
            {['ALL', 'INFO', 'WARN', 'ERROR'].map(lvl => (
              <button
                key={lvl}
                onClick={() => setFilterLevel(lvl)}
                className={`px-2 py-1 rounded-md transition ${filterLevel === lvl ? 'bg-zinc-700 text-white font-bold' : 'text-zinc-400 hover:text-zinc-200'}`}
              >
                {lvl}
              </button>
            ))}
          </div>

          <button
            onClick={copyAllLogs}
            className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium flex items-center space-x-1.5 transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>Copy Logs</span>
          </button>

          <button
            onClick={onClearLogs}
            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-red-400 transition"
            title="Clear logs"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="rounded-2xl bg-zinc-950 border border-zinc-800 p-4 h-[480px] overflow-y-auto font-mono text-xs text-zinc-300 space-y-1.5 leading-relaxed">
        {filteredLogs.length === 0 ? (
          <div className="text-zinc-600 text-center py-20 italic">
            No log entries matching filter. Interact with the phone or studio to generate logs.
          </div>
        ) : (
          filteredLogs.map(log => {
            const timeStr = new Date(log.timestamp).toLocaleTimeString();
            const levelColor = 
              log.level === 'ERROR' ? 'text-red-400 font-bold' :
              log.level === 'WARN' ? 'text-amber-400' :
              log.level === 'INFO' ? 'text-blue-400' : 'text-zinc-500';

            return (
              <div key={log.id} className="hover:bg-zinc-900/60 p-1 rounded transition flex items-start space-x-2">
                <span className="text-zinc-500 select-none shrink-0">{timeStr}</span>
                <span className={`shrink-0 w-14 ${levelColor}`}>[{log.level}]</span>
                <span className="text-zinc-400 shrink-0 font-semibold">{log.tag}:</span>
                <span className="text-zinc-200 break-all">{log.message}</span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
