import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Phone, 
  PhoneCall, 
  PhoneOff, 
  Music, 
  Play, 
  Pause, 
  SkipForward, 
  SkipBack, 
  Timer, 
  Bell, 
  Zap, 
  Navigation, 
  Car, 
  Download,
  Wifi,
  Signal,
  Battery,
  Sliders,
  ChevronDown,
  Smartphone
} from 'lucide-react';
import { IslandSettings, IslandState, LiveActivity } from '../types';
import { SmartIslandAppView } from './SmartIslandAppView';

interface VirtualPhoneProps {
  settings: IslandSettings;
  state: IslandState;
  onExpand: () => void;
  onCollapse: () => void;
  onSwapDual: () => void;
  onAction: (action: string) => void;
  onUpdateSettings?: (updater: (prev: IslandSettings) => IslandSettings) => void;
  onTriggerBroadcast?: (activity: LiveActivity) => void;
  screenBg?: string;
  isLandscape?: boolean;
}

export const VirtualPhone: React.FC<VirtualPhoneProps> = ({
  settings,
  state,
  onExpand,
  onCollapse,
  onSwapDual,
  onAction,
  onUpdateSettings,
  onTriggerBroadcast,
  screenBg = 'wallpaper'
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [phoneDisplayMode, setPhoneDisplayMode] = useState<'app_ui' | 'wallpaper'>('app_ui');

  // Derive Spring Transition from Settings
  const getSpringConfig = () => {
    const mult = settings.animationSpeedMultiplier || 1.0;
    switch (settings.animationStyle) {
      case 'IOS_SPRING':
        // Damping 0.72, Stiffness 380
        return { type: 'spring' as const, damping: 22 / mult, stiffness: 380 * mult, mass: 0.9 };
      case 'MATERIAL_EXPRESSIVE':
        return { type: 'spring' as const, damping: 28 / mult, stiffness: 500 * mult, mass: 1.0 };
      case 'BOUNCY':
        return { type: 'spring' as const, damping: 15 / mult, stiffness: 320 * mult, mass: 0.8 };
      case 'SMOOTH_LINEAR':
        return { duration: 0.28 / mult, ease: 'easeInOut' as const };
      case 'MINIMAL':
        return { duration: 0.16 / mult, ease: 'easeOut' as const };
      case 'INSTANT':
        return { duration: 0 };
    }
  };

  const spring = getSpringConfig();

  // Determine pill dimensions based on state
  const getPillDimensions = () => {
    switch (state.type) {
      case 'HIDDEN':
        return { width: 0, height: 0, opacity: 0, scale: 0.8 };
      case 'IDLE':
        return { 
          width: settings.minClosedWidth, 
          height: settings.cutoutHeight, 
          opacity: 1, 
          scale: 1,
          radius: settings.cornerRadius 
        };
      case 'COMPACT':
        return { 
          width: Math.max(settings.minClosedWidth + 80, 210), 
          height: settings.cutoutHeight + 4, 
          opacity: 1, 
          scale: 1,
          radius: settings.cornerRadius + 2 
        };
      case 'DUAL':
        return { 
          width: 175, 
          height: settings.cutoutHeight + 4, 
          opacity: 1, 
          scale: 1,
          radius: settings.cornerRadius + 2 
        };
      case 'EXPANDED':
        return { 
          width: 320, 
          height: 165, 
          opacity: 1, 
          scale: 1,
          radius: 34 
        };
      case 'FULLSCREEN':
        return { 
          width: 334, 
          height: 240, 
          opacity: 1, 
          scale: 1,
          radius: 38 
        };
    }
  };

  const pillDims = getPillDimensions();

  // Current active activity if any
  const primaryActivity: LiveActivity | undefined = 
    state.type === 'COMPACT' || state.type === 'EXPANDED' || state.type === 'FULLSCREEN' 
      ? state.activity 
      : state.type === 'DUAL' 
        ? state.primary 
        : undefined;

  const secondaryActivity: LiveActivity | undefined = 
    state.type === 'DUAL' ? state.secondary : undefined;

  return (
    <div className="relative mx-auto flex flex-col items-center">
      {/* Screen Mode Switcher */}
      <div className="flex items-center gap-1.5 p-1 bg-zinc-900 border border-zinc-800 rounded-2xl text-xs mb-3 shadow-lg">
        <button
          onClick={() => setPhoneDisplayMode('app_ui')}
          className={`py-1.5 px-3 rounded-xl font-bold flex items-center gap-1.5 transition ${
            phoneDisplayMode === 'app_ui' 
              ? 'bg-blue-600 text-white shadow-md' 
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>SmartIsland App UI (Compose)</span>
        </button>
        <button
          onClick={() => setPhoneDisplayMode('wallpaper')}
          className={`py-1.5 px-3 rounded-xl font-bold flex items-center gap-1.5 transition ${
            phoneDisplayMode === 'wallpaper' 
              ? 'bg-zinc-800 text-white shadow-md' 
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Home Launcher Wallpaper</span>
        </button>
      </div>

      {/* Phone Hardware Shell */}
      <div 
        className="relative w-[360px] h-[720px] rounded-[50px] p-3 shadow-2xl transition-all duration-300"
        style={{
          background: 'linear-gradient(145deg, #2b303c 0%, #16181f 40%, #0d0e12 100%)',
          boxShadow: '0 30px 60px -15px rgba(0,0,0,0.85), inset 0 1px 2px rgba(255,255,255,0.2), inset 0 -2px 4px rgba(0,0,0,0.6)'
        }}
      >
        {/* Antenna bands */}
        <div className="absolute top-24 -left-1 w-1 h-5 bg-zinc-600 rounded-sm" />
        <div className="absolute top-36 -left-1 w-1 h-12 bg-zinc-600 rounded-sm" />
        <div className="absolute top-52 -left-1 w-1 h-12 bg-zinc-600 rounded-sm" />
        <div className="absolute top-32 -right-1 w-1 h-16 bg-zinc-600 rounded-sm" />

        {/* Screen Bezel */}
        <div className="relative w-full h-full rounded-[40px] overflow-hidden bg-black flex flex-col border-[4px] border-zinc-950">
          
          {/* Screen Background */}
          <div className="absolute inset-0 z-0">
            {phoneDisplayMode === 'app_ui' ? (
              <div className="w-full h-full pt-12 pb-6 bg-[#121316]">
                <SmartIslandAppView
                  settings={settings}
                  onUpdateSettings={onUpdateSettings || (() => {})}
                  onTriggerBroadcast={onTriggerBroadcast}
                  compactMode={true}
                />
              </div>
            ) : screenBg === 'wallpaper' ? (
              <div 
                className="w-full h-full"
                style={{
                  background: 'radial-gradient(circle at 50% 20%, #1e2638 0%, #0c0f16 65%, #050608 100%)'
                }}
              >
                {/* Subtle wallpaper gradient mesh */}
                <div className="absolute -top-12 -left-12 w-64 h-64 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
                <div className="absolute bottom-16 -right-12 w-64 h-64 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />

                {/* Simulated lockscreen / home clock */}
                <div className="pt-28 text-center select-none">
                  <div className="text-zinc-400 text-xs font-medium tracking-wide">THURSDAY, OCTOBER 29</div>
                  <div className="text-6xl font-light tracking-tight text-white/90 mt-1">09:41</div>
                </div>

                {/* Simulated App Grid */}
                <div className="absolute bottom-12 inset-x-0 px-6">
                  <div className="grid grid-cols-4 gap-4 text-center">
                    {['Phone', 'Messages', 'Browser', 'Camera'].map((name, i) => (
                      <div key={name} className="flex flex-col items-center gap-1.5">
                        <div className="w-12 h-12 rounded-2xl bg-zinc-800/80 border border-zinc-700/40 flex items-center justify-center text-white/80 shadow-md">
                          {i === 0 && <Phone className="w-5 h-5 text-emerald-400" />}
                          {i === 1 && <Bell className="w-5 h-5 text-blue-400" />}
                          {i === 2 && <Navigation className="w-5 h-5 text-amber-400" />}
                          {i === 3 && <Zap className="w-5 h-5 text-purple-400" />}
                        </div>
                        <span className="text-[10px] text-zinc-400">{name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="w-full h-full bg-zinc-950 flex items-center justify-center">
                <div className="text-zinc-600 text-xs text-center p-4">
                  Full-screen video / app mode active.
                  {settings.hideInFullscreen && <div className="text-blue-400 mt-1">Auto-hide policy active.</div>}
                </div>
              </div>
            )}
          </div>

          {/* Status Bar */}
          <div className="relative z-10 w-full h-11 px-6 flex items-center justify-between text-xs text-white/80 select-none">
            <span className="font-semibold text-xs pl-1">09:41</span>
            
            {/* Status Icons Right */}
            <div className="flex items-center space-x-1.5 text-white/80 pr-1">
              <Signal className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <div className="flex items-center">
                <span className="text-[10px] font-bold mr-0.5">85%</span>
                <Battery className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Hardware Cutout Simulator (Behind the Island) */}
          <div 
            className="absolute z-20 pointer-events-none flex items-center justify-center"
            style={{
              top: `${settings.topYOffset}px`,
              left: `calc(50% + ${settings.centreXOffset}px)`,
              transform: 'translateX(-50%)'
            }}
          >
            {settings.cutoutHoleShape === 'CENTER_HOLE' && (
              <div className="w-3.5 h-3.5 rounded-full bg-black border border-zinc-900/50 shadow-inner" />
            )}
            {settings.cutoutHoleShape === 'PILL_HOLE' && (
              <div className="w-9 h-3.5 rounded-full bg-black border border-zinc-900/50 shadow-inner" />
            )}
          </div>

          {/* DYNAMIC ISLAND ROOT CONTAINER */}
          {settings.enabled && state.type !== 'HIDDEN' && (
            <div 
              className="absolute z-30 flex items-center justify-center w-full select-none"
              style={{
                top: `${settings.topYOffset}px`,
                transform: `translateX(${settings.centreXOffset}px)`
              }}
            >
              <div className="relative flex items-center justify-center">
                
                {/* Main Dynamic Pill */}
                <motion.div
                  layout
                  transition={spring}
                  animate={{
                    width: pillDims.width,
                    height: pillDims.height,
                    borderRadius: pillDims.radius,
                    scale: pillDims.scale,
                    opacity: pillDims.opacity
                  }}
                  onClick={() => {
                    if (state.type === 'EXPANDED' || state.type === 'FULLSCREEN') {
                      onCollapse();
                    } else {
                      onExpand();
                    }
                  }}
                  className="relative bg-black flex items-center justify-between cursor-pointer overflow-hidden"
                  style={{
                    boxShadow: settings.ambientShadow 
                      ? '0 10px 30px -5px rgba(0, 0, 0, 0.9), 0 0 1px 1px rgba(255, 255, 255, 0.12)' 
                      : 'none',
                    border: settings.showOutlineBorder 
                      ? '1px solid rgba(255, 255, 255, 0.12)' 
                      : 'none'
                  }}
                >
                  {/* Glowing Flash Border if enabled */}
                  {settings.showGlowFlash && primaryActivity && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: [0, 0.8, 0.2] }}
                      transition={{ duration: 1.2, repeat: Infinity, repeatType: 'reverse' }}
                      className="absolute inset-0 rounded-inherit pointer-events-none"
                      style={{
                        boxShadow: `inset 0 0 12px 1px ${primaryActivity.accentColorHex}`
                      }}
                    />
                  )}

                  {/* IDLE STATE: Sleek Camera Pill or Split Pill */}
                  {state.type === 'IDLE' && (
                    state.isSplitPill ? (
                      <div className="w-full h-full flex items-center justify-between px-3 text-white text-[10px] font-bold">
                        <span className="bg-white/10 px-2 py-0.5 rounded-full font-mono">10:41</span>
                        <div className="w-2.5 h-2.5 rounded-full bg-zinc-900 shadow-inner" />
                        <span className="text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">85%</span>
                      </div>
                    ) : (
                      <div className="w-full h-full flex items-center justify-between px-3">
                        <div className="w-2.5 h-2.5 rounded-full bg-zinc-900/90 shadow-inner" />
                        <div className="text-[10px] text-zinc-300 font-medium tracking-tight truncate max-w-[150px]">
                          {state.widgetText || '10:41 • WED 24 OCT'}
                        </div>
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_6px_#10b981]" />
                      </div>
                    )
                  )}

                  {/* COMPACT & DUAL (PRIMARY) PILL */}
                  {(state.type === 'COMPACT' || state.type === 'DUAL') && primaryActivity && (
                    <div className="w-full h-full flex items-center justify-between px-3 text-white">
                      {/* Leading Badge / Icon */}
                      <div className="flex items-center space-x-2">
                        <div 
                          className="w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold"
                          style={{ backgroundColor: primaryActivity.accentColorHex }}
                        >
                          {primaryActivity.type === 'CALL' && <Phone className="w-2.5 h-2.5 text-white" />}
                          {primaryActivity.type === 'MEDIA' && <Music className="w-2.5 h-2.5 text-white" />}
                          {primaryActivity.type === 'TIMER' && <Timer className="w-2.5 h-2.5 text-white" />}
                          {primaryActivity.type === 'CHARGING' && <Zap className="w-2.5 h-2.5 text-black" />}
                          {primaryActivity.type === 'NOTIFICATION' && <Bell className="w-2.5 h-2.5 text-white" />}
                          {primaryActivity.type === 'NAVIGATION' && <Navigation className="w-2.5 h-2.5 text-white" />}
                          {primaryActivity.type === 'RIDE' && <Car className="w-2.5 h-2.5 text-white" />}
                          {primaryActivity.type === 'WEATHER' && <span className="text-[8px]">☀️</span>}
                          {primaryActivity.type === 'CALENDAR' && <span className="text-[8px]">📅</span>}
                          {primaryActivity.type === 'QUICK_LAUNCHER' && <Sliders className="w-2.5 h-2.5 text-white" />}
                        </div>
                        <span className="text-[11px] font-semibold truncate max-w-[100px]">
                          {primaryActivity.title}
                        </span>
                      </div>

                      {/* Trailing Subtitle or Wave */}
                      <div className="flex items-center pl-1">
                        {primaryActivity.type === 'MEDIA' ? (
                          <div className="flex items-center space-x-0.5">
                            {[12, 6, 14, 8].map((h, i) => (
                              <motion.div
                                key={i}
                                animate={{ height: [4, h, 3] }}
                                transition={{ repeat: Infinity, duration: 0.6 + i * 0.15, repeatType: 'reverse' }}
                                className="w-[2.5px] rounded-full"
                                style={{ backgroundColor: primaryActivity.accentColorHex }}
                              />
                            ))}
                          </div>
                        ) : (
                          <span className="text-[10px] text-zinc-400 font-mono">
                            {primaryActivity.subtitle}
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  {/* EXPANDED RICH CARD */}
                  {(state.type === 'EXPANDED' || state.type === 'FULLSCREEN') && primaryActivity && (
                    <div className="w-full h-full flex flex-col justify-between p-4 text-white">
                      {/* Header Row */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div 
                            className="w-10 h-10 rounded-2xl flex items-center justify-center shadow-lg"
                            style={{ 
                              backgroundColor: `${primaryActivity.accentColorHex}33`,
                              border: `1px solid ${primaryActivity.accentColorHex}88`
                            }}
                          >
                            {primaryActivity.type === 'CALL' && <PhoneCall className="w-5 h-5 text-emerald-400" />}
                            {primaryActivity.type === 'MEDIA' && <Music className="w-5 h-5 text-pink-400" />}
                            {primaryActivity.type === 'TIMER' && <Timer className="w-5 h-5 text-amber-400" />}
                            {primaryActivity.type === 'CHARGING' && <Zap className="w-5 h-5 text-yellow-400" />}
                            {primaryActivity.type === 'NOTIFICATION' && <Bell className="w-5 h-5 text-blue-400" />}
                            {primaryActivity.type === 'NAVIGATION' && <Navigation className="w-5 h-5 text-blue-400" />}
                            {primaryActivity.type === 'RIDE' && <Car className="w-5 h-5 text-emerald-400" />}
                            {primaryActivity.type === 'WEATHER' && <span className="text-xl">☀️</span>}
                            {primaryActivity.type === 'CALENDAR' && <span className="text-xl">📅</span>}
                            {primaryActivity.type === 'QUICK_LAUNCHER' && <Sliders className="w-5 h-5 text-blue-400" />}
                          </div>
                          <div>
                            <div className="text-sm font-bold tracking-tight">{primaryActivity.title}</div>
                            <div className="text-xs text-zinc-400 font-medium">{primaryActivity.subtitle}</div>
                          </div>
                        </div>

                        {/* Swipe up indicator / collapse */}
                        <button 
                          onClick={(e) => { e.stopPropagation(); onCollapse(); }}
                          className="w-6 h-6 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition"
                          title="Collapse Island"
                        >
                          <ChevronDown className="w-3.5 h-3.5 text-zinc-300" />
                        </button>
                      </div>

                      {/* Progress bar if present */}
                      {primaryActivity.progress !== undefined && (
                        <div className="w-full my-2">
                          <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                            <div 
                              className="h-full rounded-full transition-all"
                              style={{ 
                                width: `${(primaryActivity.progress || 0.45) * 100}%`,
                                backgroundColor: primaryActivity.accentColorHex 
                              }}
                            />
                          </div>
                        </div>
                      )}

                      {/* Card Action Controls */}
                      <div className="pt-2">
                        {primaryActivity.type === 'CALL' && (
                          <div className="flex items-center space-x-2">
                            <button 
                              onClick={(e) => { e.stopPropagation(); onAction('answer'); onCollapse(); }}
                              className="flex-1 py-2 bg-emerald-500 hover:bg-emerald-600 rounded-xl text-xs font-bold flex items-center justify-center space-x-1 transition shadow-md"
                            >
                              <Phone className="w-3.5 h-3.5" />
                              <span>Answer</span>
                            </button>
                            <button 
                              onClick={(e) => { e.stopPropagation(); onAction('decline'); onCollapse(); }}
                              className="flex-1 py-2 bg-red-500 hover:bg-red-600 rounded-xl text-xs font-bold flex items-center justify-center space-x-1 transition shadow-md"
                            >
                              <PhoneOff className="w-3.5 h-3.5" />
                              <span>Decline</span>
                            </button>
                          </div>
                        )}

                        {primaryActivity.type === 'MEDIA' && (
                          <div className="flex items-center justify-between px-3 py-1">
                            <button 
                              onClick={(e) => { e.stopPropagation(); onAction('prev'); }}
                              className="p-1.5 text-zinc-400 hover:text-white transition"
                            >
                              <SkipBack className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={(e) => { 
                                e.stopPropagation(); 
                                setIsPlaying(!isPlaying);
                                onAction('play_pause'); 
                              }}
                              className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 transition shadow-lg"
                            >
                              {isPlaying ? <Pause className="w-4 h-4 fill-black" /> : <Play className="w-4 h-4 fill-black ml-0.5" />}
                            </button>
                            <button 
                              onClick={(e) => { e.stopPropagation(); onAction('next'); }}
                              className="p-1.5 text-zinc-400 hover:text-white transition"
                            >
                              <SkipForward className="w-4 h-4" />
                            </button>
                          </div>
                        )}

                        {primaryActivity.type !== 'CALL' && primaryActivity.type !== 'MEDIA' && (
                          <div className="flex items-center space-x-2">
                            <button 
                              onClick={(e) => { e.stopPropagation(); onCollapse(); }}
                              className="w-full py-2 bg-white/10 hover:bg-white/15 rounded-xl text-xs font-medium text-zinc-300 transition"
                            >
                              Dismiss to Pill
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </motion.div>

                {/* Detached Bubble for Dual Mode (secondary activity) */}
                {state.type === 'DUAL' && secondaryActivity && (
                  <motion.div
                    layout
                    transition={spring}
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSwapDual();
                    }}
                    title="Tap to swap active activities"
                    className="ml-2 w-9 h-9 rounded-full bg-black flex items-center justify-center cursor-pointer border border-white/10 hover:border-white/30 transition shadow-lg"
                    style={{
                      boxShadow: '0 8px 20px rgba(0,0,0,0.8)'
                    }}
                  >
                    <div 
                      className="w-4 h-4 rounded-full flex items-center justify-center text-[10px]"
                      style={{ backgroundColor: secondaryActivity.accentColorHex }}
                    >
                      {secondaryActivity.type === 'CALL' && <Phone className="w-2.5 h-2.5 text-white" />}
                      {secondaryActivity.type === 'MEDIA' && <Music className="w-2.5 h-2.5 text-white" />}
                      {secondaryActivity.type === 'TIMER' && <Timer className="w-2.5 h-2.5 text-white" />}
                      {secondaryActivity.type === 'CHARGING' && <Zap className="w-2.5 h-2.5 text-black" />}
                      {secondaryActivity.type === 'NOTIFICATION' && <Bell className="w-2.5 h-2.5 text-white" />}
                    </div>
                  </motion.div>
                )}
              </div>
            </div>
          )}

          {/* Android Home Navigation Bar */}
          <div className="absolute bottom-2 inset-x-0 flex justify-center z-10 pointer-events-none">
            <div className="w-32 h-1 bg-white/50 rounded-full" />
          </div>
        </div>
      </div>
      
      {/* Device Label */}
      <div className="mt-3 text-xs text-zinc-400 flex items-center space-x-2">
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        <span>Hardware Cutout Mode: <b>{settings.displayMode}</b> • Spring: <b>{settings.animationStyle}</b></span>
      </div>
    </div>
  );
};
