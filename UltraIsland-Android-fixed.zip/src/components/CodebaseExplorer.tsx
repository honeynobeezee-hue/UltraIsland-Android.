import React, { useState } from 'react';
import JSZip from 'jszip';
import { 
  FileCode, 
  FolderTree, 
  Download, 
  Copy, 
  Check, 
  Terminal, 
  ChevronRight, 
  FileCheck2, 
  Folder, 
  ExternalLink 
} from 'lucide-react';
import { ANDROID_FILES } from '../data/androidFiles';
import { AndroidCodeFile } from '../types';

export const CodebaseExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidCodeFile>(ANDROID_FILES[3]); // app/build.gradle.kts
  const [copied, setCopied] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [copiedCli, setCopiedCli] = useState<string | null>(null);

  const copyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const copyCliCommand = (cmd: string, id: string) => {
    navigator.clipboard.writeText(cmd);
    setCopiedCli(id);
    setTimeout(() => setCopiedCli(null), 2000);
  };

  // Generate downloadable Android project ZIP using JSZip
  const downloadAndroidZip = async () => {
    try {
      setIsExporting(true);
      const zip = new JSZip();

      // Add all files
      ANDROID_FILES.forEach(file => {
        zip.file(file.path, file.content);
      });

      // Add README.md with build instructions
      const readme = `# UltraIsland Pro (Complete Production Suite - Phases 0 to 7)

Next-Generation Dynamic Island, Live Activities & Privileged Tools Engine for Android 8–16.
Superset combining features of SmartIsland, Island, Islandify, OmniLand, ExpressiveCutout, and Tooler.

## How to Build

1. Open this folder in Android Studio (Ladybug / Iguana or newer) with JDK 17+.
2. Run \`./gradlew assembleDebug\` to build the debug APK, or \`./gradlew assembleRelease\` for production.
3. Install to device:
   \`\`\`bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   \`\`\`

## Permissions Setup via ADB & Shizuku

- Grant WRITE_SECURE_SETTINGS (for system tweaks & Quick Tools):
  \`\`\`bash
  adb shell pm grant com.ultraisland.pro android.permission.WRITE_SECURE_SETTINGS
  \`\`\`

- Enable Accessibility Service (primary zero-permission-dialog overlay):
  \`\`\`bash
  adb shell settings put secure enabled_accessibility_services com.ultraisland.pro/com.ultraisland.pro.services.accessibility.IslandAccessibilityService
  adb shell settings put secure accessibility_enabled 1
  \`\`\`

- Grant System Alert Window (fallback overlay):
  \`\`\`bash
  adb shell appops set com.ultraisland.pro SYSTEM_ALERT_WINDOW allow
  \`\`\`

- Whitelist battery optimization:
  \`\`\`bash
  adb shell dumpsys deviceidle whitelist +com.ultraisland.pro
  \`\`\`
`;
      zip.file('README.md', readme);

      // Generate blob & trigger download
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'UltraIslandPro_FullSuite_Project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Error generating zip:', e);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header and Download CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-zinc-800 pb-5">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-md">
              100% Complete Production Code
            </span>
            <span className="text-xs text-zinc-400">14 Files • Kotlin 2.1 • Compose M3</span>
          </div>
          <h2 className="text-xl font-bold text-white mt-1">Android Project Source Tree</h2>
          <p className="text-xs text-zinc-400">
            Phase 0 (Skeleton, Architecture, Shizuku, Settings) & Phase 1 (Overlay Engine, Cutout Detection, State Machine, Spring Animations)
          </p>
        </div>

        <button
          onClick={downloadAndroidZip}
          disabled={isExporting}
          className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center space-x-2 shadow-lg hover:shadow-blue-500/20 transition disabled:opacity-50"
        >
          <Download className="w-4 h-4" />
          <span>{isExporting ? 'Generating ZIP...' : 'Download Full Android Project (.ZIP)'}</span>
        </button>
      </div>

      {/* Terminal CLI instructions */}
      <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/80 font-mono text-xs space-y-2">
        <div className="flex items-center justify-between text-zinc-400 font-sans text-[11px] font-bold uppercase tracking-wider mb-1">
          <span className="flex items-center space-x-1.5">
            <Terminal className="w-3.5 h-3.5 text-blue-400" />
            <span>Gradle & ADB Quick Commands</span>
          </span>
          <span className="text-zinc-500">Run in terminal</span>
        </div>

        <div className="flex items-center justify-between bg-zinc-900/90 rounded-xl px-3 py-2 border border-zinc-800 text-zinc-200">
          <span className="truncate pr-2">./gradlew assembleDebug</span>
          <button 
            onClick={() => copyCliCommand('./gradlew assembleDebug', 'build')}
            className="text-zinc-400 hover:text-white transition"
          >
            {copiedCli === 'build' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>

        <div className="flex items-center justify-between bg-zinc-900/90 rounded-xl px-3 py-2 border border-zinc-800 text-zinc-200">
          <span className="truncate pr-2">adb install -r app/build/outputs/apk/debug/app-debug.apk</span>
          <button 
            onClick={() => copyCliCommand('adb install -r app/build/outputs/apk/debug/app-debug.apk', 'install')}
            className="text-zinc-400 hover:text-white transition"
          >
            {copiedCli === 'install' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Code Browser Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
        
        {/* Left: File Tree (4 cols) */}
        <div className="md:col-span-5 rounded-2xl bg-zinc-900/70 border border-zinc-800 p-3 max-h-[580px] overflow-y-auto space-y-1">
          <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-zinc-400 border-b border-zinc-800 mb-1 flex items-center justify-between">
            <span>Project Explorer</span>
            <span className="text-zinc-500">{ANDROID_FILES.length} files</span>
          </div>

          {ANDROID_FILES.map(file => {
            const isSelected = selectedFile.path === file.path;
            return (
              <button
                key={file.path}
                onClick={() => setSelectedFile(file)}
                className={`w-full text-left p-2.5 rounded-xl text-xs transition flex items-center justify-between ${
                  isSelected
                    ? 'bg-blue-600/20 text-white border border-blue-500/40 font-medium'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
                }`}
              >
                <div className="flex items-center space-x-2 truncate">
                  <FileCode className={`w-4 h-4 shrink-0 ${isSelected ? 'text-blue-400' : 'text-zinc-500'}`} />
                  <span className="truncate">{file.path}</span>
                </div>
                <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-mono ${
                  file.language === 'kotlin' ? 'bg-purple-500/10 text-purple-400' : 'bg-zinc-800 text-zinc-400'
                }`}>
                  {file.language}
                </span>
              </button>
            );
          })}
        </div>

        {/* Right: Code Viewer (7 cols) */}
        <div className="md:col-span-7 rounded-2xl bg-zinc-950 border border-zinc-800 overflow-hidden flex flex-col max-h-[580px]">
          {/* File bar */}
          <div className="px-4 py-3 bg-zinc-900/80 border-b border-zinc-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-white font-mono flex items-center space-x-1.5">
                <span>{selectedFile.path}</span>
              </div>
              <div className="text-[11px] text-zinc-400 mt-0.5">{selectedFile.description}</div>
            </div>

            <button
              onClick={copyCode}
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium flex items-center space-x-1.5 transition shrink-0"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>

          {/* Code Text Content */}
          <div className="p-4 overflow-auto flex-1 font-mono text-xs text-zinc-300 leading-relaxed bg-zinc-950/90">
            <pre className="whitespace-pre">
              {selectedFile.content.split('\n').map((line, idx) => (
                <div key={idx} className="table-row">
                  <span className="table-cell pr-4 text-zinc-600 select-none text-right w-8">
                    {idx + 1}
                  </span>
                  <span className="table-cell">{line}</span>
                </div>
              ))}
            </pre>
          </div>
        </div>

      </div>
    </div>
  );
};
