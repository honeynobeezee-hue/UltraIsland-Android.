# UltraIsland Pro ProGuard Rules
-keep class dev.rikka.shizuku.** { *; }
-dontwarn dev.rikka.shizuku.**
