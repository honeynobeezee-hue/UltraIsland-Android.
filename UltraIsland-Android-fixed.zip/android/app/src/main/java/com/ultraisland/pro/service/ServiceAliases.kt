package com.ultraisland.pro.service

/**
 * Kode util hasil port SmartIsland merujuk ke service dengan nama lama. Di proyek ini service-nya
 * adalah IslandAccessibilityService (overlay) dan IslandNotificationListener; alias ini menyambungkannya
 * tanpa menduplikasi service.
 */
typealias UltraIslandOverlayService = com.ultraisland.pro.services.accessibility.IslandAccessibilityService
typealias UltraIslandNotificationListenerService = com.ultraisland.pro.services.notification.IslandNotificationListener
