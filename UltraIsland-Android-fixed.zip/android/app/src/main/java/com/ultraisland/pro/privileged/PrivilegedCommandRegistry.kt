package com.ultraisland.pro.privileged

import java.util.regex.Pattern

object PrivilegedCommandRegistry {

    private val PACKAGE_NAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_.]+$")

    // Command Whitelist definitions
    const val CMD_SCREENSHOT = "input keyevent 120"
    const val CMD_LOCK_SCREEN = "input keyevent 26"
    const val CMD_NAV_BACK = "input keyevent 4"
    const val CMD_NAV_HOME = "input keyevent 3"
    const val CMD_NAV_RECENTS = "input keyevent 187"

    const val CMD_WIFI_ENABLE = "svc wifi enable"
    const val CMD_WIFI_DISABLE = "svc wifi disable"
    const val CMD_BT_ENABLE = "svc bluetooth enable"
    const val CMD_BT_DISABLE = "svc bluetooth disable"

    const val CMD_AIRPLANE_ON = "settings put global airplane_mode_on 1 && am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true"
    const val CMD_AIRPLANE_OFF = "settings put global airplane_mode_on 0 && am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false"

    const val CMD_STAY_ON_ENABLE = "svc power stayon true"
    const val CMD_STAY_ON_DISABLE = "svc power stayon false"

    const val CMD_GRAYSCALE_ENABLE = "settings put secure accessibility_display_daltonizer_enabled 1 && settings put secure accessibility_display_daltonizer 0"
    const val CMD_GRAYSCALE_DISABLE = "settings put secure accessibility_display_daltonizer_enabled 0"

    const val CMD_HEADS_UP_DISABLE = "settings put global heads_up_notifications_enabled 0"
    const val CMD_HEADS_UP_ENABLE = "settings put global heads_up_notifications_enabled 1"

    fun cmdAntiKill(pkg: String = "com.ultraisland.pro"): List<String> {
        val safePkg = if (PACKAGE_NAME_PATTERN.matcher(pkg).matches()) pkg else "com.ultraisland.pro"
        return listOf(
            "dumpsys deviceidle whitelist +$safePkg",
            "appops set $safePkg RUN_ANY_IN_BACKGROUND allow",
            "appops set $safePkg RECEIVE_SENSITIVE_NOTIFICATIONS allow",
            "am set-standby-bucket $safePkg active"
        )
    }

    fun cmdPrivateDns(mode: String, specifier: String? = null): String {
        return when (mode.lowercase()) {
            "off" -> "settings put global private_dns_mode off"
            "opportunistic", "auto" -> "settings put global private_dns_mode opportunistic"
            "hostname" -> {
                val safeHost = specifier?.filter { it.isLetterOrDigit() || it == '.' || it == '-' } ?: "dns.quad9.net"
                "settings put global private_dns_mode hostname && settings put global private_dns_specifier $safeHost"
            }
            else -> "settings put global private_dns_mode opportunistic"
        }
    }

    fun cmdForceStop(pkg: String): String? {
        if (!PACKAGE_NAME_PATTERN.matcher(pkg).matches()) return null
        return "am force-stop $pkg"
    }

    fun isCommandAllowed(command: String): Boolean {
        val trimmed = command.trim()
        if (trimmed == CMD_SCREENSHOT ||
            trimmed == CMD_LOCK_SCREEN ||
            trimmed == CMD_NAV_BACK ||
            trimmed == CMD_NAV_HOME ||
            trimmed == CMD_NAV_RECENTS ||
            trimmed == CMD_WIFI_ENABLE ||
            trimmed == CMD_WIFI_DISABLE ||
            trimmed == CMD_BT_ENABLE ||
            trimmed == CMD_BT_DISABLE ||
            trimmed == CMD_AIRPLANE_ON ||
            trimmed == CMD_AIRPLANE_OFF ||
            trimmed == CMD_STAY_ON_ENABLE ||
            trimmed == CMD_STAY_ON_DISABLE ||
            trimmed == CMD_GRAYSCALE_ENABLE ||
            trimmed == CMD_GRAYSCALE_DISABLE ||
            trimmed == CMD_HEADS_UP_DISABLE ||
            trimmed == CMD_HEADS_UP_ENABLE
        ) return true

        if (trimmed.startsWith("dumpsys deviceidle whitelist +") ||
            trimmed.startsWith("appops set ") ||
            trimmed.startsWith("am set-standby-bucket ") ||
            trimmed.startsWith("settings put global private_dns_") ||
            trimmed.startsWith("am force-stop ") ||
            trimmed.startsWith("settings put ")
        ) {
            // Verify no command injection characters like semicolon, pipe, ampersand (except predefined)
            val sub = trimmed.replace("&&", "").trim()
            if (!sub.contains(";") && !sub.contains("|") && !sub.contains("`") && !sub.contains("$")) {
                return true
            }
        }

        return false
    }
}
