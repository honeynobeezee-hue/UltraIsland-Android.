package com.ultraisland.pro.ui.fonts

import androidx.compose.runtime.State
import com.ultraisland.pro.model.IdleSlots
import com.ultraisland.pro.model.IdleWidgetKind
import com.ultraisland.pro.model.IdleWidgets
import com.ultraisland.pro.model.LedTickConfig
import com.ultraisland.pro.model.WeatherPill
import com.ultraisland.pro.util.IdleWidgetData

/**
 * Idle widgets on the collapsed cutout (portrait pill and landscape circle) while no event is on the island.
 * What is shown is chosen in Layout > Idle widgets; the values come from [rememberIdleWidgetData].
 *
 * Wide pill (portrait): an icon in the left slot and the value in the right slot, like every other event, so the camera hole in the
 * middle stays clear. Small circle (landscape): only the value, centred, in small type.
 */
class IdleWidgetFrame(
    val kind: IdleWidgetKind,
    val data: IdleWidgetData,
    val fahrenheit: Boolean,
    val compact: Boolean,
    /** 0..1: the widget fades in once the cutout has settled at its idle size. Read where it is drawn, so the fade does not recompose. */
    val appear: State<Float>,
    /** Font of the pill's glyph text; null = the island font. */
    val glyphFont: androidx.compose.ui.text.font.FontFamily? = null,
    val glyphScale: Float = 1f,
    /** The widget on the pill was just changed by the automatic timer (not by a swipe): the glyphs travel left to right in three ticks. */
    val autoSwitch: Boolean = false,
    /** Milliseconds between the sideways ticks of the glyphs (Settings > Idle widgets). */
    val tickPeriodMs: Long = IdleSlots.SIDE_TICK_PERIOD_MS,
    /** The LED footsteps tick (Settings > Idle widgets > Tick style): null = the smooth tick. See ui/LedTickSlot.kt. */
    val led: LedTickConfig? = null,
    /** The wind speed unit to draw (already resolved from Auto): see [IdleWidgets.resolveWindUnit]. */
    val windUnit: String = IdleWidgets.WIND_KMH,
    val weatherMode: String = WeatherPill.TEMP_ICON,
    val weatherReadouts: List<String> = emptyList(),
    /** False keeps the weather glyph still (turned off, Battery Saver, or the system's "remove animations"). */
    val weatherAnimate: Boolean = true,
    /** "Beat only when a value changes" (Settings > Idle widgets): the sideways beat waits for a change, see [IdleSlots.beatDue]. */
    val beatOnlyOnChange: Boolean = false,
    /**
     * True while the pill cannot be seen (the widget island is open over it): the beat waits and starts again in step
     * when the pill is back.
     */
    val beatPaused: Boolean = false,
    /** False under Battery Saver or the system's "remove animations": every tick is a plain cross-fade, see [IdleSlots.ticksAnimate]. */
    val tickAnimates: Boolean = true,
    /**
     * [android.os.SystemClock.elapsedRealtime] of the last widget switch (automatic or swipe): the beat stays out of
     * the switch, see [IdleSlots.beatClearOfSwitch].
     */
    val lastSwitchAtMs: Long = 0L,
    /** The same clock at the start of the automatic timer's current wait, and that wait's length (0 = no automatic switching). */
    val cycleStartAtMs: Long = 0L,
    val cycleMs: Long = 0L
)

/**
 * The same data and unit as this frame, for another [kind], always as the wide (non-compact) layout. Used by the
 * semi-expanded widget island.
 */
internal fun IdleWidgetFrame.asWide(kind: IdleWidgetKind): IdleWidgetFrame =
    IdleWidgetFrame(
        kind = kind, data = data, fahrenheit = fahrenheit, compact = false, appear = appear,
        glyphFont = glyphFont, glyphScale = glyphScale, tickPeriodMs = tickPeriodMs, led = led, windUnit = windUnit,
        weatherMode = weatherMode, weatherReadouts = weatherReadouts, weatherAnimate = weatherAnimate,
        beatOnlyOnChange = beatOnlyOnChange, beatPaused = beatPaused, tickAnimates = tickAnimates
    )

