package com.ultraisland.pro.services.notification

import android.util.Log
import com.ultraisland.pro.privileged.PrivilegedManager

object HeadsUpManager {
    private const val TAG = "HeadsUpManager"
    private var originalState: String? = null

    suspend fun setSystemHeadsUpEnabled(enabled: Boolean): Boolean {
        val bridge = PrivilegedManager.getActiveBridge()
        if (!bridge.hasPermission()) {
            Log.w(TAG, "Cannot modify heads-up setting without privileged permissions")
            return false
        }

        try {
            if (originalState == null) {
                // Save original value
                val current = bridge.exec("settings get global heads_up_notifications_enabled")
                if (current.isSuccess) {
                    originalState = current.getOrNull()?.trim()
                    Log.i(TAG, "Saved original system heads_up state: $originalState")
                }
            }

            val targetVal = if (enabled) "1" else "0"
            val res = bridge.exec("settings put global heads_up_notifications_enabled $targetVal")
            return res.isSuccess
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle system heads-up", e)
            return false
        }
    }

    suspend fun restoreOriginalState(): Boolean {
        val original = originalState ?: "1"
        val bridge = PrivilegedManager.getActiveBridge()
        return if (bridge.hasPermission()) {
            val res = bridge.exec("settings put global heads_up_notifications_enabled $original")
            Log.i(TAG, "Restored system heads_up state to $original")
            res.isSuccess
        } else {
            false
        }
    }
}
