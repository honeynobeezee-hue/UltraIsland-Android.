/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.ultraisland.pro.ui.sections

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ClearAll
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Close
import com.ultraisland.pro.ui.glass.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import com.ultraisland.pro.ui.glass.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import kotlinx.coroutines.flow.MutableStateFlow
import com.ultraisland.pro.model.IslandNotification
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ultraisland.pro.data.INotificationRepository
import com.ultraisland.pro.data.UltraIslandSettings
import com.ultraisland.pro.model.IslandEvent
import com.ultraisland.pro.ui.components.CollapsibleCard
import com.ultraisland.pro.util.DemoEvents
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

/**
 * Demo tab: a button per island event that puts a sample card on the island, so every cutout, expanded card and
 * switch can be tried at any time. Sample cards never touch the system shade.
 */
@Composable
fun DemoSection(
    settings: UltraIslandSettings,
    notificationRepository: INotificationRepository?
) {
    val context = LocalContext.current
    var openExpanded by rememberSaveable { mutableStateOf(true) }
    val noCards = remember { MutableStateFlow<List<IslandNotification>>(emptyList()) }
    val cards by (notificationRepository?.notifications ?: noCards).collectAsState()
    val showingKeys = cards.filter { DemoEvents.isDemoKey(it.key) }.map { it.key }.toSet()

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Sample cards",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = when {
                        notificationRepository == null -> "The island is not ready yet. Open the app again."
                        !settings.enabled -> "The island is off. Turn it on from the Home tab, then tap a button to see that card."
                        else -> "Tap Show to put a sample card on the island. Short events leave by themselves; " +
                            "the others stay until you clear them. Events switched off on the Home tab stay hidden."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Open the card expanded",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(checked = openExpanded, onCheckedChange = { openExpanded = it })
                }
                FilledTonalButton(
                    onClick = { notificationRepository?.let { DemoEvents.clearAll(it) } },
                    enabled = notificationRepository != null && showingKeys.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.ClearAll, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (showingKeys.isEmpty()) "No demo cards showing" else "Clear all demo cards (${showingKeys.size})")
                }
            }
        }

        DemoEvents.available.filter { it != IslandEvent.FACE_UNLOCK }.groupBy { it.group }.entries.forEachIndexed { index, (group, events) ->
            val showingCount = events.count { DemoEvents.keyFor(it) in showingKeys }
            CollapsibleCard(
                title = group,
                stateKey = "demo_group_$group",
                summary = if (showingCount > 0) "$showingCount showing" else "${events.size} samples",
                icon = iconFor(events.first()),
                initiallyExpanded = false
            ) {
                events.forEachIndexed { rowIndex, event ->
                    if (rowIndex > 0) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
                    }
                    val showing = DemoEvents.keyFor(event) in showingKeys
                    val off = !settings.isEventEnabled(event.id)
                    DemoRow(
                        title = event.label,
                        subtitle = if (off) "Switched off on the Home tab" else null,
                        event = event,
                        showing = showing,
                        enabled = notificationRepository != null,
                        onShow = {
                            notificationRepository?.let { DemoEvents.show(context, it, event, openExpanded, settings.batteryWarningMs.toLong()) }
                        },
                        onClear = {
                            notificationRepository?.let { DemoEvents.clear(it, event) }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun DemoRow(
    title: String,
    subtitle: String?,
    event: IslandEvent,
    showing: Boolean,
    enabled: Boolean,
    onShow: () -> Unit,
    onClear: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (showing) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = iconFor(event),
                    contentDescription = null,
                    tint = if (showing) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.size(18.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        if (showing) {
            IconButton(onClick = onClear, enabled = enabled) {
                Icon(Icons.Rounded.Close, contentDescription = "Clear $title")
            }
        } else {
            FilledTonalButton(onClick = onShow, enabled = enabled) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Show")
            }
        }
    }
}
