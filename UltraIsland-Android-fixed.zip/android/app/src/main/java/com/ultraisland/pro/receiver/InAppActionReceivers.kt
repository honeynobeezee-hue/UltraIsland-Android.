package com.ultraisland.pro.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ultraisland.pro.util.InAppStopwatch
import com.ultraisland.pro.util.InAppTimer

/** Menerima tombol aksi (jeda/lanjut/reset) dari notifikasi timer in-app. */
class TimerActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        InAppTimer.handle(context, intent.action)
    }
}

/** Menerima tombol aksi (lap/toggle/reset) dari notifikasi stopwatch in-app. */
class StopwatchActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        InAppStopwatch.handle(context, intent.action)
    }
}
