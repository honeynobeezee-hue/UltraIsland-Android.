package com.ultraisland.pro

import android.app.Application
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.engine.idle.IdleWidgetManager
import com.ultraisland.pro.privileged.PrivilegedManager
import com.ultraisland.pro.services.media.MediaSessionTracker
import com.ultraisland.pro.services.network.NetworkSpeedTracker
import com.ultraisland.pro.services.system.PrivacyTracker
import com.ultraisland.pro.services.system.SoundAndDeviceTracker
import com.ultraisland.pro.services.telephony.CallManager
import com.ultraisland.pro.services.timer.TimerManager
import com.ultraisland.pro.services.weather.WeatherManager
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@HiltAndroidApp
class UltraIslandApp : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        SettingsRepository.init(this)
        com.ultraisland.pro.data.UltraIslandSettingsProvider.init(this)
        PrivilegedManager.shizuku.registerListeners()
        MediaSessionTracker.init(this)
        CallManager.init(this)
        PrivacyTracker.init(this)
        SoundAndDeviceTracker.init(this)
        
        // Phase 5 Managers
        WeatherManager.init(this)
        NetworkSpeedTracker.startTracking(appScope)
        IdleWidgetManager.init(this, appScope)

        appScope.launch {
            WeatherManager.refreshWeather(this@UltraIslandApp)
        }

        val alarm = TimerManager.checkNextAlarm(this)
        if (alarm != null) {
            com.ultraisland.pro.engine.statemachine.IslandStateMachine.setNextAlarm(alarm)
        }
    }
}
