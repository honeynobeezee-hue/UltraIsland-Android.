package com.ultraisland.pro.engine.statemachine

import com.ultraisland.pro.engine.activity.LiveActivity
import com.ultraisland.pro.engine.activity.NotificationActivity
import com.ultraisland.pro.engine.idle.IdleWidgetInfo
import com.ultraisland.pro.services.calendar.CalendarEventInfo
import com.ultraisland.pro.services.delivery.RideDeliveryInfo
import com.ultraisland.pro.services.media.MediaTrackInfo
import com.ultraisland.pro.services.navigation.NavigationInfo
import com.ultraisland.pro.services.system.BatteryStatusInfo
import com.ultraisland.pro.services.system.BluetoothStatusInfo
import com.ultraisland.pro.services.system.PrivacyIndicatorsState
import com.ultraisland.pro.services.system.SoundStatusInfo
import com.ultraisland.pro.services.system.VolumeBrightnessInfo
import com.ultraisland.pro.services.telephony.ActiveCallInfo
import com.ultraisland.pro.services.timer.ActiveTimerInfo
import com.ultraisland.pro.services.weather.WeatherData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface IslandContentType {
    data object Generic : IslandContentType
    data class Notification(val notif: NotificationActivity) : IslandContentType
    data class Media(val track: MediaTrackInfo) : IslandContentType
    data class Call(val call: ActiveCallInfo) : IslandContentType
    data class Timer(val timer: ActiveTimerInfo) : IslandContentType
    data class Charging(val battery: BatteryStatusInfo) : IslandContentType
    data class Bluetooth(val bluetooth: BluetoothStatusInfo) : IslandContentType
    data class Sound(val sound: SoundStatusInfo) : IslandContentType
    data class Volume(val volume: VolumeBrightnessInfo) : IslandContentType
    data class Download(val title: String, val progressPercent: Int) : IslandContentType
    // Phase 5 Content Types
    data class Navigation(val nav: NavigationInfo) : IslandContentType
    data class Ride(val ride: RideDeliveryInfo) : IslandContentType
    data class Weather(val weather: WeatherData) : IslandContentType
    data class Calendar(val event: CalendarEventInfo) : IslandContentType
    data class CustomApi(val activity: LiveActivity) : IslandContentType
    data object QuickLauncher : IslandContentType
}

sealed interface IslandState {
    data class Idle(
        val nextAlarm: String? = null,
        val widget: IdleWidgetInfo? = null,
        val isSplitPill: Boolean = false,
        val autoHide: Boolean = false
    ) : IslandState

    data class Compact(
        val activity: LiveActivity,
        val contentType: IslandContentType,
        val pendingCount: Int = 1
    ) : IslandState

    data class Expanded(
        val activity: LiveActivity,
        val contentType: IslandContentType
    ) : IslandState

    data object Hidden : IslandState
}

object IslandStateMachine {
    private val _state = MutableStateFlow<IslandState>(IslandState.Idle())
    val state: StateFlow<IslandState> = _state.asStateFlow()

    private val _privacyState = MutableStateFlow(PrivacyIndicatorsState())
    val privacyState: StateFlow<PrivacyIndicatorsState> = _privacyState.asStateFlow()

    // Activity Slots
    private var activeCall: ActiveCallInfo? = null
    private var activeTimer: ActiveTimerInfo? = null
    private var activeMedia: MediaTrackInfo? = null
    private var activeCharging: BatteryStatusInfo? = null
    private var activeBluetooth: BluetoothStatusInfo? = null
    private var activeSound: SoundStatusInfo? = null
    private var activeVolume: VolumeBrightnessInfo? = null
    private var activeNav: NavigationInfo? = null
    private var activeRide: RideDeliveryInfo? = null
    private var activeCustomApi: LiveActivity? = null
    private val activeNotifications = mutableListOf<NotificationActivity>()
    private var nextAlarmText: String? = null
    private var currentIdleWidget: IdleWidgetInfo? = null
    private var isSplitPillIdle = false
    private var isAutoHideIdle = false

    private var isUserExpanded = false
    private var isQuickLauncherOpen = false

    @Synchronized
    private fun reevaluateState(autoExpand: Boolean = false) {
        if (autoExpand) isUserExpanded = true

        // Priority 7: Call (Highest)
        val call = activeCall
        if (call != null) {
            val liveAct = LiveActivity(
                id = "call_active",
                title = call.callerName,
                subtitle = if (call.isIncoming) call.callerNumber else formatDuration(call.durationSeconds),
                iconType = "call",
                colorHex = if (call.isIncoming) "#34C759" else "#30B0C7"
            )
            val cType = IslandContentType.Call(call)
            _state.value = if (isUserExpanded || call.isIncoming) IslandState.Expanded(liveAct, cType) else IslandState.Compact(liveAct, cType)
            return
        }

        // Priority 6: Transient System Alerts (Volume, Sound mode, Bluetooth, Charging)
        val vol = activeVolume
        if (vol != null) {
            val liveAct = LiveActivity("vol", "Media Volume", "${vol.volumePercent}%", "volume", "#388AF6")
            val cType = IslandContentType.Volume(vol)
            _state.value = if (isUserExpanded) IslandState.Expanded(liveAct, cType) else IslandState.Compact(liveAct, cType)
            return
        }

        val sound = activeSound
        if (sound != null) {
            val liveAct = LiveActivity("snd", "Sound Profile", sound.ringerMode, "sound", "#FF9500")
            val cType = IslandContentType.Sound(sound)
            _state.value = if (isUserExpanded) IslandState.Expanded(liveAct, cType) else IslandState.Compact(liveAct, cType)
            return
        }

        val bt = activeBluetooth
        if (bt != null) {
            val liveAct = LiveActivity("bt", bt.deviceName, if (bt.isWired) "Connected" else "Connected ${bt.batteryPercentage ?: 80}%", "bluetooth", "#30B0C7")
            val cType = IslandContentType.Bluetooth(bt)
            _state.value = if (isUserExpanded) IslandState.Expanded(liveAct, cType) else IslandState.Compact(liveAct, cType)
            return
        }

        val chg = activeCharging
        if (chg != null) {
            val liveAct = LiveActivity("chg", chg.chargingType, "${chg.percentage}%", "battery", if (chg.isLowBattery) "#FF3B30" else "#FFD600")
            val cType = IslandContentType.Charging(chg)
            _state.value = if (isUserExpanded) IslandState.Expanded(liveAct, cType) else IslandState.Compact(liveAct, cType)
            return
        }

        // Quick Launcher if user opened it
        if (isQuickLauncherOpen) {
            val liveAct = LiveActivity("quick_tools", "Quick Utilities", "Tools & Shortcuts", "launcher", "#388AF6")
            _state.value = IslandState.Expanded(liveAct, IslandContentType.QuickLauncher)
            return
        }

        // Priority 5.5: Navigation (Live Google Maps / Waze / OsmAnd turn-by-turn)
        val nav = activeNav
        if (nav != null) {
            val liveAct = LiveActivity(
                id = "nav_active",
                title = nav.distance,
                subtitle = nav.nextStreet.ifEmpty { nav.direction },
                iconType = "navigation",
                colorHex = "#4285F4"
            )
            val cType = IslandContentType.Navigation(nav)
            _state.value = if (isUserExpanded) IslandState.Expanded(liveAct, cType) else IslandState.Compact(liveAct, cType)
            return
        }

        // Priority 5: Timer
        val timer = activeTimer
        if (timer != null) {
            val liveAct = LiveActivity("timer_active", timer.title, timer.formattedTime, "timer", "#FF9500")
            val cType = IslandContentType.Timer(timer)
            _state.value = if (isUserExpanded) IslandState.Expanded(liveAct, cType) else IslandState.Compact(liveAct, cType)
            return
        }

        // Priority 4.5: Ride / Delivery (Grab, Gojek, Uber, Zomato)
        val ride = activeRide
        if (ride != null) {
            val liveAct = LiveActivity(
                id = "ride_active",
                title = ride.title,
                subtitle = "${ride.status} (${ride.eta})",
                iconType = "car",
                colorHex = ride.accentColorHex
            )
            val cType = IslandContentType.Ride(ride)
            _state.value = if (isUserExpanded) IslandState.Expanded(liveAct, cType) else IslandState.Compact(liveAct, cType)
            return
        }

        // Priority 4: Media
        val media = activeMedia
        if (media != null && media.isPlaying) {
            val liveAct = LiveActivity("media_active", media.title, media.artist, "media", media.accentColorHex)
            val cType = IslandContentType.Media(media)
            _state.value = if (isUserExpanded) IslandState.Expanded(liveAct, cType) else IslandState.Compact(liveAct, cType)
            return
        }

        // Priority 3.5: Public API Custom Live Activity (Tasker / Broadcast)
        val custom = activeCustomApi
        if (custom != null) {
            val cType = IslandContentType.CustomApi(custom)
            _state.value = if (isUserExpanded) IslandState.Expanded(custom, cType) else IslandState.Compact(custom, cType)
            return
        }

        // Priority 3: Notification
        val notif = activeNotifications.firstOrNull()
        if (notif != null) {
            val liveAct = notif.toLiveActivity()
            val cType = IslandContentType.Notification(notif)
            _state.value = if (isUserExpanded) IslandState.Expanded(liveAct, cType) else IslandState.Compact(liveAct, cType, activeNotifications.size)
            return
        }

        // Priority 1: Idle (Alternating widgets or Split Pill)
        isUserExpanded = false
        if (isAutoHideIdle) {
            _state.value = IslandState.Hidden
        } else {
            _state.value = IslandState.Idle(
                nextAlarm = nextAlarmText,
                widget = currentIdleWidget,
                isSplitPill = isSplitPillIdle,
                autoHide = false
            )
        }
    }

    // Handlers
    fun updatePrivacyState(state: PrivacyIndicatorsState) {
        _privacyState.value = state
    }

    fun postCharging(status: BatteryStatusInfo, autoExpand: Boolean = false) {
        activeCharging = status
        reevaluateState(autoExpand)
    }

    fun clearCharging() {
        activeCharging = null
        reevaluateState()
    }

    fun postBluetooth(status: BluetoothStatusInfo, autoExpand: Boolean = false) {
        activeBluetooth = status
        reevaluateState(autoExpand)
    }

    fun clearBluetooth() {
        activeBluetooth = null
        reevaluateState()
    }

    fun postSoundStatus(status: SoundStatusInfo, autoExpand: Boolean = false) {
        activeSound = status
        reevaluateState(autoExpand)
    }

    fun postVolumeBrightness(info: VolumeBrightnessInfo, autoExpand: Boolean = false) {
        activeVolume = info
        reevaluateState(autoExpand)
    }

    fun postCall(call: ActiveCallInfo, autoExpand: Boolean = false) {
        activeCall = call
        reevaluateState(autoExpand)
    }

    fun clearCall() {
        activeCall = null
        isUserExpanded = false
        reevaluateState()
    }

    fun postMedia(track: MediaTrackInfo, autoExpand: Boolean = false) {
        activeMedia = track
        reevaluateState(autoExpand)
    }

    fun clearMedia() {
        activeMedia = null
        reevaluateState()
    }

    fun postTimer(timer: ActiveTimerInfo, autoExpand: Boolean = false) {
        activeTimer = timer
        reevaluateState(autoExpand)
    }

    fun clearTimer() {
        activeTimer = null
        isUserExpanded = false
        reevaluateState()
    }

    fun postNavigation(nav: NavigationInfo, autoExpand: Boolean = false) {
        activeNav = nav
        reevaluateState(autoExpand)
    }

    fun clearNavigation() {
        activeNav = null
        reevaluateState()
    }

    fun postRideDelivery(ride: RideDeliveryInfo, autoExpand: Boolean = false) {
        activeRide = ride
        reevaluateState(autoExpand)
    }

    fun clearRideDelivery() {
        activeRide = null
        reevaluateState()
    }

    fun postNotification(notif: NotificationActivity, autoExpand: Boolean = false) {
        activeNotifications.removeAll { it.key == notif.key }
        activeNotifications.add(0, notif)
        reevaluateState(autoExpand)
    }

    fun removeNotification(key: String, clearSystem: Boolean = false) {
        activeNotifications.removeAll { it.key == key }
        reevaluateState()
    }

    fun setNextAlarm(alarmFormatted: String?) {
        nextAlarmText = alarmFormatted
        if (_state.value is IslandState.Idle) {
            reevaluateState()
        }
    }

    fun setIdleWidget(widget: IdleWidgetInfo) {
        currentIdleWidget = widget
        if (_state.value is IslandState.Idle) {
            _state.value = IslandState.Idle(
                nextAlarm = nextAlarmText,
                widget = widget,
                isSplitPill = isSplitPillIdle,
                autoHide = isAutoHideIdle
            )
        }
    }

    fun setIdleSplitPill(enabled: Boolean) {
        isSplitPillIdle = enabled
        if (_state.value is IslandState.Idle) {
            reevaluateState()
        }
    }

    fun setAutoHideIdle(enabled: Boolean) {
        isAutoHideIdle = enabled
        reevaluateState()
    }

    fun openQuickLauncher() {
        isQuickLauncherOpen = true
        isUserExpanded = true
        reevaluateState()
    }

    fun closeQuickLauncher() {
        isQuickLauncherOpen = false
        isUserExpanded = false
        reevaluateState()
    }

    fun toggleExpand() {
        if (isQuickLauncherOpen) {
            isQuickLauncherOpen = false
            isUserExpanded = false
        } else {
            isUserExpanded = !isUserExpanded
        }
        reevaluateState()
    }

    fun collapse() {
        isUserExpanded = false
        isQuickLauncherOpen = false
        activeVolume = null
        activeSound = null
        reevaluateState()
    }

    fun clearAll() {
        activeCall = null
        activeTimer = null
        activeMedia = null
        activeCharging = null
        activeBluetooth = null
        activeSound = null
        activeVolume = null
        activeNav = null
        activeRide = null
        activeCustomApi = null
        activeNotifications.clear()
        isUserExpanded = false
        isQuickLauncherOpen = false
        reevaluateState()
    }

    fun postCustomApiActivity(activity: LiveActivity, autoExpand: Boolean = false) {
        activeCustomApi = activity
        reevaluateState(autoExpand)
    }

    fun dismissCustomApiActivity(id: String? = null) {
        if (id == null || activeCustomApi?.id == id) {
            activeCustomApi = null
            reevaluateState()
        }
    }

    private fun formatDuration(seconds: Int): String {
        val mins = seconds / 60
        val secs = seconds % 60
        return String.format("%02d:%02d", mins, secs)
    }
}
