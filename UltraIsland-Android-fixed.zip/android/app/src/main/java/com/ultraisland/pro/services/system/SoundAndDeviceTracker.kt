package com.ultraisland.pro.services.system

import android.app.NotificationManager
import android.content.Context
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import com.ultraisland.pro.engine.statemachine.IslandStateMachine

data class SoundStatusInfo(
    val ringerMode: String, // "Ring", "Vibrate", "Silent"
    val isDndActive: Boolean,
    val isFlashlightOn: Boolean = false
)

data class VolumeBrightnessInfo(
    val volumePercent: Int,
    val brightnessPercent: Int
)

object SoundAndDeviceTracker {
    private const val TAG = "SoundAndDeviceTracker"

    private var audioManager: AudioManager? = null
    private var notificationManager: NotificationManager? = null
    private var cameraManager: CameraManager? = null

    private var isTorchOn = false
    private val mainHandler = Handler(Looper.getMainLooper())

    fun init(context: Context) {
        val appCtx = context.applicationContext
        audioManager = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        notificationManager = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        cameraManager = appCtx.getSystemService(Context.CAMERA_SERVICE) as? CameraManager

        try {
            cameraManager?.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    super.onTorchModeChanged(cameraId, enabled)
                    isTorchOn = enabled
                    checkAndNotifySoundStatus()
                }
            }, mainHandler)
        } catch (_: Exception) {}
    }

    fun checkAndNotifySoundStatus() {
        val am = audioManager ?: return
        val ringer = when (am.ringerMode) {
            AudioManager.RINGER_MODE_NORMAL -> "Ring"
            AudioManager.RINGER_MODE_VIBRATE -> "Vibrate"
            AudioManager.RINGER_MODE_SILENT -> "Silent"
            else -> "Ring"
        }

        val dnd = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val filter = notificationManager?.currentInterruptionFilter ?: NotificationManager.INTERRUPTION_FILTER_ALL
            filter != NotificationManager.INTERRUPTION_FILTER_ALL
        } else false

        val status = SoundStatusInfo(
            ringerMode = ringer,
            isDndActive = dnd,
            isFlashlightOn = isTorchOn
        )

        IslandStateMachine.postSoundStatus(status, autoExpand = true)

        mainHandler.postDelayed({
            IslandStateMachine.collapse()
        }, 3500L)
    }

    fun onVolumeChanged(context: Context) {
        val am = audioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val volPercent = (curVol * 100 / maxVol)

        val curBrightness = try {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (_: Exception) { 128 }
        val brightnessPercent = (curBrightness * 100 / 255)

        val info = VolumeBrightnessInfo(
            volumePercent = volPercent,
            brightnessPercent = brightnessPercent
        )

        IslandStateMachine.postVolumeBrightness(info, autoExpand = true)

        mainHandler.postDelayed({
            IslandStateMachine.collapse()
        }, 2500L)
    }

    fun setMusicVolume(percent: Int) {
        val am = audioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = (percent * maxVol / 100).coerceIn(0, maxVol)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
    }

    fun toggleFlashlight(context: Context) {
        try {
            val cm = cameraManager ?: return
            val cameraId = cm.cameraIdList.firstOrNull() ?: return
            isTorchOn = !isTorchOn
            cm.setTorchMode(cameraId, isTorchOn)
            checkAndNotifySoundStatus()
        } catch (e: Exception) {
            Log.e(TAG, "Error toggling flashlight", e)
        }
    }
}
