package com.ultraisland.pro.privileged

import android.content.Context
import android.provider.Settings
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

val Context.settingsChangelogDataStore by preferencesDataStore(name = "system_settings_changelog")

data class SettingChangeRecord(
    val namespace: String, // "GLOBAL", "SECURE", "SYSTEM"
    val key: String,
    val originalValue: String?,
    val currentValue: String,
    val timestamp: Long = System.currentTimeMillis()
)

object SystemSettingsRestorer {
    private val CHANGELOG_KEY = stringPreferencesKey("settings_changelog_json")

    fun getChangelog(context: Context): Flow<List<SettingChangeRecord>> {
        return context.settingsChangelogDataStore.data.map { prefs ->
            val json = prefs[CHANGELOG_KEY]
            if (json.isNullOrEmpty()) emptyList() else parseChangelog(json)
        }
    }

    suspend fun recordAndSet(
        context: Context,
        bridge: PrivilegedBridge,
        namespace: String,
        key: String,
        newValue: String
    ): Result<String> {
        val upperNs = namespace.uppercase()
        val originalValue: String? = try {
            when (upperNs) {
                "SECURE" -> Settings.Secure.getString(context.contentResolver, key)
                "GLOBAL" -> Settings.Global.getString(context.contentResolver, key)
                "SYSTEM" -> Settings.System.getString(context.contentResolver, key)
                else -> null
            }
        } catch (_: Exception) {
            null
        }

        // Execute shell via PrivilegedBridge
        val cmd = "settings put ${upperNs.lowercase()} $key $newValue"
        if (!PrivilegedCommandRegistry.isCommandAllowed(cmd)) {
            return Result.failure(SecurityException("Command is not whitelisted: $cmd"))
        }

        val execResult = bridge.exec(cmd)
        if (execResult.isSuccess) {
            // Save to changelog
            context.settingsChangelogDataStore.edit { prefs ->
                val currentList = (prefs[CHANGELOG_KEY]?.let { parseChangelog(it) } ?: emptyList()).toMutableList()
                val existingIndex = currentList.indexOfFirst { it.namespace == upperNs && it.key == key }
                if (existingIndex >= 0) {
                    val existing = currentList[existingIndex]
                    currentList[existingIndex] = existing.copy(currentValue = newValue, timestamp = System.currentTimeMillis())
                } else {
                    currentList.add(SettingChangeRecord(upperNs, key, originalValue, newValue))
                }
                prefs[CHANGELOG_KEY] = serializeChangelog(currentList)
            }
        }
        return execResult
    }

    suspend fun restoreAll(context: Context, bridge: PrivilegedBridge): Result<Int> {
        val list = try {
            val prefs = context.settingsChangelogDataStore.data.first()
            val json = prefs[CHANGELOG_KEY]
            if (json.isNullOrEmpty()) emptyList() else parseChangelog(json)
        } catch (e: Exception) {
            return Result.failure(e)
        }

        var restoredCount = 0
        for (item in list) {
            val cmd = if (item.originalValue != null) {
                "settings put ${item.namespace.lowercase()} ${item.key} ${item.originalValue}"
            } else {
                "settings delete ${item.namespace.lowercase()} ${item.key}"
            }
            val res = bridge.exec(cmd)
            if (res.isSuccess) restoredCount++
        }

        // Clear changelog
        context.settingsChangelogDataStore.edit { it.remove(CHANGELOG_KEY) }
        return Result.success(restoredCount)
    }

    private fun parseChangelog(json: String): List<SettingChangeRecord> {
        val list = mutableListOf<SettingChangeRecord>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    SettingChangeRecord(
                        namespace = obj.getString("namespace"),
                        key = obj.getString("key"),
                        originalValue = if (obj.has("originalValue") && !obj.isNull("originalValue")) obj.getString("originalValue") else null,
                        currentValue = obj.getString("currentValue"),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
        } catch (_: Exception) {
            return emptyList()
        }
        return list
    }

    private fun serializeChangelog(list: List<SettingChangeRecord>): String {
        val arr = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("namespace", item.namespace)
            obj.put("key", item.key)
            if (item.originalValue != null) {
                obj.put("originalValue", item.originalValue)
            } else {
                obj.put("originalValue", JSONObject.NULL)
            }
            obj.put("currentValue", item.currentValue)
            obj.put("timestamp", item.timestamp)
            arr.put(obj)
        }
        return arr.toString()
    }
}
