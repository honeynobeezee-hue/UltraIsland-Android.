package com.ultraisland.pro.engine.render

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.services.system.BatteryStatusInfo
import com.ultraisland.pro.services.system.BluetoothStatusInfo
import com.ultraisland.pro.services.system.SoundAndDeviceTracker
import com.ultraisland.pro.services.system.SoundStatusInfo
import com.ultraisland.pro.services.system.VolumeBrightnessInfo

@Composable
fun ChargingCardView(
    battery: BatteryStatusInfo,
    modifier: Modifier = Modifier
) {
    val accentColor = if (battery.isLowBattery) Color(0xFFFF3B30) else Color(0xFFFFD600)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.2f))
                    .border(1.5.dp, accentColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (battery.isLowBattery) Icons.Default.BatteryAlert else Icons.Default.BatteryChargingFull,
                    contentDescription = "Battery",
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = battery.chargingType,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (battery.isLowBattery) "Please connect charger" else "${battery.percentage}% charged",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 12.sp
                )
            }
        }

        Text(
            text = "${battery.percentage}%",
            color = accentColor,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun BluetoothCardView(
    bluetooth: BluetoothStatusInfo,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF30B0C7).copy(alpha = 0.2f))
                    .border(1.5.dp, Color(0xFF30B0C7), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (bluetooth.isWired) Icons.Default.Headphones else Icons.Default.Bluetooth,
                    contentDescription = "Audio Device",
                    tint = Color(0xFF30B0C7),
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = bluetooth.deviceName,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (bluetooth.isWired) "Wired Audio Active" else "Connected • Battery ${bluetooth.batteryPercentage ?: 80}%",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 12.sp
                )
            }
        }

        if (!bluetooth.isWired) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF30B0C7).copy(alpha = 0.2f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${bluetooth.batteryPercentage ?: 80}%",
                    color = Color(0xFF30B0C7),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun VolumeBrightnessCardView(
    info: VolumeBrightnessInfo,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Media Volume Row
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.VolumeUp, contentDescription = "Volume", tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Slider(
                value = info.volumePercent.toFloat(),
                onValueChange = { SoundAndDeviceTracker.setMusicVolume(it.toInt()) },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color(0xFF388AF6)
                ),
                modifier = Modifier.weight(1f).height(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("${info.volumePercent}%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        // Screen Brightness Row
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.BrightnessMedium, contentDescription = "Brightness", tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Slider(
                value = info.brightnessPercent.toFloat(),
                onValueChange = {},
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color(0xFFFF9500)
                ),
                modifier = Modifier.weight(1f).height(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("${info.brightnessPercent}%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SoundModeCardView(
    sound: SoundStatusInfo,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("Sound Profile: ${sound.ringerMode}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
                text = if (sound.isDndActive) "Do Not Disturb Active" else "Alerts Unmuted",
                color = if (sound.isDndActive) Color(0xFFFF9500) else Color.White.copy(alpha = 0.6f),
                fontSize = 11.sp
            )
        }

        // Flashlight Toggle Button
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(if (sound.isFlashlightOn) Color(0xFFFFD600) else Color.White.copy(alpha = 0.12f))
                .clickable { SoundAndDeviceTracker.toggleFlashlight(context) },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.FlashlightOn,
                contentDescription = "Flashlight",
                tint = if (sound.isFlashlightOn) Color.Black else Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
