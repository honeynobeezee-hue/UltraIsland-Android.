/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.ultraisland.pro.ui.sections

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.WifiLock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.ui.components.CollapsibleCard

private val ProBlue = Color(0xFF388AF6)
private val ProGreen = Color(0xFF10B981)
private val ProAmber = Color(0xFFF59E0B)
private val ProRed = Color(0xFFEF4444)
private val ProSurface = Color(0xFF141720)
private val ProCodeBg = Color(0xFF0D0F14)

private enum class SettingScope {
    GLOBAL,
    SECURE
}

private data class AuditedSystemSetting(
    val id: String,
    val name: String,
    val key: String,
    val scope: SettingScope,
    val icon: ImageVector,
    val description: String,
    val defaultValue: String,
    var currentValue: String = "",
    var isModified: Boolean = false
)

/**
 * System Settings Restorer & Audit Tracker.
 * Tracks sensitive Android system settings often altered by notification/island apps
 * and allows 1-tap granular or batch rollback to original OEM defaults.
 */
@Composable
fun SystemSettingsRestorerCard(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var hasWriteSecureSettings by remember {
        mutableStateOf(
            context.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
        )
    }

    var showBatchConfirmDialog by remember { mutableStateOf(false) }

    val auditedSettings = remember {
        mutableStateListOf(
            AuditedSystemSetting(
                id = "heads_up",
                name = "Heads-up Notifications",
                key = "heads_up_notifications_enabled",
                scope = SettingScope.GLOBAL,
                icon = Icons.Rounded.NotificationsOff,
                description = "System pop-up banners. Suppressed by Island to prevent duplicate alerts.",
                defaultValue = "1"
            ),
            AuditedSystemSetting(
                id = "daltonizer",
                name = "Color Correction (Daltonizer)",
                key = "accessibility_display_daltonizer_enabled",
                scope = SettingScope.SECURE,
                icon = Icons.Rounded.Palette,
                description = "Display color correction/inversion used for OLED high-contrast modes.",
                defaultValue = "0"
            ),
            AuditedSystemSetting(
                id = "private_dns",
                name = "Private DNS Mode",
                key = "private_dns_mode",
                scope = SettingScope.GLOBAL,
                icon = Icons.Rounded.WifiLock,
                description = "System DNS encryption routing mode (opportunistic, hostname, off).",
                defaultValue = "opportunistic"
            ),
            AuditedSystemSetting(
                id = "stay_on",
                name = "Stay Awake While Plugged In",
                key = "stay_on_while_plugged_in",
                scope = SettingScope.GLOBAL,
                icon = Icons.Rounded.Power,
                description = "Prevents device sleep when docked or charging.",
                defaultValue = "0"
            )
        )
    }

    fun readCurrentValues() {
        hasWriteSecureSettings = context.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
        val resolver = context.contentResolver

        for (i in auditedSettings.indices) {
            val item = auditedSettings[i]
            val liveVal = try {
                when (item.scope) {
                    SettingScope.GLOBAL -> Settings.Global.getString(resolver, item.key) ?: item.defaultValue
                    SettingScope.SECURE -> Settings.Secure.getString(resolver, item.key) ?: item.defaultValue
                }
            } catch (e: Exception) {
                item.defaultValue
            }

            auditedSettings[i] = item.copy(
                currentValue = liveVal,
                isModified = liveVal != item.defaultValue
            )
        }
    }

    LaunchedEffect(Unit) {
        readCurrentValues()
    }

    fun restoreSingleSetting(setting: AuditedSystemSetting) {
        if (!hasWriteSecureSettings) {
            val adbCmd = "adb shell settings put ${if (setting.scope == SettingScope.GLOBAL) "global" else "secure"} ${setting.key} ${setting.defaultValue}"
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Restore Command", adbCmd))
            Toast.makeText(context, "Copied ADB command! Requires WRITE_SECURE_SETTINGS.", Toast.LENGTH_LONG).show()
            return
        }

        try {
            val resolver = context.contentResolver
            when (setting.scope) {
                SettingScope.GLOBAL -> Settings.Global.putString(resolver, setting.key, setting.defaultValue)
                SettingScope.SECURE -> Settings.Secure.putString(resolver, setting.key, setting.defaultValue)
            }
            Toast.makeText(context, "Restored ${setting.name} to default (${setting.defaultValue})", Toast.LENGTH_SHORT).show()
            readCurrentValues()
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to restore: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun restoreAllSettings() {
        if (!hasWriteSecureSettings) {
            Toast.makeText(context, "Requires WRITE_SECURE_SETTINGS permission to restore automatically.", Toast.LENGTH_LONG).show()
            return
        }

        val resolver = context.contentResolver
        var count = 0
        auditedSettings.forEach { setting ->
            runCatching {
                when (setting.scope) {
                    SettingScope.GLOBAL -> Settings.Global.putString(resolver, setting.key, setting.defaultValue)
                    SettingScope.SECURE -> Settings.Secure.putString(resolver, setting.key, setting.defaultValue)
                }
                count++
            }
        }
        readCurrentValues()
        Toast.makeText(context, "Successfully restored $count settings to OEM defaults.", Toast.LENGTH_SHORT).show()
    }

    val modifiedCount = auditedSettings.count { it.isModified }

    CollapsibleCard(
        title = "System Settings Restorer & Audit",
        stateKey = "card_system_settings_restorer",
        summary = if (modifiedCount == 0) "All 4 audited settings match OEM defaults" else "$modifiedCount settings modified",
        icon = Icons.Rounded.History,
        initiallyExpanded = modifiedCount > 0,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header actions: Refresh & Batch rollback
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (modifiedCount > 0) ProAmber else ProGreen)
                    )
                    Text(
                        text = if (modifiedCount > 0) "$modifiedCount modified settings" else "All settings clean",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (modifiedCount > 0) ProAmber else ProGreen
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = { readCurrentValues() },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Refresh Audit",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    if (modifiedCount > 0) {
                        Button(
                            onClick = { showBatchConfirmDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ProAmber),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reset All", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Description info note
            Text(
                text = "UltraIsland and custom overlays modify system flags to streamline the notification experience. You can audit, toggle, or roll them back anytime below.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Settings list
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                auditedSettings.forEach { item ->
                    SettingAuditItemRow(
                        setting = item,
                        hasWritePermission = hasWriteSecureSettings,
                        onRestore = { restoreSingleSetting(item) }
                    )
                }
            }
        }
    }

    if (showBatchConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showBatchConfirmDialog = false },
            title = {
                Text(
                    text = "Restore All System Settings?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "This will reset Heads-up notifications, Daltonizer, Private DNS, and Stay Awake flags back to their factory Android values. Continue?",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showBatchConfirmDialog = false
                        restoreAllSettings()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ProAmber)
                ) {
                    Text("Restore All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBatchConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun SettingAuditItemRow(
    setting: AuditedSystemSetting,
    hasWritePermission: Boolean,
    onRestore: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ProSurface)
            .border(
                1.dp,
                if (setting.isModified) ProAmber.copy(alpha = 0.35f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
                RoundedCornerShape(12.dp)
            )
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (setting.isModified) ProAmber.copy(alpha = 0.15f) else ProBlue.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = setting.icon,
                    contentDescription = null,
                    tint = if (setting.isModified) ProAmber else ProBlue,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = setting.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = setting.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            if (setting.isModified) {
                OutlinedButton(
                    onClick = onRestore,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Rollback", fontSize = 11.sp)
                }
            }
        }

        // Details strip: Key, Current Value vs Default
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(ProCodeBg)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${setting.scope.name.lowercase()}.${setting.key}",
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Current: ${setting.currentValue.ifEmpty { "0" }}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (setting.isModified) ProAmber else ProGreen
                )
                Text(
                    text = "(Default: ${setting.defaultValue})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
