/*
 * UltraIsland Pro (2026)
 * Licensed under the GNU General Public License v3.0
 */

package com.ultraisland.pro.ui.expanded

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AirplanemodeActive
import androidx.compose.material.icons.rounded.BatterySaver
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Screenshot
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.ui.graphics.vector.ImageVector
import com.ultraisland.pro.R
import com.ultraisland.pro.model.UtilityType

fun utilityIcon(type: UtilityType): ImageVector = when (type) {
    UtilityType.MobileData -> Icons.Rounded.SignalCellularAlt
    UtilityType.WiFi -> Icons.Rounded.Wifi
    UtilityType.Hotspot -> Icons.Rounded.WifiTethering
    UtilityType.Flashlight -> Icons.Rounded.FlashlightOn
    UtilityType.Calculator -> Icons.Rounded.Calculate
    UtilityType.ClearCache -> Icons.Rounded.CleaningServices
    UtilityType.ScreenRecorder -> Icons.Rounded.Videocam
    UtilityType.Screenshot -> Icons.Rounded.Screenshot
    UtilityType.Timer -> Icons.Rounded.Timer
    UtilityType.Stopwatch -> Icons.Rounded.Timer
    UtilityType.LockScreen -> Icons.Rounded.Lock
    UtilityType.VoiceRecorder -> Icons.Rounded.Mic
    UtilityType.Camera -> Icons.Rounded.CameraAlt
    UtilityType.Bluetooth -> Icons.Rounded.Bluetooth
    UtilityType.AirplaneMode -> Icons.Rounded.AirplanemodeActive
    UtilityType.AutoRotate -> Icons.Rounded.ScreenRotation
    UtilityType.DarkMode -> Icons.Rounded.DarkMode
    UtilityType.BatterySaver -> Icons.Rounded.BatterySaver
    UtilityType.AppWidget -> Icons.Rounded.Widgets
}

fun utilityLabelRes(type: UtilityType): Int = when (type) {
    UtilityType.MobileData -> R.string.tile_custom_default_label
    UtilityType.WiFi -> R.string.tile_custom_default_label
    UtilityType.Hotspot -> R.string.tile_custom_default_label
    UtilityType.Flashlight -> R.string.tile_custom_default_label
    UtilityType.Calculator -> R.string.tile_custom_default_label
    UtilityType.ClearCache -> R.string.tile_custom_default_label
    UtilityType.ScreenRecorder -> R.string.tile_custom_default_label
    UtilityType.Screenshot -> R.string.tile_screenshot_label
    UtilityType.Timer -> R.string.tile_custom_default_label
    UtilityType.Stopwatch -> R.string.tile_custom_default_label
    UtilityType.LockScreen -> R.string.tile_lock_label
    UtilityType.VoiceRecorder -> R.string.tile_custom_default_label
    UtilityType.Camera -> R.string.tile_custom_default_label
    UtilityType.Bluetooth -> R.string.tile_custom_default_label
    UtilityType.AirplaneMode -> R.string.tile_custom_default_label
    UtilityType.AutoRotate -> R.string.tile_custom_default_label
    UtilityType.DarkMode -> R.string.tile_custom_default_label
    UtilityType.BatterySaver -> R.string.tile_battery_label
    UtilityType.AppWidget -> R.string.tile_custom_default_label
}
