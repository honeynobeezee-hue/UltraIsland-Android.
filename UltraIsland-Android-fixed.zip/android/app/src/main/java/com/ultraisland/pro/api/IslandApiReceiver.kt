package com.ultraisland.pro.api

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.ultraisland.pro.engine.activity.LiveActivity
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class IslandApiReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        Log.i(TAG, "IslandApiReceiver received intent: $action")

        when (action) {
            ACTION_POST_ACTIVITY -> {
                val id = intent.getStringExtra(EXTRA_ID) ?: "api_${System.currentTimeMillis()}"
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "Live Activity"
                val subtitle = intent.getStringExtra(EXTRA_SUBTITLE) ?: ""
                val iconType = intent.getStringExtra(EXTRA_ICON) ?: "custom"
                val accentColorHex = intent.getStringExtra(EXTRA_ACCENT_COLOR) ?: "#388AF6"
                val progress = if (intent.hasExtra(EXTRA_PROGRESS)) intent.getIntExtra(EXTRA_PROGRESS, -1) else null
                val durationSec = if (intent.hasExtra(EXTRA_DURATION)) intent.getLongExtra(EXTRA_DURATION, 0L) else null
                val actionIntent = intent.getStringExtra(EXTRA_ACTION_INTENT)
                val autoExpand = intent.getBooleanExtra(EXTRA_AUTO_EXPAND, false)

                val activity = LiveActivity(
                    id = id,
                    title = title,
                    subtitle = subtitle,
                    iconType = iconType,
                    colorHex = accentColorHex,
                    progress = if (progress != null && progress in 0..100) progress else null,
                    durationSeconds = durationSec,
                    actionIntent = actionIntent
                )

                IslandStateMachine.postCustomApiActivity(activity, autoExpand)

                // Optional auto-dismiss if duration specified
                if (durationSec != null && durationSec > 0) {
                    CoroutineScope(Dispatchers.Default).launch {
                        delay(durationSec * 1000L)
                        IslandStateMachine.dismissCustomApiActivity(id)
                    }
                }
            }

            ACTION_DISMISS_ACTIVITY -> {
                val id = intent.getStringExtra(EXTRA_ID)
                IslandStateMachine.dismissCustomApiActivity(id)
            }
        }
    }

    companion object {
        private const val TAG = "IslandApiReceiver"

        const val PERMISSION_POST_ISLAND = "com.ultraisland.pro.permission.POST_ISLAND_ACTIVITY"

        const val ACTION_POST_ACTIVITY = "com.ultraisland.pro.action.POST_ACTIVITY"
        const val ACTION_DISMISS_ACTIVITY = "com.ultraisland.pro.action.DISMISS_ACTIVITY"

        const val EXTRA_ID = "id"
        const val EXTRA_TITLE = "title"
        const val EXTRA_SUBTITLE = "subtitle"
        const val EXTRA_ICON = "icon"
        const val EXTRA_PROGRESS = "progress"
        const val EXTRA_DURATION = "duration"
        const val EXTRA_ACCENT_COLOR = "accentColorHex"
        const val EXTRA_ACTION_INTENT = "actionIntent"
        const val EXTRA_AUTO_EXPAND = "autoExpand"
    }
}
