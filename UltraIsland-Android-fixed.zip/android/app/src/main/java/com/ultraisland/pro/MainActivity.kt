package com.ultraisland.pro

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.core.datastore.FontOption
import com.ultraisland.pro.core.datastore.IslandSettingsState
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.core.designsystem.UltraIslandTheme
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import com.ultraisland.pro.privileged.PrivilegedManager
import com.ultraisland.pro.services.accessibility.IslandAccessibilityService
import com.ultraisland.pro.services.media.MediaTrackInfo
import com.ultraisland.pro.services.system.BatteryStatusInfo
import com.ultraisland.pro.services.system.BluetoothStatusInfo
import com.ultraisland.pro.services.system.PrivacyIndicatorsState
import com.ultraisland.pro.services.system.VolumeBrightnessInfo
import com.ultraisland.pro.services.telephony.ActiveCallInfo
import com.ultraisland.pro.services.timer.TimerManager
import com.ultraisland.pro.ui.notifications.AppRulesScreen
import com.ultraisland.pro.ui.diagnostics.PrivilegedDiagnosticsScreen
import com.ultraisland.pro.ui.studio.AnimationsScreen
import com.ultraisland.pro.ui.studio.AppearanceScreen
import com.ultraisland.pro.ui.studio.FontsClockScreen
import com.ultraisland.pro.ui.studio.LayoutPresetsScreen
import com.ultraisland.pro.data.UltraIslandSettingsProvider
import com.ultraisland.pro.ui.studio.StudioHomeScreen
import com.ultraisland.pro.ui.tools.QuickToolsScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        UltraIslandSettingsProvider.init(this)
        setContent {
            com.ultraisland.pro.ui.UltraIslandTheme {
                com.ultraisland.pro.ui.UltraIslandHomeScreen(
                    repository = UltraIslandSettingsProvider.repository
                )
            }
        }
    }
}

@Composable
fun MainAppScreen() {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }
    var activeStudioSubscreen by remember { mutableStateOf<String?>(null) }
    val settings by SettingsRepository.settingsFlow.collectAsState(initial = IslandSettingsState())
    val scope = rememberCoroutineScope()

    // Permission checks
    val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
    val enabledServices = am?.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK) ?: emptyList()
    val isAccessibilityActive = enabledServices.any {
        it.resolveInfo.serviceInfo.packageName == context.packageName &&
                it.resolveInfo.serviceInfo.name == IslandAccessibilityService::class.java.name
    }
    val hasCoreOverlayPermission = isAccessibilityActive || Settings.canDrawOverlays(context)

    // Font picker launcher
    val fontPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                SettingsRepository.updateSettings { s ->
                    s.copy(
                        fontOption = FontOption.CUSTOM,
                        customFontUri = uri.toString()
                    )
                }
            }
            Toast.makeText(context, "Custom font loaded: ${uri.lastPathSegment}", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        bottomBar = {
            if (activeStudioSubscreen == null) {
                NavigationBar(containerColor = Color(0xFF0F1117)) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0; activeStudioSubscreen = null },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Studio") },
                        label = { Text("Studio", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            indicatorColor = Color(0xFF388AF6)
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1; activeStudioSubscreen = null },
                        icon = { Icon(Icons.Default.Notifications, contentDescription = "Alerts") },
                        label = { Text("App Alerts", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            indicatorColor = Color(0xFF388AF6)
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2; activeStudioSubscreen = null },
                        icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Test") },
                        label = { Text("Test Flight", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            indicatorColor = Color(0xFF388AF6)
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3; activeStudioSubscreen = null },
                        icon = { Icon(Icons.Default.Build, contentDescription = "Setup") },
                        label = { Text("Setup", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            indicatorColor = Color(0xFF388AF6)
                        )
                    )
                }
            }
        },
        containerColor = Color(0xFF090A0D)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> {
                    when (activeStudioSubscreen) {
                        "appearance" -> {
                            AppearanceScreen(
                                settings = settings,
                                onUpdate = { t -> scope.launch { SettingsRepository.updateSettings(t) } },
                                onBack = { activeStudioSubscreen = null }
                            )
                        }
                        "layout" -> {
                            LayoutPresetsScreen(
                                settings = settings,
                                onUpdate = { t -> scope.launch { SettingsRepository.updateSettings(t) } },
                                onBack = { activeStudioSubscreen = null }
                            )
                        }
                        "fonts" -> {
                            FontsClockScreen(
                                settings = settings,
                                onUpdate = { t -> scope.launch { SettingsRepository.updateSettings(t) } },
                                onPickCustomFont = { fontPickerLauncher.launch("*/*") },
                                onBack = { activeStudioSubscreen = null }
                            )
                        }
                        "animations" -> {
                            AnimationsScreen(
                                settings = settings,
                                onUpdate = { t -> scope.launch { SettingsRepository.updateSettings(t) } },
                                onBack = { activeStudioSubscreen = null }
                            )
                        }
                        "quick_tools" -> {
                            QuickToolsScreen(onBack = { activeStudioSubscreen = null })
                        }
                        "diagnostics" -> {
                            PrivilegedDiagnosticsScreen(onBack = { activeStudioSubscreen = null })
                        }
                        else -> {
                            StudioHomeScreen(
                                settings = settings,
                                hasCoreOverlayPermission = hasCoreOverlayPermission,
                                onNavigateToCategory = { catId ->
                                    when (catId) {
                                        "appearance", "layout", "fonts", "animations", "quick_tools", "diagnostics" -> {
                                            activeStudioSubscreen = catId
                                        }
                                        "live_activities" -> {
                                            selectedTab = 2
                                        }
                                        "alerts" -> {
                                            selectedTab = 1
                                        }
                                        "setup" -> {
                                            activeStudioSubscreen = "diagnostics"
                                        }
                                        "gestures", "idle" -> {
                                            Toast.makeText(context, "Full customization for $catId coming in 6B", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                onOpenAccessibility = {
                                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    })
                                },
                                onOpenOverlay = {
                                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    })
                                }
                            )
                        }
                    }
                }
                1 -> AppRulesScreen(settings = settings)
                2 -> TestScreen()
                3 -> SetupScreen(onOpenDiagnostics = { selectedTab = 0; activeStudioSubscreen = "diagnostics" })
            }
        }
    }
}

@Composable
fun TestScreen() {
    val state by IslandStateMachine.state.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Phase 3-5 Interactive Matrix", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Simulate Live Activities and verify real-time animations", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Current State: ${state.javaClass.simpleName}", color = Color(0xFF388AF6), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            IslandStateMachine.postMedia(
                                MediaTrackInfo(
                                    title = "Midnight Reverie",
                                    artist = "Synthwave Collective",
                                    isPlaying = true,
                                    durationMs = 210000L,
                                    positionMs = 85000L,
                                    accentColorHex = "#E0245E"
                                ),
                                autoExpand = false
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE0245E))
                    ) {
                        Text("1. Play Music (Priority 4)")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            IslandStateMachine.postCall(
                                ActiveCallInfo(
                                    callerName = "Jane Doe",
                                    callerNumber = "+1 (555) 0199",
                                    isIncoming = true,
                                    isOngoing = false
                                ),
                                autoExpand = true
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34C759))
                    ) {
                        Text("2. Incoming Call (Priority 7)")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            IslandStateMachine.postCall(
                                ActiveCallInfo(
                                    callerName = "Jane Doe",
                                    callerNumber = "+1 (555) 0199",
                                    isIncoming = false,
                                    isOngoing = true,
                                    durationSeconds = 45
                                ),
                                autoExpand = false
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF30B0C7))
                    ) {
                        Text("3. Answer Call (Duration Counter)")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { IslandStateMachine.clearCall() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF3B30))
                    ) {
                        Text("4. End Call (Music Resumes)")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { TimerManager.startTimer("Kitchen Timer", 300) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9500))
                    ) {
                        Text("5. Countdown Timer 05:00")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            IslandStateMachine.postCharging(
                                BatteryStatusInfo(
                                    percentage = 85,
                                    isCharging = true,
                                    chargingType = "Super Fast Charging 67W",
                                    isLowBattery = false,
                                    isFull = false
                                ),
                                autoExpand = true
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD600))
                    ) {
                        Text("6. 67W Fast Charging (85%)", color = Color.Black)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            IslandStateMachine.postBluetooth(
                                BluetoothStatusInfo(
                                    deviceName = "Earbuds Pro",
                                    isConnected = true,
                                    isWired = false,
                                    batteryPercentage = 85
                                ),
                                autoExpand = true
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF30B0C7))
                    ) {
                        Text("7. Bluetooth Connected (85%)")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            IslandStateMachine.postVolumeBrightness(
                                VolumeBrightnessInfo(volumePercent = 65, brightnessPercent = 75),
                                autoExpand = true
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388AF6))
                    ) {
                        Text("8. Volume & Brightness HUD")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            val cur = IslandStateMachine.privacyState.value
                            IslandStateMachine.updatePrivacyState(
                                cur.copy(isCameraActive = !cur.isCameraActive, isMicActive = !cur.isMicActive)
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34C759))
                    ) {
                        Text("9. Toggle Privacy Dots (Green/Orange)")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            IslandStateMachine.postCustomApiActivity(
                                com.ultraisland.pro.engine.activity.LiveActivity(
                                    id = "api_tasker_test",
                                    title = "Tasker: Home Arrival",
                                    subtitle = "Security armed • 24°C AC set",
                                    iconType = "tasker",
                                    colorHex = "#9C27B0",
                                    progress = 75,
                                    durationSeconds = 120
                                ),
                                autoExpand = true
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9C27B0))
                    ) {
                        Text("10. Public API Live Activity (Tasker)")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            TimerManager.reset()
                            IslandStateMachine.clearAll()
                            IslandStateMachine.updatePrivacyState(PrivacyIndicatorsState())
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f))
                    ) {
                        Text("Clear All to Idle Pill", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun SetupScreen(onOpenDiagnostics: () -> Unit = {}) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var autoSetupRunning by remember { mutableStateOf(false) }
    var autoSetupLog by remember { mutableStateOf<String?>(null) }

    val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
    val enabledServices = am?.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK) ?: emptyList()
    val isAccessibilityActive = enabledServices.any {
        it.resolveInfo.serviceInfo.packageName == context.packageName &&
                it.resolveInfo.serviceInfo.name == IslandAccessibilityService::class.java.name
    }

    val isNotifListenerActive = Settings.Secure.getString(
        context.contentResolver,
        "enabled_notification_listeners"
    )?.contains(context.packageName) ?: false

    val isShizukuReady = PrivilegedManager.shizuku.hasPermission()
    val pkg = context.packageName

    val adbCommands = remember {
        listOf(
            "adb shell pm grant $pkg android.permission.ANSWER_PHONE_CALLS",
            "adb shell pm grant $pkg android.permission.READ_PHONE_STATE",
            "adb shell cmd notification allow_listener $pkg/com.ultraisland.pro.services.notification.IslandNotificationListener",
            "adb shell pm grant $pkg android.permission.WRITE_SECURE_SETTINGS",
            "adb shell appops set $pkg SYSTEM_ALERT_WINDOW allow",
            "adb shell dumpsys deviceidle whitelist +$pkg"
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Permissions & Privileged Setup", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Grant permissions for Overlay, Calls, Media, and Notifications", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Permission Status", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    StatusRow(
                        title = "Accessibility Overlay",
                        active = isAccessibilityActive,
                        actionLabel = "Enable in Settings",
                        onAction = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }) }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    StatusRow(
                        title = "Notification & Media Access",
                        active = isNotifListenerActive,
                        actionLabel = "Enable Access",
                        onAction = { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }) }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    StatusRow(
                        title = "Shizuku Privileged Access",
                        active = isShizukuReady,
                        actionLabel = "Request Shizuku",
                        onAction = { PrivilegedManager.shizuku.requestPermission() }
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onOpenDiagnostics,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF242936))
                    ) {
                        Text("Open Privileged Diagnostics & Wireless ADB", fontSize = 12.sp)
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Automatic Setup (Shizuku)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Grant Phone, Notification, and Overlay permissions via Shizuku", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (!PrivilegedManager.shizuku.hasPermission()) {
                                PrivilegedManager.shizuku.requestPermission()
                                Toast.makeText(context, "Grant Shizuku permission first", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            autoSetupRunning = true
                            scope.launch {
                                val sb = StringBuilder()
                                for (cmd in adbCommands) {
                                    val stripped = cmd.removePrefix("adb shell ")
                                    val res = PrivilegedManager.shizuku.exec(stripped)
                                    sb.append(if (res.isSuccess) "✓ " else "✗ ").append(stripped.take(35)).append("...\n")
                                }
                                autoSetupLog = sb.toString()
                                autoSetupRunning = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388AF6))
                    ) {
                        Text(if (autoSetupRunning) "Applying Grants..." else "Run Auto Setup")
                    }

                    if (autoSetupLog != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = autoSetupLog!!, color = Color(0xFF34C759), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
            }
        }

        item {
            Text("One-Time ADB Commands", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
        }

        items(adbCommands) { cmd ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101217)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = cmd,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                    )
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("ADB Command", cmd))
                            Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF242936))
                    ) {
                        Text("Copy", fontSize = 11.sp)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun StatusRow(title: String, active: Boolean, actionLabel: String, onAction: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(if (active) "Active ✓" else "Inactive ✗", color = if (active) Color(0xFF34C759) else Color(0xFFFF3B30), fontSize = 11.sp)
        }
        if (!active) {
            Button(onClick = onAction, shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388AF6))) {
                Text(actionLabel, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun SliderItem(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    unit: String,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            Text(String.format("%.1f %s", value, unit), color = Color(0xFF388AF6), fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Color(0xFF388AF6), activeTrackColor = Color(0xFF388AF6), inactiveTrackColor = Color.White.copy(alpha = 0.15f))
        )
    }
}
