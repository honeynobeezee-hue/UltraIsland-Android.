package com.ultraisland.pro.core.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "island_settings")

data class IslandSettingsState(
    val islandEnabled: Boolean = true,
    val widthDp: Int = 110,
    val heightDp: Int = 36,
    val offsetX: Int = 0,
    val offsetY: Int = 12,
    val cornerRadius: Int = 24,
    val animSpeed: Float = 1.0f,
    val hapticEnabled: Boolean = true,

    // Phase 6A: Appearance & Opacity
    val backgroundOpacity: Float = 0.95f,
    val backgroundBlurRadius: Int = 16,
    val cardBlurEnabled: Boolean = true,
    val albumBackdropBlur: Boolean = true,
    val colorTheme: ColorTheme = ColorTheme.NOIR_OLED,
    val gradientEnabled: Boolean = false,
    val gradientSecondColorHex: String = "#8A2BE2",
    val ambientDropShadow: Boolean = true,
    val showGlowFlash: Boolean = true,
    val showOutlineBorder: Boolean = true,
    val ledColorHex: String = "#00FF66",
    val perActivityTextScale: Float = 1.0f,
    val perActivityCornerRadius: Int = 24,

    // Phase 6A: Layout & Presets
    val cutoutWidth: Int = 110,
    val cutoutHeight: Int = 36,
    val centreXOffset: Int = 0,
    val topYOffset: Int = 12,
    val collapsedCutoutWidthWithContent: Int = 160,
    val mergeStyle: MergeStyle = MergeStyle.MERGE,
    val alternateByOrientation: Boolean = false,
    val landscapeCutoutWidth: Int = 120,
    val landscapeCutoutHeight: Int = 34,
    val landscapeTopYOffset: Int = 8,
    val activePresetName: String = "iPhone 15 Pro",
    val customPresetsJson: String = "[]",

    // Phase 6A: Fonts & Clock
    val fontOption: FontOption = FontOption.SYSTEM,
    val customFontUri: String? = null,
    val mixFonts: Boolean = false,
    val showHourTick: Boolean = true,
    val clockFormatStyle: String = "HH:mm",
    val weatherUnitCelsius: Boolean = true,
    val windSpeedUnit: String = "km/h",
    val batteryStyle: String = "PERCENT_ICON",

    // Phase 6A: Animations & Physics
    val animationStyle: AnimationStyle = AnimationStyle.IOS_SPRING,
    val speedMultiplierPortrait: Float = 1.0f,
    val speedMultiplierLandscape: Float = 1.0f,
    val springDamping: Float = 0.72f,
    val springStiffness: Float = 380f,
    val hapticIntensity: Int = 2, // 1: Light, 2: Medium, 3: Strong

    // Phase 2: Notification & Anti-spam Settings
    val autoExpandNotification: Boolean = true,
    val hideNotificationOnLockscreen: Boolean = false,
    val hideSystemHeadsUp: Boolean = false,
    val dismissClearsSystemNotification: Boolean = true,
    val antiSpamThreshold: Int = 5,
    val antiSpamCooldownSeconds: Int = 30,
    val appRules: Map<String, AppNotificationRule> = emptyMap(),
    val antiSpamWhitelist: Set<String> = emptySet()
)

object SettingsRepository {
    private lateinit var appContext: Context

    // Master & Base Geometry Keys
    private val KEY_ISLAND_ENABLED = booleanPreferencesKey("island_enabled")
    private val KEY_WIDTH_DP = intPreferencesKey("width_dp")
    private val KEY_HEIGHT_DP = intPreferencesKey("height_dp")
    private val KEY_OFFSET_X = intPreferencesKey("offset_x")
    private val KEY_OFFSET_Y = intPreferencesKey("offset_y")
    private val KEY_CORNER_RADIUS = intPreferencesKey("corner_radius")
    private val KEY_ANIM_SPEED = floatPreferencesKey("anim_speed")
    private val KEY_HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")

    // Phase 6A: Appearance Keys
    private val KEY_BG_OPACITY = floatPreferencesKey("bg_opacity")
    private val KEY_BG_BLUR_RADIUS = intPreferencesKey("bg_blur_radius")
    private val KEY_CARD_BLUR_ENABLED = booleanPreferencesKey("card_blur_enabled")
    private val KEY_ALBUM_BACKDROP_BLUR = booleanPreferencesKey("album_backdrop_blur")
    private val KEY_COLOR_THEME = stringPreferencesKey("color_theme")
    private val KEY_GRADIENT_ENABLED = booleanPreferencesKey("gradient_enabled")
    private val KEY_GRADIENT_SECOND_COLOR = stringPreferencesKey("gradient_second_color")
    private val KEY_AMBIENT_DROP_SHADOW = booleanPreferencesKey("ambient_drop_shadow")
    private val KEY_SHOW_GLOW_FLASH = booleanPreferencesKey("show_glow_flash")
    private val KEY_SHOW_OUTLINE_BORDER = booleanPreferencesKey("show_outline_border")
    private val KEY_LED_COLOR_HEX = stringPreferencesKey("led_color_hex")
    private val KEY_PER_ACTIVITY_TEXT_SCALE = floatPreferencesKey("per_activity_text_scale")
    private val KEY_PER_ACTIVITY_CORNER_RADIUS = intPreferencesKey("per_activity_corner_radius")

    // Phase 6A: Layout & Orientation Keys
    private val KEY_COLLAPSED_WIDTH_CONTENT = intPreferencesKey("collapsed_width_content")
    private val KEY_MERGE_STYLE = stringPreferencesKey("merge_style")
    private val KEY_ALTERNATE_ORIENTATION = booleanPreferencesKey("alternate_orientation")
    private val KEY_LANDSCAPE_CUTOUT_WIDTH = intPreferencesKey("landscape_cutout_width")
    private val KEY_LANDSCAPE_CUTOUT_HEIGHT = intPreferencesKey("landscape_cutout_height")
    private val KEY_LANDSCAPE_TOP_Y = intPreferencesKey("landscape_top_y")
    private val KEY_ACTIVE_PRESET_NAME = stringPreferencesKey("active_preset_name")
    private val KEY_CUSTOM_PRESETS_JSON = stringPreferencesKey("custom_presets_json")

    // Phase 6A: Fonts & Clock Keys
    private val KEY_FONT_OPTION = stringPreferencesKey("font_option")
    private val KEY_CUSTOM_FONT_URI = stringPreferencesKey("custom_font_uri")
    private val KEY_MIX_FONTS = booleanPreferencesKey("mix_fonts")
    private val KEY_SHOW_HOUR_TICK = booleanPreferencesKey("show_hour_tick")
    private val KEY_CLOCK_FORMAT_STYLE = stringPreferencesKey("clock_format_style")
    private val KEY_WEATHER_UNIT_CELSIUS = booleanPreferencesKey("weather_unit_celsius")
    private val KEY_WIND_SPEED_UNIT = stringPreferencesKey("wind_speed_unit")
    private val KEY_BATTERY_STYLE = stringPreferencesKey("battery_style")

    // Phase 6A: Animations Keys
    private val KEY_ANIMATION_STYLE = stringPreferencesKey("animation_style")
    private val KEY_SPEED_PORTRAIT = floatPreferencesKey("speed_portrait")
    private val KEY_SPEED_LANDSCAPE = floatPreferencesKey("speed_landscape")
    private val KEY_SPRING_DAMPING = floatPreferencesKey("spring_damping")
    private val KEY_SPRING_STIFFNESS = floatPreferencesKey("spring_stiffness")
    private val KEY_HAPTIC_INTENSITY = intPreferencesKey("haptic_intensity")

    // Phase 2 Keys
    private val KEY_AUTO_EXPAND_NOTIF = booleanPreferencesKey("auto_expand_notif")
    private val KEY_HIDE_NOTIF_LOCKSCREEN = booleanPreferencesKey("hide_notif_lockscreen")
    private val KEY_HIDE_SYSTEM_HEADS_UP = booleanPreferencesKey("hide_system_heads_up")
    private val KEY_DISMISS_CLEARS_SYSTEM = booleanPreferencesKey("dismiss_clears_system")
    private val KEY_ANTI_SPAM_THRESHOLD = intPreferencesKey("anti_spam_threshold")
    private val KEY_ANTI_SPAM_COOLDOWN = intPreferencesKey("anti_spam_cooldown")
    private val KEY_APP_RULES_JSON = stringPreferencesKey("app_rules_json")
    private val KEY_ANTI_SPAM_WHITELIST_JSON = stringPreferencesKey("anti_spam_whitelist_json")

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    val settingsFlow: Flow<IslandSettingsState> by lazy {
        appContext.dataStore.data.map { prefs ->
            val rulesJson = prefs[KEY_APP_RULES_JSON] ?: "{}"
            val whitelistJson = prefs[KEY_ANTI_SPAM_WHITELIST_JSON] ?: "[]"

            val width = prefs[KEY_WIDTH_DP] ?: 110
            val height = prefs[KEY_HEIGHT_DP] ?: 36
            val offsetX = prefs[KEY_OFFSET_X] ?: 0
            val offsetY = prefs[KEY_OFFSET_Y] ?: 12
            val cornerRadius = prefs[KEY_CORNER_RADIUS] ?: 24
            val animSpeed = prefs[KEY_ANIM_SPEED] ?: 1.0f

            IslandSettingsState(
                islandEnabled = prefs[KEY_ISLAND_ENABLED] ?: true,
                widthDp = width,
                heightDp = height,
                offsetX = offsetX,
                offsetY = offsetY,
                cornerRadius = cornerRadius,
                animSpeed = animSpeed,
                hapticEnabled = prefs[KEY_HAPTIC_ENABLED] ?: true,

                // Appearance
                backgroundOpacity = prefs[KEY_BG_OPACITY] ?: 0.95f,
                backgroundBlurRadius = prefs[KEY_BG_BLUR_RADIUS] ?: 16,
                cardBlurEnabled = prefs[KEY_CARD_BLUR_ENABLED] ?: true,
                albumBackdropBlur = prefs[KEY_ALBUM_BACKDROP_BLUR] ?: true,
                colorTheme = try {
                    ColorTheme.valueOf(prefs[KEY_COLOR_THEME] ?: ColorTheme.NOIR_OLED.name)
                } catch (_: Exception) {
                    ColorTheme.NOIR_OLED
                },
                gradientEnabled = prefs[KEY_GRADIENT_ENABLED] ?: false,
                gradientSecondColorHex = prefs[KEY_GRADIENT_SECOND_COLOR] ?: "#8A2BE2",
                ambientDropShadow = prefs[KEY_AMBIENT_DROP_SHADOW] ?: true,
                showGlowFlash = prefs[KEY_SHOW_GLOW_FLASH] ?: true,
                showOutlineBorder = prefs[KEY_SHOW_OUTLINE_BORDER] ?: true,
                ledColorHex = prefs[KEY_LED_COLOR_HEX] ?: "#00FF66",
                perActivityTextScale = prefs[KEY_PER_ACTIVITY_TEXT_SCALE] ?: 1.0f,
                perActivityCornerRadius = prefs[KEY_PER_ACTIVITY_CORNER_RADIUS] ?: 24,

                // Layout & Geometry
                cutoutWidth = width,
                cutoutHeight = height,
                centreXOffset = offsetX,
                topYOffset = offsetY,
                collapsedCutoutWidthWithContent = prefs[KEY_COLLAPSED_WIDTH_CONTENT] ?: 160,
                mergeStyle = try {
                    MergeStyle.valueOf(prefs[KEY_MERGE_STYLE] ?: MergeStyle.MERGE.name)
                } catch (_: Exception) {
                    MergeStyle.MERGE
                },
                alternateByOrientation = prefs[KEY_ALTERNATE_ORIENTATION] ?: false,
                landscapeCutoutWidth = prefs[KEY_LANDSCAPE_CUTOUT_WIDTH] ?: 120,
                landscapeCutoutHeight = prefs[KEY_LANDSCAPE_CUTOUT_HEIGHT] ?: 34,
                landscapeTopYOffset = prefs[KEY_LANDSCAPE_TOP_Y] ?: 8,
                activePresetName = prefs[KEY_ACTIVE_PRESET_NAME] ?: "iPhone 15 Pro",
                customPresetsJson = prefs[KEY_CUSTOM_PRESETS_JSON] ?: "[]",

                // Fonts & Clock
                fontOption = try {
                    FontOption.valueOf(prefs[KEY_FONT_OPTION] ?: FontOption.SYSTEM.name)
                } catch (_: Exception) {
                    FontOption.SYSTEM
                },
                customFontUri = prefs[KEY_CUSTOM_FONT_URI],
                mixFonts = prefs[KEY_MIX_FONTS] ?: false,
                showHourTick = prefs[KEY_SHOW_HOUR_TICK] ?: true,
                clockFormatStyle = prefs[KEY_CLOCK_FORMAT_STYLE] ?: "HH:mm",
                weatherUnitCelsius = prefs[KEY_WEATHER_UNIT_CELSIUS] ?: true,
                windSpeedUnit = prefs[KEY_WIND_SPEED_UNIT] ?: "km/h",
                batteryStyle = prefs[KEY_BATTERY_STYLE] ?: "PERCENT_ICON",

                // Animations & Physics
                animationStyle = try {
                    AnimationStyle.valueOf(prefs[KEY_ANIMATION_STYLE] ?: AnimationStyle.IOS_SPRING.name)
                } catch (_: Exception) {
                    AnimationStyle.IOS_SPRING
                },
                speedMultiplierPortrait = prefs[KEY_SPEED_PORTRAIT] ?: animSpeed,
                speedMultiplierLandscape = prefs[KEY_SPEED_LANDSCAPE] ?: animSpeed,
                springDamping = prefs[KEY_SPRING_DAMPING] ?: 0.72f,
                springStiffness = prefs[KEY_SPRING_STIFFNESS] ?: 380f,
                hapticIntensity = prefs[KEY_HAPTIC_INTENSITY] ?: 2,

                // Notification & Anti-spam
                autoExpandNotification = prefs[KEY_AUTO_EXPAND_NOTIF] ?: true,
                hideNotificationOnLockscreen = prefs[KEY_HIDE_NOTIF_LOCKSCREEN] ?: false,
                hideSystemHeadsUp = prefs[KEY_HIDE_SYSTEM_HEADS_UP] ?: false,
                dismissClearsSystemNotification = prefs[KEY_DISMISS_CLEARS_SYSTEM] ?: true,
                antiSpamThreshold = prefs[KEY_ANTI_SPAM_THRESHOLD] ?: 5,
                antiSpamCooldownSeconds = prefs[KEY_ANTI_SPAM_COOLDOWN] ?: 30,
                appRules = parseRules(rulesJson),
                antiSpamWhitelist = parseWhitelist(whitelistJson)
            )
        }
    }

    suspend fun updateSettings(transform: (IslandSettingsState) -> IslandSettingsState) {
        appContext.dataStore.edit { prefs ->
            val rulesJson = prefs[KEY_APP_RULES_JSON] ?: "{}"
            val whitelistJson = prefs[KEY_ANTI_SPAM_WHITELIST_JSON] ?: "[]"

            val width = prefs[KEY_WIDTH_DP] ?: 110
            val height = prefs[KEY_HEIGHT_DP] ?: 36
            val offsetX = prefs[KEY_OFFSET_X] ?: 0
            val offsetY = prefs[KEY_OFFSET_Y] ?: 12
            val cornerRadius = prefs[KEY_CORNER_RADIUS] ?: 24
            val animSpeed = prefs[KEY_ANIM_SPEED] ?: 1.0f

            val current = IslandSettingsState(
                islandEnabled = prefs[KEY_ISLAND_ENABLED] ?: true,
                widthDp = width,
                heightDp = height,
                offsetX = offsetX,
                offsetY = offsetY,
                cornerRadius = cornerRadius,
                animSpeed = animSpeed,
                hapticEnabled = prefs[KEY_HAPTIC_ENABLED] ?: true,

                backgroundOpacity = prefs[KEY_BG_OPACITY] ?: 0.95f,
                backgroundBlurRadius = prefs[KEY_BG_BLUR_RADIUS] ?: 16,
                cardBlurEnabled = prefs[KEY_CARD_BLUR_ENABLED] ?: true,
                albumBackdropBlur = prefs[KEY_ALBUM_BACKDROP_BLUR] ?: true,
                colorTheme = try {
                    ColorTheme.valueOf(prefs[KEY_COLOR_THEME] ?: ColorTheme.NOIR_OLED.name)
                } catch (_: Exception) {
                    ColorTheme.NOIR_OLED
                },
                gradientEnabled = prefs[KEY_GRADIENT_ENABLED] ?: false,
                gradientSecondColorHex = prefs[KEY_GRADIENT_SECOND_COLOR] ?: "#8A2BE2",
                ambientDropShadow = prefs[KEY_AMBIENT_DROP_SHADOW] ?: true,
                showGlowFlash = prefs[KEY_SHOW_GLOW_FLASH] ?: true,
                showOutlineBorder = prefs[KEY_SHOW_OUTLINE_BORDER] ?: true,
                ledColorHex = prefs[KEY_LED_COLOR_HEX] ?: "#00FF66",
                perActivityTextScale = prefs[KEY_PER_ACTIVITY_TEXT_SCALE] ?: 1.0f,
                perActivityCornerRadius = prefs[KEY_PER_ACTIVITY_CORNER_RADIUS] ?: 24,

                cutoutWidth = width,
                cutoutHeight = height,
                centreXOffset = offsetX,
                topYOffset = offsetY,
                collapsedCutoutWidthWithContent = prefs[KEY_COLLAPSED_WIDTH_CONTENT] ?: 160,
                mergeStyle = try {
                    MergeStyle.valueOf(prefs[KEY_MERGE_STYLE] ?: MergeStyle.MERGE.name)
                } catch (_: Exception) {
                    MergeStyle.MERGE
                },
                alternateByOrientation = prefs[KEY_ALTERNATE_ORIENTATION] ?: false,
                landscapeCutoutWidth = prefs[KEY_LANDSCAPE_CUTOUT_WIDTH] ?: 120,
                landscapeCutoutHeight = prefs[KEY_LANDSCAPE_CUTOUT_HEIGHT] ?: 34,
                landscapeTopYOffset = prefs[KEY_LANDSCAPE_TOP_Y] ?: 8,
                activePresetName = prefs[KEY_ACTIVE_PRESET_NAME] ?: "iPhone 15 Pro",
                customPresetsJson = prefs[KEY_CUSTOM_PRESETS_JSON] ?: "[]",

                fontOption = try {
                    FontOption.valueOf(prefs[KEY_FONT_OPTION] ?: FontOption.SYSTEM.name)
                } catch (_: Exception) {
                    FontOption.SYSTEM
                },
                customFontUri = prefs[KEY_CUSTOM_FONT_URI],
                mixFonts = prefs[KEY_MIX_FONTS] ?: false,
                showHourTick = prefs[KEY_SHOW_HOUR_TICK] ?: true,
                clockFormatStyle = prefs[KEY_CLOCK_FORMAT_STYLE] ?: "HH:mm",
                weatherUnitCelsius = prefs[KEY_WEATHER_UNIT_CELSIUS] ?: true,
                windSpeedUnit = prefs[KEY_WIND_SPEED_UNIT] ?: "km/h",
                batteryStyle = prefs[KEY_BATTERY_STYLE] ?: "PERCENT_ICON",

                animationStyle = try {
                    AnimationStyle.valueOf(prefs[KEY_ANIMATION_STYLE] ?: AnimationStyle.IOS_SPRING.name)
                } catch (_: Exception) {
                    AnimationStyle.IOS_SPRING
                },
                speedMultiplierPortrait = prefs[KEY_SPEED_PORTRAIT] ?: animSpeed,
                speedMultiplierLandscape = prefs[KEY_SPEED_LANDSCAPE] ?: animSpeed,
                springDamping = prefs[KEY_SPRING_DAMPING] ?: 0.72f,
                springStiffness = prefs[KEY_SPRING_STIFFNESS] ?: 380f,
                hapticIntensity = prefs[KEY_HAPTIC_INTENSITY] ?: 2,

                autoExpandNotification = prefs[KEY_AUTO_EXPAND_NOTIF] ?: true,
                hideNotificationOnLockscreen = prefs[KEY_HIDE_NOTIF_LOCKSCREEN] ?: false,
                hideSystemHeadsUp = prefs[KEY_HIDE_SYSTEM_HEADS_UP] ?: false,
                dismissClearsSystemNotification = prefs[KEY_DISMISS_CLEARS_SYSTEM] ?: true,
                antiSpamThreshold = prefs[KEY_ANTI_SPAM_THRESHOLD] ?: 5,
                antiSpamCooldownSeconds = prefs[KEY_ANTI_SPAM_COOLDOWN] ?: 30,
                appRules = parseRules(rulesJson),
                antiSpamWhitelist = parseWhitelist(whitelistJson)
            )

            val updated = transform(current)

            // Persist master & base geometry
            prefs[KEY_ISLAND_ENABLED] = updated.islandEnabled
            prefs[KEY_WIDTH_DP] = updated.widthDp
            prefs[KEY_HEIGHT_DP] = updated.heightDp
            prefs[KEY_OFFSET_X] = updated.offsetX
            prefs[KEY_OFFSET_Y] = updated.offsetY
            prefs[KEY_CORNER_RADIUS] = updated.cornerRadius
            prefs[KEY_ANIM_SPEED] = updated.animSpeed
            prefs[KEY_HAPTIC_ENABLED] = updated.hapticEnabled

            // Persist Appearance
            prefs[KEY_BG_OPACITY] = updated.backgroundOpacity
            prefs[KEY_BG_BLUR_RADIUS] = updated.backgroundBlurRadius
            prefs[KEY_CARD_BLUR_ENABLED] = updated.cardBlurEnabled
            prefs[KEY_ALBUM_BACKDROP_BLUR] = updated.albumBackdropBlur
            prefs[KEY_COLOR_THEME] = updated.colorTheme.name
            prefs[KEY_GRADIENT_ENABLED] = updated.gradientEnabled
            prefs[KEY_GRADIENT_SECOND_COLOR] = updated.gradientSecondColorHex
            prefs[KEY_AMBIENT_DROP_SHADOW] = updated.ambientDropShadow
            prefs[KEY_SHOW_GLOW_FLASH] = updated.showGlowFlash
            prefs[KEY_SHOW_OUTLINE_BORDER] = updated.showOutlineBorder
            prefs[KEY_LED_COLOR_HEX] = updated.ledColorHex
            prefs[KEY_PER_ACTIVITY_TEXT_SCALE] = updated.perActivityTextScale
            prefs[KEY_PER_ACTIVITY_CORNER_RADIUS] = updated.perActivityCornerRadius

            // Persist Layout & Orientation
            prefs[KEY_COLLAPSED_WIDTH_CONTENT] = updated.collapsedCutoutWidthWithContent
            prefs[KEY_MERGE_STYLE] = updated.mergeStyle.name
            prefs[KEY_ALTERNATE_ORIENTATION] = updated.alternateByOrientation
            prefs[KEY_LANDSCAPE_CUTOUT_WIDTH] = updated.landscapeCutoutWidth
            prefs[KEY_LANDSCAPE_CUTOUT_HEIGHT] = updated.landscapeCutoutHeight
            prefs[KEY_LANDSCAPE_TOP_Y] = updated.landscapeTopYOffset
            prefs[KEY_ACTIVE_PRESET_NAME] = updated.activePresetName
            prefs[KEY_CUSTOM_PRESETS_JSON] = updated.customPresetsJson

            // Persist Fonts & Clock
            prefs[KEY_FONT_OPTION] = updated.fontOption.name
            if (updated.customFontUri != null) {
                prefs[KEY_CUSTOM_FONT_URI] = updated.customFontUri
            } else {
                prefs.remove(KEY_CUSTOM_FONT_URI)
            }
            prefs[KEY_MIX_FONTS] = updated.mixFonts
            prefs[KEY_SHOW_HOUR_TICK] = updated.showHourTick
            prefs[KEY_CLOCK_FORMAT_STYLE] = updated.clockFormatStyle
            prefs[KEY_WEATHER_UNIT_CELSIUS] = updated.weatherUnitCelsius
            prefs[KEY_WIND_SPEED_UNIT] = updated.windSpeedUnit
            prefs[KEY_BATTERY_STYLE] = updated.batteryStyle

            // Persist Animations & Physics
            prefs[KEY_ANIMATION_STYLE] = updated.animationStyle.name
            prefs[KEY_SPEED_PORTRAIT] = updated.speedMultiplierPortrait
            prefs[KEY_SPEED_LANDSCAPE] = updated.speedMultiplierLandscape
            prefs[KEY_SPRING_DAMPING] = updated.springDamping
            prefs[KEY_SPRING_STIFFNESS] = updated.springStiffness
            prefs[KEY_HAPTIC_INTENSITY] = updated.hapticIntensity

            // Persist Notifications & Anti-spam
            prefs[KEY_AUTO_EXPAND_NOTIF] = updated.autoExpandNotification
            prefs[KEY_HIDE_NOTIF_LOCKSCREEN] = updated.hideNotificationOnLockscreen
            prefs[KEY_HIDE_SYSTEM_HEADS_UP] = updated.hideSystemHeadsUp
            prefs[KEY_DISMISS_CLEARS_SYSTEM] = updated.dismissClearsSystemNotification
            prefs[KEY_ANTI_SPAM_THRESHOLD] = updated.antiSpamThreshold
            prefs[KEY_ANTI_SPAM_COOLDOWN] = updated.antiSpamCooldownSeconds
            prefs[KEY_APP_RULES_JSON] = serializeRules(updated.appRules)
            prefs[KEY_ANTI_SPAM_WHITELIST_JSON] = serializeWhitelist(updated.antiSpamWhitelist)
        }
    }

    suspend fun applyBuiltinPreset(presetName: String) {
        updateSettings { cur ->
            when (presetName) {
                "iPhone 15 Pro" -> cur.copy(
                    widthDp = 110,
                    heightDp = 36,
                    offsetX = 0,
                    offsetY = 12,
                    cornerRadius = 24,
                    mergeStyle = MergeStyle.MERGE,
                    activePresetName = presetName
                )
                "iPhone 16 Pro" -> cur.copy(
                    widthDp = 100,
                    heightDp = 34,
                    offsetX = 0,
                    offsetY = 10,
                    cornerRadius = 24,
                    mergeStyle = MergeStyle.MERGE,
                    activePresetName = presetName
                )
                "Center Hole" -> cur.copy(
                    widthDp = 84,
                    heightDp = 32,
                    offsetX = 0,
                    offsetY = 14,
                    cornerRadius = 20,
                    mergeStyle = MergeStyle.CENTER_HOLE,
                    activePresetName = presetName
                )
                "Wide Island" -> cur.copy(
                    widthDp = 160,
                    heightDp = 38,
                    offsetX = 0,
                    offsetY = 10,
                    cornerRadius = 26,
                    mergeStyle = MergeStyle.WIDE,
                    activePresetName = presetName
                )
                "Nothing-style" -> cur.copy(
                    widthDp = 80,
                    heightDp = 32,
                    offsetX = 0,
                    offsetY = 12,
                    cornerRadius = 18,
                    mergeStyle = MergeStyle.SEPARATE,
                    activePresetName = presetName
                )
                "Minimal" -> cur.copy(
                    widthDp = 72,
                    heightDp = 28,
                    offsetX = 0,
                    offsetY = 16,
                    cornerRadius = 16,
                    mergeStyle = MergeStyle.CENTER_HOLE,
                    activePresetName = presetName
                )
                else -> cur
            }
        }
    }

    suspend fun saveCustomPreset(name: String) {
        updateSettings { cur ->
            val list = parseCustomPresets(cur.customPresetsJson).toMutableList()
            list.removeAll { it.name.equals(name, ignoreCase = true) }
            list.add(
                CustomPreset(
                    name = name,
                    cutoutWidth = cur.widthDp,
                    cutoutHeight = cur.heightDp,
                    centreXOffset = cur.offsetX,
                    topYOffset = cur.offsetY,
                    cornerRadius = cur.cornerRadius,
                    mergeStyle = cur.mergeStyle
                )
            )
            cur.copy(
                activePresetName = name,
                customPresetsJson = serializeCustomPresets(list)
            )
        }
    }

    suspend fun deleteCustomPreset(name: String) {
        updateSettings { cur ->
            val list = parseCustomPresets(cur.customPresetsJson).toMutableList()
            list.removeAll { it.name.equals(name, ignoreCase = true) }
            cur.copy(customPresetsJson = serializeCustomPresets(list))
        }
    }

    suspend fun applyCustomPreset(preset: CustomPreset) {
        updateSettings { cur ->
            cur.copy(
                widthDp = preset.cutoutWidth,
                heightDp = preset.cutoutHeight,
                offsetX = preset.centreXOffset,
                offsetY = preset.topYOffset,
                cornerRadius = preset.cornerRadius,
                mergeStyle = preset.mergeStyle,
                activePresetName = preset.name
            )
        }
    }

    fun parseCustomPresets(jsonStr: String): List<CustomPreset> {
        val list = mutableListOf<CustomPreset>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    CustomPreset(
                        name = obj.getString("name"),
                        cutoutWidth = obj.getInt("cutoutWidth"),
                        cutoutHeight = obj.getInt("cutoutHeight"),
                        centreXOffset = obj.getInt("centreXOffset"),
                        topYOffset = obj.getInt("topYOffset"),
                        cornerRadius = obj.getInt("cornerRadius"),
                        mergeStyle = try {
                            MergeStyle.valueOf(obj.getString("mergeStyle"))
                        } catch (_: Exception) {
                            MergeStyle.MERGE
                        }
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun serializeCustomPresets(list: List<CustomPreset>): String {
        val arr = JSONArray()
        list.forEach { p ->
            val obj = JSONObject()
            obj.put("name", p.name)
            obj.put("cutoutWidth", p.cutoutWidth)
            obj.put("cutoutHeight", p.cutoutHeight)
            obj.put("centreXOffset", p.centreXOffset)
            obj.put("topYOffset", p.topYOffset)
            obj.put("cornerRadius", p.cornerRadius)
            obj.put("mergeStyle", p.mergeStyle.name)
            arr.put(obj)
        }
        return arr.toString()
    }

    private fun parseRules(jsonStr: String): Map<String, AppNotificationRule> {
        val result = mutableMapOf<String, AppNotificationRule>()
        try {
            val json = JSONObject(jsonStr)
            val keys = json.keys()
            while (keys.hasNext()) {
                val pkg = keys.next()
                val obj = json.getJSONObject(pkg)
                result[pkg] = AppNotificationRule(
                    packageName = pkg,
                    enabled = obj.optBoolean("enabled", true),
                    isPrivate = obj.optBoolean("isPrivate", false),
                    alwaysAlert = obj.optBoolean("alwaysAlert", false),
                    customColorHex = if (obj.has("color")) obj.getString("color") else null
                )
            }
        } catch (_: Exception) {}
        return result
    }

    private fun serializeRules(rules: Map<String, AppNotificationRule>): String {
        val json = JSONObject()
        rules.forEach { (pkg, rule) ->
            val obj = JSONObject()
            obj.put("enabled", rule.enabled)
            obj.put("isPrivate", rule.isPrivate)
            obj.put("alwaysAlert", rule.alwaysAlert)
            rule.customColorHex?.let { obj.put("color", it) }
            json.put(pkg, obj)
        }
        return json.toString()
    }

    private fun parseWhitelist(jsonStr: String): Set<String> {
        val set = mutableSetOf<String>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                set.add(arr.getString(i))
            }
        } catch (_: Exception) {}
        return set
    }

    private fun serializeWhitelist(set: Set<String>): String {
        val arr = JSONArray()
        set.forEach { arr.put(it) }
        return arr.toString()
    }
}
