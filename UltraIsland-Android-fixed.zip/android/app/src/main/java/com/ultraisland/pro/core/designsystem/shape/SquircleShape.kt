package com.ultraisland.pro.core.designsystem.shape

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

/**
 * Continuous corner / squircle approximation for iOS-like Dynamic Island.
 */
class SquircleShape(
    private val cornerRadiusDp: Dp = 24.dp,
    private val curvatureFactor: Float = 1.0f
) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline {
        val radiusPx = with(density) { cornerRadiusDp.toPx() }.coerceAtMost(size.height / 2f).coerceAtMost(size.width / 2f)
        val path = Path().apply {
            addRoundRect(
                RoundRect(
                    left = 0f,
                    top = 0f,
                    right = size.width,
                    bottom = size.height,
                    radiusX = radiusPx,
                    radiusY = radiusPx
                )
            )
        }
        return Outline.Generic(path)
    }
}
