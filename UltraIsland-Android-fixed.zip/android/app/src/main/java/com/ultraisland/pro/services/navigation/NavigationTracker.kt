package com.ultraisland.pro.services.navigation

import android.app.Notification
import android.content.Context
import android.service.notification.StatusBarNotification
import android.util.Log
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import java.util.regex.Pattern

enum class ManeuverType {
    STRAIGHT,
    TURN_LEFT,
    TURN_RIGHT,
    SLIGHT_LEFT,
    SLIGHT_RIGHT,
    SHARP_LEFT,
    SHARP_RIGHT,
    U_TURN,
    ROUNDABOUT,
    ARRIVED,
    UNKNOWN
}

data class NavigationInfo(
    val packageName: String,
    val appName: String,
    val direction: String,
    val distance: String,
    val nextStreet: String,
    val eta: String,
    val maneuver: ManeuverType,
    val rawTitle: String,
    val rawText: String,
    val timestamp: Long = System.currentTimeMillis()
)

object NavigationTracker {
    private const val TAG = "NavigationTracker"

    // Supported navigation packages
    val SUPPORTED_PACKAGES = setOf(
        "com.google.android.apps.maps",
        "com.waze",
        "net.osmand",
        "net.osmand.plus"
    )

    private var currentNav: NavigationInfo? = null

    fun isNavigationPackage(packageName: String): Boolean {
        return SUPPORTED_PACKAGES.contains(packageName)
    }

    /**
     * Parses StatusBarNotification and posts to IslandStateMachine if valid live navigation.
     * Returns true if parsed and handled, false if false-positive or non-navigational.
     */
    fun processNotification(sbn: StatusBarNotification, context: Context): Boolean {
        val pkg = sbn.packageName
        if (!isNavigationPackage(pkg)) return false

        val notif = sbn.notification ?: return false

        // 1. False-positive check: Must be an ongoing notification
        val isOngoing = (notif.flags and Notification.FLAG_ONGOING_EVENT) != 0 ||
                (notif.flags and Notification.FLAG_FOREGROUND_SERVICE) != 0
        if (!isOngoing) {
            Log.d(TAG, "Ignoring non-ongoing notification from $pkg")
            return false
        }

        val extras = notif.extras ?: return false
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim().orEmpty()

        // 2. False-positive check: Filter out background location / static status alerts
        val combined = "$title $text $subText".lowercase()
        if (combined.contains("offline") ||
            combined.contains("downloading") ||
            combined.contains("running in the background") ||
            combined.contains("tap to return") && !hasManeuverOrDistance(combined)
        ) {
            Log.d(TAG, "Filtered out background/static notification: $combined")
            return false
        }

        // 3. Check for navigation completion / arrival
        if (combined.contains("arrived at your destination") || combined.contains("telah sampai")) {
            val appName = getAppName(pkg, context)
            val info = NavigationInfo(
                packageName = pkg,
                appName = appName,
                direction = "Arrived at destination",
                distance = "0 m",
                nextStreet = title,
                eta = "Arrived",
                maneuver = ManeuverType.ARRIVED,
                rawTitle = title,
                rawText = text
            )
            currentNav = info
            IslandStateMachine.postNavigation(info, autoExpand = true)
            return true
        }

        // 4. Extract Maneuver, Distance, and ETA
        val maneuver = parseManeuver(combined)
        val distance = parseDistance(title, text, subText)
        val eta = parseEta(title, text, subText)
        val nextStreet = parseNextStreet(title, text)

        val appName = getAppName(pkg, context)
        val navInfo = NavigationInfo(
            packageName = pkg,
            appName = appName,
            direction = if (title.isNotEmpty()) title else "Navigating",
            distance = distance,
            nextStreet = nextStreet,
            eta = eta,
            maneuver = maneuver,
            rawTitle = title,
            rawText = text
        )

        currentNav = navInfo
        IslandStateMachine.postNavigation(navInfo, autoExpand = false)
        return true
    }

    fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (isNavigationPackage(sbn.packageName)) {
            currentNav = null
            IslandStateMachine.clearNavigation()
        }
    }

    fun clear() {
        currentNav = null
        IslandStateMachine.clearNavigation()
    }

    private fun hasManeuverOrDistance(text: String): Boolean {
        val distanceRegex = "(\\d+(\\.\\d+)?)\\s*(m|km|ft|mi|meter|miles)".toRegex()
        return distanceRegex.containsMatchIn(text) ||
                text.contains("turn") || text.contains("belok") ||
                text.contains("exit") || text.contains("keluar") ||
                text.contains("keep") || text.contains("lurus")
    }

    private fun parseManeuver(text: String): ManeuverType {
        return when {
            text.contains("u-turn") || text.contains("putar balik") -> ManeuverType.U_TURN
            text.contains("slight left") || text.contains("serong kiri") -> ManeuverType.SLIGHT_LEFT
            text.contains("slight right") || text.contains("serong kanan") -> ManeuverType.SLIGHT_RIGHT
            text.contains("sharp left") -> ManeuverType.SHARP_LEFT
            text.contains("sharp right") -> ManeuverType.SHARP_RIGHT
            text.contains("turn left") || text.contains("belok kiri") || text.contains("left") -> ManeuverType.TURN_LEFT
            text.contains("turn right") || text.contains("belok kanan") || text.contains("right") -> ManeuverType.TURN_RIGHT
            text.contains("roundabout") || text.contains("bundaran") -> ManeuverType.ROUNDABOUT
            text.contains("straight") || text.contains("lurus") || text.contains("continue") -> ManeuverType.STRAIGHT
            else -> ManeuverType.STRAIGHT
        }
    }

    private fun parseDistance(title: String, text: String, subText: String): String {
        val combined = "$title • $text • $subText"
        val pattern = Pattern.compile("(\\d+(?:[.,]\\d+)?\\s*(?:m|km|ft|mi|meter|miles))", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(combined)
        return if (matcher.find()) {
            matcher.group(1)?.trim() ?: "In 200 m"
        } else {
            "200 m"
        }
    }

    private fun parseEta(title: String, text: String, subText: String): String {
        val combined = "$text • $subText • $title"
        // Look for ETA like "14 min", "10:30 AM", "ETA 12:45"
        val etaPattern = Pattern.compile("(\\d+\\s*(?:min|mins|menit)|\\d{1,2}:\\d{2}\\s*(?:AM|PM|am|pm)?)", Pattern.CASE_INSENSITIVE)
        val matcher = etaPattern.matcher(combined)
        return if (matcher.find()) {
            matcher.group(1)?.trim() ?: "12 min"
        } else {
            "15 min"
        }
    }

    private fun parseNextStreet(title: String, text: String): String {
        return when {
            title.contains("onto", ignoreCase = true) -> title.substringAfter("onto", "").trim()
            title.contains("ke", ignoreCase = true) -> title.substringAfter("ke", "").trim()
            text.isNotEmpty() -> text
            else -> title
        }
    }

    private fun getAppName(packageName: String, context: Context): String {
        return try {
            val pm = context.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            when (packageName) {
                "com.google.android.apps.maps" -> "Google Maps"
                "com.waze" -> "Waze"
                "net.osmand", "net.osmand.plus" -> "OsmAnd"
                else -> "Navigation"
            }
        }
    }
}
