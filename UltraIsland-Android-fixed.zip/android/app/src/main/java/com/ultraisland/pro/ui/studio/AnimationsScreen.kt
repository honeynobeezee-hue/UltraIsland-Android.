package com.ultraisland.pro.ui.studio

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.R
import com.ultraisland.pro.core.datastore.AnimationStyle
import com.ultraisland.pro.core.datastore.IslandSettingsState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimationsScreen(
    settings: IslandSettingsState,
    onUpdate: ((IslandSettingsState) -> IslandSettingsState) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.animations_title),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = stringResource(R.string.animations_subtitle),
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF090A0D))
            )
        },
        containerColor = Color(0xFF090A0D)
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Preview Island
            item {
                Spacer(modifier = Modifier.height(4.dp))
                StudioLivePreview(settings = settings)
            }

            // Section 1: Physics Engine Style
            item {
                StudioSectionCard(
                    title = stringResource(R.string.animation_style_title),
                    subtitle = "Select dynamic curve and spring characteristics"
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioChip(
                            label = "iOS Spring",
                            isSelected = settings.animationStyle == AnimationStyle.IOS_SPRING,
                            onClick = {
                                onUpdate { s ->
                                    s.copy(
                                        animationStyle = AnimationStyle.IOS_SPRING,
                                        springDamping = 0.72f,
                                        springStiffness = 380f
                                    )
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Expressive",
                            isSelected = settings.animationStyle == AnimationStyle.MATERIAL_EXPRESSIVE,
                            onClick = {
                                onUpdate { s ->
                                    s.copy(
                                        animationStyle = AnimationStyle.MATERIAL_EXPRESSIVE,
                                        springDamping = 0.85f,
                                        springStiffness = 500f
                                    )
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Bouncy",
                            isSelected = settings.animationStyle == AnimationStyle.BOUNCY,
                            onClick = {
                                onUpdate { s ->
                                    s.copy(
                                        animationStyle = AnimationStyle.BOUNCY,
                                        springDamping = 0.55f,
                                        springStiffness = 320f
                                    )
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioChip(
                            label = "Smooth Linear",
                            isSelected = settings.animationStyle == AnimationStyle.SMOOTH_LINEAR,
                            onClick = { onUpdate { s -> s.copy(animationStyle = AnimationStyle.SMOOTH_LINEAR) } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Minimal",
                            isSelected = settings.animationStyle == AnimationStyle.MINIMAL,
                            onClick = { onUpdate { s -> s.copy(animationStyle = AnimationStyle.MINIMAL) } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Instant",
                            isSelected = settings.animationStyle == AnimationStyle.INSTANT,
                            onClick = { onUpdate { s -> s.copy(animationStyle = AnimationStyle.INSTANT) } },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Section 2: Physics Fine-Tuning
            item {
                StudioSectionCard(
                    title = "Spring Physics Tuning",
                    subtitle = "Directly adjust damping resistance and harmonic stiffness"
                ) {
                    StudioSlider(
                        title = stringResource(R.string.spring_damping_title),
                        value = settings.springDamping,
                        range = 0.3f..1.0f,
                        unit = "",
                        decimalPlaces = 2,
                        onValueChange = { onUpdate { s -> s.copy(springDamping = it) } }
                    )

                    StudioSlider(
                        title = stringResource(R.string.spring_stiffness_title),
                        value = settings.springStiffness,
                        range = 100f..800f,
                        unit = "",
                        decimalPlaces = 0,
                        onValueChange = { onUpdate { s -> s.copy(springStiffness = it) } }
                    )
                }
            }

            // Section 3: Speed Multipliers (Portrait & Landscape)
            item {
                StudioSectionCard(
                    title = "Speed Multipliers",
                    subtitle = "Separate transition velocity for portrait and landscape modes"
                ) {
                    StudioSlider(
                        title = stringResource(R.string.speed_portrait_title),
                        value = settings.speedMultiplierPortrait,
                        range = 0.5f..2.5f,
                        unit = "x",
                        decimalPlaces = 2,
                        onValueChange = { onUpdate { s -> s.copy(speedMultiplierPortrait = it, animSpeed = it) } }
                    )

                    StudioSlider(
                        title = stringResource(R.string.speed_landscape_title),
                        value = settings.speedMultiplierLandscape,
                        range = 0.5f..2.5f,
                        unit = "x",
                        decimalPlaces = 2,
                        onValueChange = { onUpdate { s -> s.copy(speedMultiplierLandscape = it) } }
                    )
                }
            }

            // Section 4: Haptic Pulse Feedback
            item {
                StudioSectionCard(
                    title = "Tactile Response",
                    subtitle = "Precision vibration motor pulse on island actions"
                ) {
                    StudioToggle(
                        title = stringResource(R.string.haptic_enabled_title),
                        subtitle = stringResource(R.string.haptic_enabled_desc),
                        checked = settings.hapticEnabled,
                        onCheckedChange = { onUpdate { s -> s.copy(hapticEnabled = it) } }
                    )

                    if (settings.hapticEnabled) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = stringResource(R.string.haptic_intensity_title),
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            StudioChip(
                                label = "Light (1)",
                                isSelected = settings.hapticIntensity == 1,
                                onClick = { onUpdate { s -> s.copy(hapticIntensity = 1) } },
                                modifier = Modifier.weight(1f)
                            )
                            StudioChip(
                                label = "Medium (2)",
                                isSelected = settings.hapticIntensity == 2,
                                onClick = { onUpdate { s -> s.copy(hapticIntensity = 2) } },
                                modifier = Modifier.weight(1f)
                            )
                            StudioChip(
                                label = "Strong (3)",
                                isSelected = settings.hapticIntensity == 3,
                                onClick = { onUpdate { s -> s.copy(hapticIntensity = 3) } },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }
}
