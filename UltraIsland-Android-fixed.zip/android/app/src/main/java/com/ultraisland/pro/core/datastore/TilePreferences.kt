package com.ultraisland.pro.core.datastore

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

val Context.tileDataStore by preferencesDataStore(name = "ultra_island_tiles")

data class CustomTileConfig(
    val slot: Int,
    val label: String,
    val iconType: String = "custom",
    val actionType: String = "TOGGLE_ISLAND", // TOGGLE_ISLAND, LAUNCH_APP, SHELL, SCREENSHOT, LOCK_SCREEN
    val targetPayload: String = "",
    val isEnabled: Boolean = true
)

object TilePreferences {
    private val TILES_CONFIG_KEY = stringPreferencesKey("custom_tiles_json")

    fun getTiles(context: Context): Flow<List<CustomTileConfig>> {
        return context.tileDataStore.data.map { prefs ->
            val jsonStr = prefs[TILES_CONFIG_KEY]
            if (jsonStr.isNullOrEmpty()) {
                defaultTiles()
            } else {
                parseTiles(jsonStr)
            }
        }
    }

    suspend fun saveTile(context: Context, tile: CustomTileConfig) {
        context.tileDataStore.edit { prefs ->
            val currentList = (prefs[TILES_CONFIG_KEY]?.let { parseTiles(it) } ?: defaultTiles()).toMutableList()
            val index = currentList.indexOfFirst { it.slot == tile.slot }
            if (index >= 0) {
                currentList[index] = tile
            } else {
                currentList.add(tile)
            }
            prefs[TILES_CONFIG_KEY] = serializeTiles(currentList)
        }
    }

    fun defaultTiles(): List<CustomTileConfig> {
        return (1..10).map { slot ->
            when (slot) {
                1 -> CustomTileConfig(slot, "Island Toggle", "island", "TOGGLE_ISLAND", "", true)
                2 -> CustomTileConfig(slot, "Quick Snap", "screenshot", "SCREENSHOT", "", true)
                3 -> CustomTileConfig(slot, "Lock Phone", "lock", "LOCK_SCREEN", "", true)
                4 -> CustomTileConfig(slot, "Wi-Fi Toggle", "custom", "SHELL", "svc wifi disable", true)
                5 -> CustomTileConfig(slot, "BT Toggle", "custom", "SHELL", "svc bluetooth disable", true)
                else -> CustomTileConfig(slot, "Tile #$slot", "custom", "LAUNCH_APP", "com.ultraisland.pro", false)
            }
        }
    }

    private fun parseTiles(json: String): List<CustomTileConfig> {
        val list = mutableListOf<CustomTileConfig>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    CustomTileConfig(
                        slot = obj.optInt("slot", i + 1),
                        label = obj.optString("label", "Tile #${i + 1}"),
                        iconType = obj.optString("iconType", "custom"),
                        actionType = obj.optString("actionType", "TOGGLE_ISLAND"),
                        targetPayload = obj.optString("targetPayload", ""),
                        isEnabled = obj.optBoolean("isEnabled", true)
                    )
                )
            }
        } catch (_: Exception) {
            return defaultTiles()
        }
        return list
    }

    private fun serializeTiles(list: List<CustomTileConfig>): String {
        val arr = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("slot", item.slot)
            obj.put("label", item.label)
            obj.put("iconType", item.iconType)
            obj.put("actionType", item.actionType)
            obj.put("targetPayload", item.targetPayload)
            obj.put("isEnabled", item.isEnabled)
            arr.put(obj)
        }
        return arr.toString()
    }
}
