package com.ultraisland.pro.services.timer

import android.app.AlarmManager
import android.content.Context
import android.os.Build
import android.util.Log
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ActiveTimerInfo(
    val title: String,
    val totalSeconds: Int,
    val remainingSeconds: Int,
    val isRunning: Boolean,
    val isStopwatch: Boolean = false
) {
    val formattedTime: String
        get() {
            val mins = remainingSeconds / 60
            val secs = remainingSeconds % 60
            return String.format(Locale.US, "%02d:%02d", mins, secs)
        }
}

object TimerManager {
    private const val TAG = "TimerManager"

    private var tickerJob: Job? = null
    private var currentTimer: ActiveTimerInfo? = null
    private var nextAlarmFormatted: String? = null

    fun startTimer(label: String = "Timer", durationSeconds: Int = 300) {
        tickerJob?.cancel()
        currentTimer = ActiveTimerInfo(
            title = label,
            totalSeconds = durationSeconds,
            remainingSeconds = durationSeconds,
            isRunning = true,
            isStopwatch = false
        )
        IslandStateMachine.postTimer(currentTimer!!, autoExpand = true)

        tickerJob = CoroutineScope(Dispatchers.Main).launch {
            while (isActive && (currentTimer?.remainingSeconds ?: 0) > 0) {
                delay(1000L)
                val updated = currentTimer?.copy(
                    remainingSeconds = (currentTimer?.remainingSeconds ?: 1) - 1
                )
                currentTimer = updated
                if (updated != null) {
                    IslandStateMachine.postTimer(updated, autoExpand = false)
                }
            }
            if ((currentTimer?.remainingSeconds ?: 0) <= 0) {
                Log.i(TAG, "Timer reached zero!")
                currentTimer = currentTimer?.copy(isRunning = false)
                currentTimer?.let { IslandStateMachine.postTimer(it, autoExpand = true) }
            }
        }
    }

    fun startStopwatch(label: String = "Stopwatch") {
        tickerJob?.cancel()
        currentTimer = ActiveTimerInfo(
            title = label,
            totalSeconds = 0,
            remainingSeconds = 0,
            isRunning = true,
            isStopwatch = true
        )
        IslandStateMachine.postTimer(currentTimer!!, autoExpand = true)

        tickerJob = CoroutineScope(Dispatchers.Main).launch {
            while (isActive) {
                delay(1000L)
                val updated = currentTimer?.copy(
                    remainingSeconds = (currentTimer?.remainingSeconds ?: 0) + 1
                )
                currentTimer = updated
                if (updated != null) {
                    IslandStateMachine.postTimer(updated, autoExpand = false)
                }
            }
        }
    }

    fun togglePauseResume() {
        val timer = currentTimer ?: return
        if (timer.isRunning) {
            tickerJob?.cancel()
            currentTimer = timer.copy(isRunning = false)
            currentTimer?.let { IslandStateMachine.postTimer(it, autoExpand = false) }
        } else {
            if (timer.isStopwatch) {
                startStopwatch(timer.title)
            } else {
                startTimer(timer.title, timer.remainingSeconds)
            }
        }
    }

    fun reset() {
        tickerJob?.cancel()
        tickerJob = null
        currentTimer = null
        IslandStateMachine.clearTimer()
    }

    fun checkNextAlarm(context: Context): String? {
        return try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            val nextAlarm = alarmManager?.nextAlarmClock
            if (nextAlarm != null) {
                val triggerTime = nextAlarm.triggerTime
                val sdf = SimpleDateFormat("h:mm a", Locale.US)
                val formatted = sdf.format(Date(triggerTime))
                nextAlarmFormatted = "Alarm $formatted"
                nextAlarmFormatted
            } else {
                nextAlarmFormatted = null
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error checking next alarm: ${e.message}")
            null
        }
    }
}
