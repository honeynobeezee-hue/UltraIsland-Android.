package com.ultraisland.pro.services.network

import android.net.TrafficStats
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

data class NetworkSpeedInfo(
    val downloadSpeedText: String = "0 B/s",
    val uploadSpeedText: String = "0 B/s",
    val downloadBytesPerSec: Long = 0,
    val uploadBytesPerSec: Long = 0,
    val formattedCombined: String = "↓ 0 B/s"
)

object NetworkSpeedTracker {
    private val _speedState = MutableStateFlow(NetworkSpeedInfo())
    val speedState: StateFlow<NetworkSpeedInfo> = _speedState.asStateFlow()

    private var trackerJob: Job? = null
    private var lastRxBytes = 0L
    private var lastTxBytes = 0L
    private var lastTimestamp = 0L

    fun startTracking(scope: CoroutineScope, sampleIntervalMs: Long = 1500L) {
        if (trackerJob?.isActive == true) return

        lastRxBytes = TrafficStats.getTotalRxBytes()
        lastTxBytes = TrafficStats.getTotalTxBytes()
        lastTimestamp = System.currentTimeMillis()

        trackerJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(sampleIntervalMs)
                updateSpeed()
            }
        }
    }

    fun stopTracking() {
        trackerJob?.cancel()
        trackerJob = null
    }

    private fun updateSpeed() {
        val currentRx = TrafficStats.getTotalRxBytes()
        val currentTx = TrafficStats.getTotalTxBytes()
        val now = System.currentTimeMillis()

        val timeDiffSec = (now - lastTimestamp) / 1000.0
        if (timeDiffSec <= 0.0) return

        val rxDelta = if (lastRxBytes > 0 && currentRx >= lastRxBytes) currentRx - lastRxBytes else 0L
        val txDelta = if (lastTxBytes > 0 && currentTx >= lastTxBytes) currentTx - lastTxBytes else 0L

        val rxBytesPerSec = (rxDelta / timeDiffSec).toLong()
        val txBytesPerSec = (txDelta / timeDiffSec).toLong()

        lastRxBytes = currentRx
        lastTxBytes = currentTx
        lastTimestamp = now

        val downFormatted = formatBytesPerSec(rxBytesPerSec)
        val upFormatted = formatBytesPerSec(txBytesPerSec)

        _speedState.value = NetworkSpeedInfo(
            downloadSpeedText = downFormatted,
            uploadSpeedText = upFormatted,
            downloadBytesPerSec = rxBytesPerSec,
            uploadBytesPerSec = txBytesPerSec,
            formattedCombined = "↓ $downFormatted"
        )
    }

    private fun formatBytesPerSec(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bytes / (1024.0 * 1024.0))
            bytes >= 1024 -> String.format(Locale.US, "%.0f KB/s", bytes / 1024.0)
            else -> "$bytes B/s"
        }
    }
}
