package com.ultraisland.pro.data

import android.content.Context

/**
 * Satu-satunya instance [UltraIslandSettingsRepository] untuk proses ini. Dipakai oleh
 * Application, MainActivity dan modul Hilt supaya semua berbagi DataStore yang sama.
 */
object UltraIslandSettingsProvider {
    @Volatile private var instance: UltraIslandSettingsRepository? = null

    val repository: UltraIslandSettingsRepository
        get() = instance ?: error("UltraIslandSettingsProvider.init(context) belum dipanggil")

    fun init(context: Context) {
        if (instance != null) return
        synchronized(this) {
            if (instance == null) instance = UltraIslandSettingsRepository(context.applicationContext)
        }
    }
}
