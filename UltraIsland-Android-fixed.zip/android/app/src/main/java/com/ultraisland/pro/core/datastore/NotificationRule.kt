package com.ultraisland.pro.core.datastore

data class AppNotificationRule(
    val packageName: String,
    val enabled: Boolean = true,
    val isPrivate: Boolean = false, // App Icon Only (Private)
    val alwaysAlert: Boolean = false,
    val customColorHex: String? = null
)
