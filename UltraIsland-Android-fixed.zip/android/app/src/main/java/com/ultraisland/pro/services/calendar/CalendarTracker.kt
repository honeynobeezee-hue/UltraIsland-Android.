package com.ultraisland.pro.services.calendar

import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.provider.CalendarContract
import android.util.Log
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class CalendarEventInfo(
    val id: Long,
    val title: String,
    val startTimeMillis: Long,
    val endTimeMillis: Long,
    val location: String?,
    val formattedTime: String,
    val relativeTime: String,
    val isAllDay: Boolean
)

object CalendarTracker {
    private const val TAG = "CalendarTracker"

    private val PROJECTION = arrayOf(
        CalendarContract.Instances.EVENT_ID,
        CalendarContract.Instances.TITLE,
        CalendarContract.Instances.BEGIN,
        CalendarContract.Instances.END,
        CalendarContract.Instances.EVENT_LOCATION,
        CalendarContract.Instances.ALL_DAY
    )

    fun hasCalendarPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.READ_CALENDAR
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Reads upcoming local calendar events within next 24 hours.
     * Strictly reads local device calendar instances; never uploads or tracks remotely.
     */
    fun getNextUpcomingEvent(context: Context): CalendarEventInfo? {
        if (!hasCalendarPermission(context)) {
            Log.d(TAG, "READ_CALENDAR permission not granted")
            return null
        }

        val now = System.currentTimeMillis()
        val oneDayLater = now + TimeUnit.HOURS.toMillis(24)

        val builder: Uri.Builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(builder, now)
        ContentUris.appendId(builder, oneDayLater)

        val cursor: Cursor? = try {
            context.contentResolver.query(
                builder.build(),
                PROJECTION,
                null,
                null,
                "${CalendarContract.Instances.BEGIN} ASC"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to query local calendar", e)
            null
        }

        cursor?.use {
            if (it.moveToFirst()) {
                val id = it.getLong(it.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_ID))
                val title = it.getString(it.getColumnIndexOrThrow(CalendarContract.Instances.TITLE)) ?: "Meeting"
                val begin = it.getLong(it.getColumnIndexOrThrow(CalendarContract.Instances.BEGIN))
                val end = it.getLong(it.getColumnIndexOrThrow(CalendarContract.Instances.END))
                val location = it.getString(it.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_LOCATION))
                val allDay = it.getInt(it.getColumnIndexOrThrow(CalendarContract.Instances.ALL_DAY)) == 1

                val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                val formattedTime = timeFormat.format(Date(begin))
                val relativeTime = formatRelativeTime(begin, now)

                return CalendarEventInfo(
                    id = id,
                    title = title,
                    startTimeMillis = begin,
                    endTimeMillis = end,
                    location = location,
                    formattedTime = formattedTime,
                    relativeTime = relativeTime,
                    isAllDay = allDay
                )
            }
        }

        return null
    }

    private fun formatRelativeTime(eventTimeMillis: Long, nowMillis: Long): String {
        val diffMillis = eventTimeMillis - nowMillis
        if (diffMillis <= 0) return "Now"
        val minutes = TimeUnit.MILLISECONDS.toMinutes(diffMillis)
        return when {
            minutes < 1 -> "in < 1 min"
            minutes < 60 -> "in $minutes min"
            else -> {
                val hours = minutes / 60
                val remainingMins = minutes % 60
                if (remainingMins == 0L) "in ${hours}h" else "in ${hours}h ${remainingMins}m"
            }
        }
    }
}
