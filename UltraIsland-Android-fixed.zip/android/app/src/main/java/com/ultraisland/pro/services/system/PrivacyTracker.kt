package com.ultraisland.pro.services.system

import android.app.AppOpsManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.ultraisland.pro.engine.statemachine.IslandStateMachine

data class PrivacyIndicatorsState(
    val isCameraActive: Boolean = false,
    val isMicActive: Boolean = false,
    val isScreenRecording: Boolean = false
) {
    val hasAnyActive: Boolean
        get() = isCameraActive || isMicActive || isScreenRecording

    val hasActiveIndicator: Boolean
        get() = hasAnyActive

    val isCameraInUse: Boolean
        get() = isCameraActive

    val isMicInUse: Boolean
        get() = isMicActive
}

object PrivacyTracker {
    private const val TAG = "PrivacyTracker"
    private var currentState = PrivacyIndicatorsState()

    fun init(context: Context) {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                appOps.startWatchingActive(
                    arrayOf(AppOpsManager.OPSTR_CAMERA, AppOpsManager.OPSTR_RECORD_AUDIO),
                    context.mainExecutor
                ) { op, _, _, active ->
                    handleOpActive(op, active)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Cannot watch AppOps active: ${e.message}")
            }
        }
    }

    private fun handleOpActive(op: String, active: Boolean) {
        currentState = when (op) {
            AppOpsManager.OPSTR_CAMERA -> currentState.copy(isCameraActive = active)
            AppOpsManager.OPSTR_RECORD_AUDIO -> currentState.copy(isMicActive = active)
            else -> currentState
        }
        Log.d(TAG, "Privacy state changed: Camera=${currentState.isCameraActive}, Mic=${currentState.isMicActive}")
        IslandStateMachine.updatePrivacyState(currentState)
    }

    fun updateScreenRecording(active: Boolean) {
        currentState = currentState.copy(isScreenRecording = active)
        IslandStateMachine.updatePrivacyState(currentState)
    }
}
