package com.ultraisland.pro.engine.activity

import android.app.PendingIntent
import android.app.RemoteInput
import android.graphics.Bitmap

data class NotificationAction(
    val title: String,
    val pendingIntent: PendingIntent?,
    val remoteInput: RemoteInput? = null,
    val isQuickReply: Boolean = remoteInput != null
)

data class NotificationActivity(
    val key: String,
    val packageName: String,
    val appName: String,
    val title: String,
    val text: String,
    val subText: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val iconBitmap: Bitmap? = null,
    val colorHex: String = "#388AF6",
    val actions: List<NotificationAction> = emptyList(),
    val groupKey: String? = null,
    val count: Int = 1,
    val isPrivate: Boolean = false
) {
    fun toLiveActivity(): LiveActivity {
        val displayTitle = if (isPrivate) appName else title
        val displaySub = if (isPrivate) "New notification" else text
        return LiveActivity(
            id = key,
            title = displayTitle,
            subtitle = displaySub,
            iconType = "notification",
            colorHex = colorHex,
            timestamp = timestamp
        )
    }
}
