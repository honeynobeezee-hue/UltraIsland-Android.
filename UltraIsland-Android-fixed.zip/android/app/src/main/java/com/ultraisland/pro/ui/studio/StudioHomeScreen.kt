package com.ultraisland.pro.ui.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.R
import com.ultraisland.pro.core.datastore.IslandSettingsState

data class StudioCategoryItem(
    val id: String,
    val titleRes: Int,
    val descRes: Int,
    val icon: ImageVector,
    val iconTint: Color,
    val keywords: List<String>
)

@Composable
fun StudioHomeScreen(
    settings: IslandSettingsState,
    hasCoreOverlayPermission: Boolean,
    onNavigateToCategory: (String) -> Unit,
    onOpenAccessibility: () -> Unit,
    onOpenOverlay: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val categories = remember {
        listOf(
            StudioCategoryItem(
                id = "live_activities",
                titleRes = R.string.cat_live_activities_title,
                descRes = R.string.cat_live_activities_desc,
                icon = Icons.Default.PlayArrow,
                iconTint = Color(0xFF388AF6),
                keywords = listOf("activity", "media", "call", "telepon", "timer", "navigation", "charging", "battery")
            ),
            StudioCategoryItem(
                id = "appearance",
                titleRes = R.string.cat_appearance_title,
                descRes = R.string.cat_appearance_desc,
                icon = Icons.Default.Favorite,
                iconTint = Color(0xFFE0245E),
                keywords = listOf("appearance", "opacity", "blur", "gradient", "shadow", "theme", "warna", "opasitas")
            ),
            StudioCategoryItem(
                id = "layout",
                titleRes = R.string.cat_layout_title,
                descRes = R.string.cat_layout_desc,
                icon = Icons.Default.Home,
                iconTint = Color(0xFF34C759),
                keywords = listOf("layout", "cutout", "preset", "offset", "radius", "orientation", "landscape", "portrait")
            ),
            StudioCategoryItem(
                id = "fonts",
                titleRes = R.string.cat_fonts_title,
                descRes = R.string.cat_fonts_desc,
                icon = Icons.Default.Star,
                iconTint = Color(0xFFFF9500),
                keywords = listOf("font", "clock", "led", "matrix", "jam", "hour tick", "typography")
            ),
            StudioCategoryItem(
                id = "animations",
                titleRes = R.string.cat_animations_title,
                descRes = R.string.cat_animations_desc,
                icon = Icons.Default.PlayArrow,
                iconTint = Color(0xFF9C27B0),
                keywords = listOf("animation", "spring", "damping", "stiffness", "speed", "haptic", "kecepatan", "pegas")
            ),
            StudioCategoryItem(
                id = "gestures",
                titleRes = R.string.cat_gestures_title,
                descRes = R.string.cat_gestures_desc,
                icon = Icons.Default.Info,
                iconTint = Color(0xFF00BCD4),
                keywords = listOf("gesture", "swipe", "tap", "long press", "geser", "sentuh")
            ),
            StudioCategoryItem(
                id = "alerts",
                titleRes = R.string.cat_alerts_title,
                descRes = R.string.cat_alerts_desc,
                icon = Icons.Default.Notifications,
                iconTint = Color(0xFFFF5252),
                keywords = listOf("alerts", "notifications", "app", "notifikasi", "anti-spam", "sound", "suara")
            ),
            StudioCategoryItem(
                id = "idle",
                titleRes = R.string.cat_idle_title,
                descRes = R.string.cat_idle_desc,
                icon = Icons.Default.Star,
                iconTint = Color(0xFFFFC107),
                keywords = listOf("idle", "widget", "weather", "cuaca", "speed", "split pill", "calendar")
            ),
            StudioCategoryItem(
                id = "setup",
                titleRes = R.string.cat_setup_title,
                descRes = R.string.cat_setup_desc,
                icon = Icons.Default.Build,
                iconTint = Color(0xFF607D8B),
                keywords = listOf("setup", "permissions", "shizuku", "adb", "aksesibilitas", "overlay")
            )
        )
    }

    val filteredCategories = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            categories
        } else {
            val q = searchQuery.trim().lowercase()
            categories.filter { cat ->
                cat.keywords.any { it.contains(q) } ||
                        cat.id.contains(q)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.welcome_headline),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = stringResource(R.string.studio_subtitle),
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.6f)
            )
        }

        // Global Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text(
                        stringResource(R.string.search_settings_hint),
                        color = Color.White.copy(alpha = 0.4f),
                        fontSize = 14.sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = Color.White.copy(alpha = 0.5f)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear",
                            tint = Color.White.copy(alpha = 0.6f),
                            modifier = Modifier.clickable { searchQuery = "" }
                        )
                    }
                },
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF388AF6),
                    unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                    focusedContainerColor = Color(0xFF141720),
                    unfocusedContainerColor = Color(0xFF141720),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                singleLine = true
            )
        }

        // Live Preview Island
        item {
            StudioLivePreview(settings = settings)
        }

        // Action Required Banner (if permissions not granted)
        if (!hasCoreOverlayPermission) {
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF281316)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFFF3B30).copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = stringResource(R.string.action_required_title),
                            color = Color(0xFFFF453A),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = stringResource(R.string.action_required_desc),
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = onOpenAccessibility,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388AF6)),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(stringResource(R.string.action_grant_accessibility), fontSize = 12.sp)
                            }
                            Button(
                                onClick = onOpenOverlay,
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.12f)),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(stringResource(R.string.action_grant_overlay), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Filtered Category Cards
        if (filteredCategories.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(R.string.no_settings_found),
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            items(filteredCategories, key = { it.id }) { cat ->
                StudioCategoryCard(
                    title = stringResource(cat.titleRes),
                    description = stringResource(cat.descRes),
                    icon = cat.icon,
                    iconTint = cat.iconTint,
                    onClick = { onNavigateToCategory(cat.id) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}
