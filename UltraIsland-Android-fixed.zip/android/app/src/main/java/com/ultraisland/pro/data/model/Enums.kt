/*
 * UltraIsland Pro (2026)
 * Derived from SmartIsland UI by Animesh Gupta (GPLv3)
 * Licensed under the GNU General Public License v3.0
 */
package com.ultraisland.pro.data.model

enum class MergeStyle {
    MERGE,
    SEPARATE,
    WIDE,
    CENTER_HOLE;

    companion object {
        fun fromString(value: String): MergeStyle {
            return entries.find { it.name.equals(value, ignoreCase = true) } ?: MERGE
        }
    }
}

enum class AnimationSpeed(val multiplier: Float, val label: String) {
    VERY_FAST(0.6f, "Very Fast"),
    FAST(0.8f, "Fast"),
    NORMAL(1.0f, "Standard"),
    RELAXED(1.3f, "Relaxed"),
    SLOW(1.6f, "Cinematic");

    companion object {
        fun fromMultiplier(value: Float): AnimationSpeed {
            return entries.minByOrNull { kotlin.math.abs(it.multiplier - value) } ?: NORMAL
        }
    }
}

enum class HapticStrength(val level: Int, val label: String) {
    OFF(0, "Off"),
    LIGHT(1, "Light"),
    MEDIUM(2, "Medium"),
    STRONG(3, "Firm");

    companion object {
        fun fromLevel(level: Int): HapticStrength {
            return entries.find { it.level == level } ?: MEDIUM
        }
    }
}

enum class GestureSensitivity(val label: String, val thresholdDp: Float) {
    LOW("Low", 36f),
    MEDIUM("Medium", 24f),
    HIGH("High", 14f);

    companion object {
        fun fromString(value: String): GestureSensitivity {
            return entries.find { it.name.equals(value, ignoreCase = true) } ?: MEDIUM
        }
    }
}

enum class SwipeAction(val actionId: String, val label: String) {
    NONE("none", "None"),
    TOGGLE_EXPAND("toggle_expand", "Expand / Collapse"),
    DISMISS("dismiss", "Dismiss"),
    QUICK_TOOLS("quick_tools", "Quick Tools"),
    SCREENSHOT("screenshot", "Take Screenshot"),
    LOCK_SCREEN("lock_screen", "Lock Screen"),
    PREVIOUS_TRACK("prev_track", "Previous Track"),
    NEXT_TRACK("next_track", "Next Track"),
    TOGGLE_PLAY("toggle_play", "Play / Pause");

    companion object {
        fun fromId(id: String): SwipeAction {
            return entries.find { it.actionId.equals(id, ignoreCase = true) } ?: NONE
        }
    }
}

object CustomFonts {
    const val FONT_SYSTEM = "system"
    const val FONT_LED_DOT_5X7 = "led_dot_5x7"
    const val FONT_MONOSPACE = "monospace"
    const val FONT_SERIF = "serif"
    const val FONT_CUSTOM = "custom"

    fun isValidFont(font: String): Boolean {
        return font in listOf(FONT_SYSTEM, FONT_LED_DOT_5X7, FONT_MONOSPACE, FONT_SERIF, FONT_CUSTOM)
    }
}
