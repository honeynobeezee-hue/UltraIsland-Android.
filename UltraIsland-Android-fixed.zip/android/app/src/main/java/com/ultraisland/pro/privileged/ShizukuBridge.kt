package com.ultraisland.pro.privileged

import android.content.pm.PackageManager
import android.util.Log
import com.ultraisland.pro.privileged.wireless.AdbWirelessManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

class ShizukuBridge : PrivilegedBridge {

    override val backend: PrivilegedBackend = PrivilegedBackend.SHIZUKU
    override val shellUid: Int = 2000

    var onBinderDied: (() -> Unit)? = null
    var onBinderReceived: (() -> Unit)? = null

    private var binderAlive = false

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        binderAlive = true
        Log.i(TAG, "Shizuku binder received")
        onBinderReceived?.invoke()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        binderAlive = false
        Log.w(TAG, "Shizuku binder died")
        onBinderDied?.invoke()
    }

    fun registerListeners() {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to register Shizuku listeners", t)
        }
    }

    override val isAvailable: Boolean
        get() = try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }

    override val hasPermission: Boolean
        get() = try {
            if (!isAvailable) false
            else if (Shizuku.isPre_V11()) false
            else Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }

    override fun requestPermission() {
        try {
            if (isAvailable && !hasPermission) {
                Shizuku.requestPermission(101)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to request Shizuku permission", t)
        }
    }

    override suspend fun exec(command: String): Result<String> = withContext(Dispatchers.IO) {
        if (!hasPermission) {
            return@withContext Result.failure(IllegalStateException("Shizuku permission not granted"))
        }

        try {
            val result = withTimeoutOrNull(6000L) {
                val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                val output = process.inputStream.bufferedReader().use { it.readText() }
                val error = process.errorStream.bufferedReader().use { it.readText() }
                val exitCode = process.waitFor()

                if (exitCode == 0) {
                    output.trim()
                } else {
                    throw RuntimeException("Command failed ($exitCode): $error")
                }
            }

            if (result != null) {
                Result.success(result)
            } else {
                Result.failure(RuntimeException("Command execution timed out after 6000ms"))
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Error executing Shizuku command: $command", t)
            Result.failure(t)
        }
    }

    companion object {
        private const val TAG = "ShizukuBridge"
    }
}

class AdbWirelessBridge : PrivilegedBridge {
    override val backend: PrivilegedBackend = PrivilegedBackend.ADB_WIRELESS
    override val shellUid: Int = 2000
    override val isAvailable: Boolean
        get() = AdbWirelessManager.isSupported()
    override val hasPermission: Boolean
        get() = AdbWirelessManager.isConnected()

    override fun requestPermission() {
        // Triggered via pairing wizard UI
    }

    override suspend fun exec(command: String): Result<String> {
        return AdbWirelessManager.execCommand(command)
    }
}

class ManualFallbackBridge : PrivilegedBridge {
    override val backend: PrivilegedBackend = PrivilegedBackend.MANUAL
    override val shellUid: Int = -1
    override val isAvailable: Boolean = true
    override val hasPermission: Boolean = false
    override fun requestPermission() {}
    override suspend fun exec(command: String): Result<String> {
        return Result.failure(UnsupportedOperationException("Manual backend requires user action via Android Settings or PC ADB"))
    }
}

// Compatibility wrapper for previous phases
object PrivilegedManager {
    val shizuku: ShizukuBridge
        get() = PrivilegedBridgeManager.shizuku

    val manual: ManualFallbackBridge
        get() = PrivilegedBridgeManager.manual

    fun getActiveBridge(): PrivilegedBridge = PrivilegedBridgeManager.getActiveBridge()

    suspend fun exec(command: String): Result<String> = PrivilegedBridgeManager.exec(command)
}
