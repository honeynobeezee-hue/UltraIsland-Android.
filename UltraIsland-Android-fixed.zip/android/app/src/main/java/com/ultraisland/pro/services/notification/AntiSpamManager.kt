package com.ultraisland.pro.services.notification

import android.util.Log

object AntiSpamManager {
    private const val TAG = "AntiSpamManager"

    // PackageName -> List of arrival timestamps
    private val notificationTimestamps = mutableMapOf<String, MutableList<Long>>()
    // PackageName -> Cooldown expiry timestamp
    private val activeCooldowns = mutableMapOf<String, Long>()

    @Synchronized
    fun shouldBlock(
        packageName: String,
        threshold: Int = 5,
        windowSeconds: Int = 30,
        whitelist: Set<String> = emptySet()
    ): Boolean {
        if (whitelist.contains(packageName)) {
            return false
        }

        val now = System.currentTimeMillis()
        val cooldownUntil = activeCooldowns[packageName] ?: 0L
        if (now < cooldownUntil) {
            Log.d(TAG, "Notification from $packageName blocked due to active cooldown (${(cooldownUntil - now) / 1000}s remaining)")
            return true
        }

        // Clean up window
        val timestamps = notificationTimestamps.getOrPut(packageName) { mutableListOf() }
        val windowStart = now - (windowSeconds * 1000L)
        timestamps.removeAll { it < windowStart }

        timestamps.add(now)

        if (timestamps.size >= threshold) {
            val cooldownExpiry = now + (windowSeconds * 1000L)
            activeCooldowns[packageName] = cooldownExpiry
            timestamps.clear()
            Log.w(TAG, "Spam detected for $packageName (>= $threshold in ${windowSeconds}s). Cooldown activated.")
            return true
        }

        return false
    }

    @Synchronized
    fun resetCooldown(packageName: String) {
        activeCooldowns.remove(packageName)
        notificationTimestamps.remove(packageName)
    }

    @Synchronized
    fun clearAll() {
        activeCooldowns.clear()
        notificationTimestamps.clear()
    }
}
