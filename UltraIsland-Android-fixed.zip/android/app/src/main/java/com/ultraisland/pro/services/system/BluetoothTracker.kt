package com.ultraisland.pro.services.system

import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.ultraisland.pro.engine.statemachine.IslandStateMachine

data class BluetoothStatusInfo(
    val deviceName: String,
    val isConnected: Boolean,
    val isWired: Boolean = false,
    val batteryPercentage: Int? = null
)

object BluetoothTracker {
    private const val TAG = "BluetoothTracker"
    private val mainHandler = Handler(Looper.getMainLooper())

    fun onBluetoothDeviceConnected(device: BluetoothDevice?) {
        val name = try { device?.name } catch (_: SecurityException) { null } ?: "Bluetooth Audio"
        Log.i(TAG, "Bluetooth device connected: $name")

        val info = BluetoothStatusInfo(
            deviceName = name,
            isConnected = true,
            isWired = false,
            batteryPercentage = 80 // Default battery estimation if available
        )

        IslandStateMachine.postBluetooth(info, autoExpand = true)

        mainHandler.postDelayed({
            IslandStateMachine.collapse()
        }, 4000L)
    }

    fun onBluetoothDeviceDisconnected() {
        Log.i(TAG, "Bluetooth device disconnected")
        IslandStateMachine.clearBluetooth()
    }

    fun onHeadsetPlugged(state: Int) {
        val isPlugged = state == 1
        Log.i(TAG, "Headset plug state: $isPlugged")
        if (isPlugged) {
            val info = BluetoothStatusInfo(
                deviceName = "Wired Headphones",
                isConnected = true,
                isWired = true
            )
            IslandStateMachine.postBluetooth(info, autoExpand = true)
            mainHandler.postDelayed({
                IslandStateMachine.collapse()
            }, 4000L)
        } else {
            IslandStateMachine.clearBluetooth()
        }
    }
}
