package com.ultraisland.pro.services.telephony

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class ActiveCallInfo(
    val callerName: String,
    val callerNumber: String,
    val isIncoming: Boolean,
    val isOngoing: Boolean,
    val durationSeconds: Int = 0,
    val isSpeakerOn: Boolean = false,
    val isMuted: Boolean = false
)

object CallManager {
    private const val TAG = "CallManager"

    private var telephonyManager: TelephonyManager? = null
    private var telecomManager: TelecomManager? = null
    private var audioManager: AudioManager? = null

    private var callDurationJob: Job? = null
    private var currentDuration = 0
    private var currentCallInfo: ActiveCallInfo? = null

    fun init(context: Context) {
        val appCtx = context.applicationContext
        telephonyManager = appCtx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        telecomManager = appCtx.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        audioManager = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

        registerCallStateListener(appCtx)
    }

    private fun registerCallStateListener(context: Context) {
        val tm = telephonyManager ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val callback = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) {
                    handleCallState(context, state, null)
                }
            }
            try {
                tm.registerTelephonyCallback(context.mainExecutor, callback)
            } catch (e: Exception) {
                Log.w(TAG, "Cannot register TelephonyCallback: ${e.message}")
            }
        } else {
            @Suppress("DEPRECATION")
            val listener = object : PhoneStateListener() {
                @Deprecated("Deprecated in Java")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                    handleCallState(context, state, phoneNumber)
                }
            }
            try {
                @Suppress("DEPRECATION")
                tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
            } catch (e: Exception) {
                Log.w(TAG, "Cannot register PhoneStateListener: ${e.message}")
            }
        }
    }

    private fun handleCallState(context: Context, state: Int, phoneNumber: String?) {
        val number = phoneNumber ?: "Incoming Call"

        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                Log.i(TAG, "Call ringing from: $number")
                stopDurationTimer()
                currentCallInfo = ActiveCallInfo(
                    callerName = "Incoming Call",
                    callerNumber = number,
                    isIncoming = true,
                    isOngoing = false
                )
                IslandStateMachine.postCall(currentCallInfo!!, autoExpand = true)
            }

            TelephonyManager.CALL_STATE_OFFHOOK -> {
                Log.i(TAG, "Call connected / ongoing")
                startDurationTimer()
            }

            TelephonyManager.CALL_STATE_IDLE -> {
                Log.i(TAG, "Call ended / idle")
                stopDurationTimer()
                currentCallInfo = null
                IslandStateMachine.clearCall()
            }
        }
    }

    private fun startDurationTimer() {
        stopDurationTimer()
        currentDuration = 0
        callDurationJob = CoroutineScope(Dispatchers.Main).launch {
            while (isActive) {
                currentDuration++
                currentCallInfo = currentCallInfo?.copy(
                    isIncoming = false,
                    isOngoing = true,
                    durationSeconds = currentDuration,
                    isSpeakerOn = audioManager?.isSpeakerphoneOn == true,
                    isMuted = audioManager?.isMicrophoneMute == true
                ) ?: ActiveCallInfo(
                    callerName = "Call in progress",
                    callerNumber = "",
                    isIncoming = false,
                    isOngoing = true,
                    durationSeconds = currentDuration
                )

                IslandStateMachine.postCall(currentCallInfo!!, autoExpand = false)
                delay(1000L)
            }
        }
    }

    private fun stopDurationTimer() {
        callDurationJob?.cancel()
        callDurationJob = null
        currentDuration = 0
    }

    // Call Controls
    fun answerCall(context: Context): Boolean {
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED) {
            return try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    telecomManager?.acceptRingingCall()
                } else {
                    openDialerFallback(context)
                }
                true
            } catch (e: Exception) {
                Log.e(TAG, "Error answering call", e)
                openDialerFallback(context)
                false
            }
        } else {
            openDialerFallback(context)
            return false
        }
    }

    fun endCall(context: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                telecomManager?.endCall()
            } else {
                openDialerFallback(context)
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error ending call", e)
            openDialerFallback(context)
            false
        }
    }

    fun toggleSpeakerphone(): Boolean {
        val am = audioManager ?: return false
        val newState = !am.isSpeakerphoneOn
        am.isSpeakerphoneOn = newState
        currentCallInfo = currentCallInfo?.copy(isSpeakerOn = newState)
        currentCallInfo?.let { IslandStateMachine.postCall(it, autoExpand = false) }
        return newState
    }

    fun toggleMute(): Boolean {
        val am = audioManager ?: return false
        val newState = !am.isMicrophoneMute
        am.isMicrophoneMute = newState
        currentCallInfo = currentCallInfo?.copy(isMuted = newState)
        currentCallInfo?.let { IslandStateMachine.postCall(it, autoExpand = false) }
        return newState
    }

    fun openDialerFallback(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch dialer", e)
        }
    }
}
