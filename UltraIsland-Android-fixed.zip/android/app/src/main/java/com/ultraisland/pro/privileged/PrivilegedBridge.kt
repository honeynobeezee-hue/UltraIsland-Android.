package com.ultraisland.pro.privileged

import com.ultraisland.pro.privileged.wireless.AdbWirelessManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class PrivilegedBackend(val displayName: String) {
    SHIZUKU("Shizuku (Binder UID 2000)"),
    ADB_WIRELESS("ADB Wireless (Local adbd)"),
    PC_ADB("PC ADB Fallback"),
    MANUAL("Manual Fallback (Non-privileged)")
}

interface PrivilegedBridge {
    val backend: PrivilegedBackend
    val isAvailable: Boolean
    val hasPermission: Boolean
    val shellUid: Int
    fun requestPermission()
    suspend fun exec(command: String): Result<String>
}

object PrivilegedBridgeManager {
    val shizuku = ShizukuBridge()
    val adbWireless = AdbWirelessBridge()
    val manual = ManualFallbackBridge()

    private val _isShizukuDead = MutableStateFlow(false)
    val isShizukuDead: StateFlow<Boolean> = _isShizukuDead.asStateFlow()

    init {
        shizuku.onBinderDied = {
            _isShizukuDead.value = true
        }
        shizuku.onBinderReceived = {
            _isShizukuDead.value = false
        }
    }

    fun getActiveBridge(): PrivilegedBridge {
        return when {
            shizuku.isAvailable && shizuku.hasPermission -> shizuku
            AdbWirelessManager.isConnected() -> adbWireless
            shizuku.isAvailable -> shizuku
            else -> manual
        }
    }

    suspend fun exec(command: String): Result<String> {
        if (!PrivilegedCommandRegistry.isCommandAllowed(command)) {
            return Result.failure(SecurityException("Command not permitted by UltraIsland whitelist: $command"))
        }
        return getActiveBridge().exec(command)
    }
}
