package com.ultraisland.pro.ui.expanded

import android.media.MediaMetadata

/** Kunci metadata standar androidx.media (MediaConstants.METADATA_KEY_IS_EXPLICIT); nilai 1 = konten eksplisit. */
private const val KEY_IS_EXPLICIT = "android.media.IS_EXPLICIT"
private const val EXPLICIT_VALUE = 1L

fun mediaIsExplicit(metadata: MediaMetadata): Boolean =
    try {
        metadata.getLong(KEY_IS_EXPLICIT) == EXPLICIT_VALUE
    } catch (e: Exception) {
        false
    }
