package com.ultraisland.pro.model

/**
 * Animasi ambient glyph LED (matahari berputar, hujan turun, dst.).
 *
 * CATATAN: definisi aslinya tidak ada di sumber yang diunggah, jadi ini adalah versi aman yang
 * tidak menjalankan animasi ambient ([LedMotion.isRunning] selalu false). Glyph tetap tampil statis
 * dan seluruh logika kedip/transisi di LedTickSlot tetap berfungsi.
 */
enum class LedMotionKind { None }

class LedMotion(
    val kind: LedMotionKind = LedMotionKind.None,
    val stepMs: Long = 1000L,
    val isRunning: Boolean = false
) {
    companion object {
        val NONE = LedMotion()
    }
}

object LedMotionFrames {
    fun frames(icon: LedIcon, kind: LedMotionKind): List<LedGrid> = emptyList()
}

object LedMotions {
    @Suppress("UNUSED_PARAMETER")
    fun forGlyph(
        widget: IdleWidgetKind,
        look: WeatherLook?,
        isDay: Boolean,
        windKmh: Float,
        fastSpeed: Boolean,
        alarmSoon: Boolean,
        animationsOff: Boolean
    ): LedMotion = LedMotion.NONE

    fun frameAt(nowMs: Long, stepMs: Long, frameCount: Int): Int =
        if (frameCount <= 0 || stepMs <= 0L) 0 else ((nowMs / stepMs) % frameCount).toInt()
}
