package com.ultraisland.pro.engine.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.ultraisland.pro.core.datastore.IslandSettingsState
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.engine.render.IslandOverlayRoot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

object IslandOverlayManager {
    private const val TAG = "IslandOverlayManager"

    private var windowManager: WindowManager? = null
    private var composeView: ComposeView? = null
    private var isAttached = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun attach(context: Context) {
        if (isAttached) return

        try {
            windowManager = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            if (windowManager == null) return

            val layoutParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                x = 0
                y = 0
            }

            // Create fake Lifecycle & SavedState owner for Compose in WindowManager
            val lifecycleOwner = object : LifecycleOwner, SavedStateRegistryOwner {
                val registry = LifecycleRegistry(this).apply {
                    currentState = Lifecycle.State.RESUMED
                }
                val controller = SavedStateRegistryController.create(this).apply {
                    performRestore(null)
                }
                override val lifecycle: Lifecycle get() = registry
                override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
            }

            composeView = ComposeView(context).apply {
                setViewTreeLifecycleOwner(lifecycleOwner)
                setViewTreeSavedStateRegistryOwner(lifecycleOwner)
                setContent {
                    // Collect settings
                    IslandOverlayRoot(settings = IslandSettingsState())
                }
            }

            windowManager?.addView(composeView, layoutParams)
            isAttached = true
            Log.i(TAG, "TYPE_ACCESSIBILITY_OVERLAY mounted successfully")

            scope.launch {
                SettingsRepository.settingsFlow.collectLatest { settings ->
                    composeView?.setContent {
                        IslandOverlayRoot(settings = settings)
                    }
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to mount accessibility overlay", t)
            isAttached = false
        }
    }

    fun detach() {
        if (!isAttached) return
        try {
            composeView?.let { windowManager?.removeView(it) }
            composeView = null
            isAttached = false
            Log.i(TAG, "Overlay detached")
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to detach overlay", t)
        }
    }
}
