package com.ultraisland.pro.engine.cutout

import android.graphics.Rect
import android.os.Build
import android.view.DisplayCutout
import android.view.WindowInsets
import com.ultraisland.pro.core.common.Logger
import com.ultraisland.pro.core.datastore.DisplayMode
import com.ultraisland.pro.core.datastore.IslandSettings
import com.ultraisland.pro.core.datastore.MergeStyle

data class CutoutGeometry(
    val hasHardwareCutout: Boolean,
    val bounds: Rect,
    val centerX: Int,
    val topY: Int,
    val width: Int,
    val height: Int,
    val isLandscape: Boolean
)

object CutoutDetector {
    private const val TAG = "CutoutDetector"

    fun detectFromInsets(
        insets: WindowInsets?,
        screenWidthPx: Int,
        screenHeightPx: Int,
        density: Float,
        isLandscape: Boolean
    ): CutoutGeometry {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && insets != null) {
            val displayCutout: DisplayCutout? = insets.displayCutout
            if (displayCutout != null && displayCutout.boundingRects.isNotEmpty()) {
                val primaryRect = displayCutout.boundingRects.first()
                Logger.d(TAG, "Hardware cutout detected: $primaryRect, isLandscape=$isLandscape")
                return CutoutGeometry(
                    hasHardwareCutout = true,
                    bounds = primaryRect,
                    centerX = primaryRect.centerX(),
                    topY = primaryRect.top,
                    width = primaryRect.width(),
                    height = primaryRect.height(),
                    isLandscape = isLandscape
                )
            }
        }

        // Fallback default hole in top center
        val defaultWidthPx = (110 * density).toInt()
        val defaultHeightPx = (36 * density).toInt()
        val defaultTopYPx = (10 * density).toInt()
        val defaultCenterX = screenWidthPx / 2
        val defaultLeft = defaultCenterX - (defaultWidthPx / 2)
        val defaultRect = Rect(defaultLeft, defaultTopYPx, defaultLeft + defaultWidthPx, defaultTopYPx + defaultHeightPx)

        return CutoutGeometry(
            hasHardwareCutout = false,
            bounds = defaultRect,
            centerX = defaultCenterX,
            topY = defaultTopYPx,
            width = defaultWidthPx,
            height = defaultHeightPx,
            isLandscape = isLandscape
        )
    }

    /**
     * Compute effective overlay pill frame based on settings and cutout geometry
     */
    fun computePillFrame(
        cutout: CutoutGeometry,
        settings: IslandSettings,
        density: Float,
        screenWidthPx: Int
    ): Rect {
        val widthPx = (settings.cutoutWidth * density).toInt()
        val heightPx = (settings.cutoutHeight * density).toInt()
        val centreXOffsetPx = (settings.centreXOffset * density).toInt()
        val topYOffsetPx = (settings.topYOffset * density).toInt()

        val baseX = if (cutout.hasHardwareCutout && settings.displayMode == DisplayMode.CUTOUT_MERGE) {
            cutout.centerX
        } else {
            screenWidthPx / 2
        }

        val effectiveCenterX = baseX + centreXOffsetPx
        val effectiveTopY = if (cutout.hasHardwareCutout && settings.displayMode == DisplayMode.CUTOUT_MERGE) {
            when (settings.mergeStyle) {
                MergeStyle.MERGE -> cutout.topY.coerceAtLeast(0) + topYOffsetPx
                MergeStyle.SEPARATE -> cutout.topY + cutout.height + topYOffsetPx
                MergeStyle.WIDE -> topYOffsetPx
                MergeStyle.CENTER_HOLE -> cutout.topY + topYOffsetPx
            }
        } else {
            topYOffsetPx
        }

        val left = effectiveCenterX - (widthPx / 2)
        return Rect(left, effectiveTopY, left + widthPx, effectiveTopY + heightPx)
    }
}
