package com.ultraisland.pro.core.designsystem.motion

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import com.ultraisland.pro.core.datastore.AnimationStyle

object IslandSpringSpec {
    // True iOS Dynamic Island physics specs: Damping ≈ 0.72f, Stiffness ≈ 380f
    const val IOS_DAMPING_RATIO = 0.72f
    const val IOS_STIFFNESS = 380f

    // Material Expressive: slightly more damped, higher stiffness
    const val MATERIAL_DAMPING_RATIO = 0.85f
    const val MATERIAL_STIFFNESS = 500f

    // Bouncy: low damping for playful bounce
    const val BOUNCY_DAMPING_RATIO = 0.55f
    const val BOUNCY_STIFFNESS = 320f

    fun <T> getSpec(
        style: AnimationStyle,
        speedMultiplier: Float = 1.0f,
        customDamping: Float = 0.72f,
        customStiffness: Float = 380f
    ): AnimationSpec<T> {
        return when (style) {
            AnimationStyle.IOS_SPRING -> spring(
                dampingRatio = customDamping,
                stiffness = customStiffness * speedMultiplier
            )
            AnimationStyle.MATERIAL_EXPRESSIVE -> spring(
                dampingRatio = MATERIAL_DAMPING_RATIO,
                stiffness = MATERIAL_STIFFNESS * speedMultiplier
            )
            AnimationStyle.BOUNCY -> spring(
                dampingRatio = BOUNCY_DAMPING_RATIO,
                stiffness = BOUNCY_STIFFNESS * speedMultiplier
            )
            AnimationStyle.SMOOTH_LINEAR -> tween(
                durationMillis = (320 / speedMultiplier.coerceAtLeast(0.1f)).toInt(),
                easing = FastOutSlowInEasing
            )
            AnimationStyle.MINIMAL -> tween(
                durationMillis = (180 / speedMultiplier.coerceAtLeast(0.1f)).toInt(),
                easing = LinearEasing
            )
            AnimationStyle.INSTANT -> tween(durationMillis = 0)
        }
    }
}
