package com.ultraisland.pro.services.media

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import com.ultraisland.pro.services.notification.IslandNotificationListener

data class MediaTrackInfo(
    val title: String,
    val artist: String,
    val albumArt: Bitmap? = null,
    val durationMs: Long = 0L,
    val positionMs: Long = 0L,
    val isPlaying: Boolean = false,
    val accentColorHex: String = "#388AF6",
    val packageName: String = ""
)

object MediaSessionTracker {
    private const val TAG = "MediaSessionTracker"

    private var activeController: MediaController? = null
    private var lastTrackTitle: String = ""
    private val mainHandler = Handler(Looper.getMainLooper())

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            updateFromController(activeController)
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            updateFromController(activeController)
        }

        override fun onSessionDestroyed() {
            super.onSessionDestroyed()
            Log.d(TAG, "MediaSession destroyed")
            activeController = null
            IslandStateMachine.clearMedia()
        }
    }

    fun init(context: Context) {
        try {
            val sessionManager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
            val notificationListener = ComponentName(context, IslandNotificationListener::class.java)

            sessionManager?.addOnActiveSessionsChangedListener({ controllers ->
                handleSessionsChanged(context, controllers)
            }, notificationListener)

            // Initial check
            val initialSessions = sessionManager?.getActiveSessions(notificationListener)
            handleSessionsChanged(context, initialSessions)
        } catch (e: Exception) {
            Log.w(TAG, "MediaSession tracking requires NotificationListener permission: ${e.message}")
        }
    }

    private fun handleSessionsChanged(context: Context, controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) {
            activeController?.unregisterCallback(callback)
            activeController = null
            IslandStateMachine.clearMedia()
            return
        }

        val primary = controllers.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: controllers.first()

        if (activeController?.sessionToken != primary.sessionToken) {
            activeController?.unregisterCallback(callback)
            activeController = primary
            activeController?.registerCallback(callback)
        }

        updateFromController(primary)
    }

    private fun updateFromController(controller: MediaController?) {
        if (controller == null) return
        val metadata = controller.metadata
        val state = controller.playbackState

        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: "Media Playing"

        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: "Unknown Artist"

        val duration = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val position = state?.position ?: 0L
        val isPlaying = state?.state == PlaybackState.STATE_PLAYING

        val artBitmap: Bitmap? = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)

        val accentColor = extractAccentColor(artBitmap)

        val trackInfo = MediaTrackInfo(
            title = title,
            artist = artist,
            albumArt = artBitmap,
            durationMs = duration,
            positionMs = position,
            isPlaying = isPlaying,
            accentColorHex = accentColor,
            packageName = controller.packageName ?: ""
        )

        val isTrackChanged = title != lastTrackTitle && isPlaying
        lastTrackTitle = title

        mainHandler.post {
            IslandStateMachine.postMedia(trackInfo, autoExpand = isTrackChanged)
        }
    }

    private fun extractAccentColor(bitmap: Bitmap?): String {
        if (bitmap == null) return "#E0245E"
        return try {
            // Sample pixel from center for fast dynamic color
            val pixel = bitmap.getPixel(bitmap.width / 2, bitmap.height / 2)
            String.format("#%06X", 0xFFFFFF and pixel)
        } catch (_: Exception) {
            "#E0245E"
        }
    }

    // Controls
    fun play() {
        activeController?.transportControls?.play()
    }

    fun pause() {
        activeController?.transportControls?.pause()
    }

    fun togglePlayPause() {
        if (activeController?.playbackState?.state == PlaybackState.STATE_PLAYING) {
            pause()
        } else {
            play()
        }
    }

    fun skipToNext() {
        activeController?.transportControls?.skipToNext()
    }

    fun skipToPrevious() {
        activeController?.transportControls?.skipToPrevious()
    }

    fun seekTo(positionMs: Long) {
        activeController?.transportControls?.seekTo(positionMs)
    }

    fun launchPlayerApp(context: Context) {
        val pkg = activeController?.packageName ?: return
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Cannot launch player app for $pkg", e)
        }
    }
}
