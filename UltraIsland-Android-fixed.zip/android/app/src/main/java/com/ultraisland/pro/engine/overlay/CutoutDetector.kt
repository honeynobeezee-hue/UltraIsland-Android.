package com.ultraisland.pro.engine.overlay

import android.graphics.Rect
import android.os.Build
import android.view.DisplayCutout
import android.view.WindowInsets

data class CutoutInfo(
    val hasHardwareCutout: Boolean,
    val bounds: Rect,
    val centerX: Int,
    val topY: Int
)

object CutoutDetector {
    fun detect(
        insets: WindowInsets?,
        screenWidthPx: Int,
        density: Float
    ): CutoutInfo {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && insets != null) {
            val cutout: DisplayCutout? = insets.displayCutout
            if (cutout != null && cutout.boundingRects.isNotEmpty()) {
                val rect = cutout.boundingRects.first()
                return CutoutInfo(
                    hasHardwareCutout = true,
                    bounds = rect,
                    centerX = rect.centerX(),
                    topY = rect.top
                )
            }
        }

        val defaultWidth = (110 * density).toInt()
        val defaultHeight = (36 * density).toInt()
        val defaultTop = (12 * density).toInt()
        val defaultCenterX = screenWidthPx / 2
        val left = defaultCenterX - (defaultWidth / 2)

        return CutoutInfo(
            hasHardwareCutout = false,
            bounds = Rect(left, defaultTop, left + defaultWidth, defaultTop + defaultHeight),
            centerX = defaultCenterX,
            topY = defaultTop
        )
    }
}
