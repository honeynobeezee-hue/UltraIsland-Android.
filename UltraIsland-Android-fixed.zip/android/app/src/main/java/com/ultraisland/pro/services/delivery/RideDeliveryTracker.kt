package com.ultraisland.pro.services.delivery

import android.app.Notification
import android.content.Context
import android.service.notification.StatusBarNotification
import android.util.Log
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import java.util.regex.Pattern

enum class OrderType {
    RIDE,
    FOOD,
    PACKAGE,
    GROCERY
}

data class RideDeliveryInfo(
    val packageName: String,
    val appName: String,
    val title: String,
    val status: String,
    val driverOrStore: String,
    val eta: String,
    val progressPercent: Int, // 0 - 100
    val orderType: OrderType,
    val accentColorHex: String,
    val timestamp: Long = System.currentTimeMillis()
)

object RideDeliveryTracker {
    private const val TAG = "RideDeliveryTracker"

    // Supported delivery and ride apps
    val DEFAULT_PACKAGES = mapOf(
        "com.ubercab" to ("Uber" to "#000000"),
        "com.ubercab.eats" to ("Uber Eats" to "#06C167"),
        "com.grabtaxi.passenger" to ("Grab" to "#00B14F"),
        "com.gojek.app" to ("Gojek" to "#00AA13"),
        "com.application.zomato" to ("Zomato" to "#E23744"),
        "in.swiggy.android" to ("Swiggy" to "#FC8019"),
        "com.shopee.id" to ("ShopeeFood" to "#EE4D2D"),
        "com.dd.doordash" to ("DoorDash" to "#FF3008"),
        "com.deliveroo.orderapp" to ("Deliveroo" to "#00CDBC")
    )

    private var currentRide: RideDeliveryInfo? = null

    fun isRideOrDeliveryPackage(packageName: String): Boolean {
        return DEFAULT_PACKAGES.containsKey(packageName)
    }

    fun processNotification(sbn: StatusBarNotification, context: Context): Boolean {
        val pkg = sbn.packageName
        if (!isRideOrDeliveryPackage(pkg)) return false

        val notif = sbn.notification ?: return false

        // Must be an active ongoing notification or progress notification
        val isOngoing = (notif.flags and Notification.FLAG_ONGOING_EVENT) != 0 ||
                (notif.flags and Notification.FLAG_FOREGROUND_SERVICE) != 0

        val extras = notif.extras ?: return false
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim().orEmpty()

        if (title.isBlank() && text.isBlank()) return false

        val combined = "$title $text $subText".lowercase()

        // Ignore promotional marketing notifications
        if (combined.contains("diskon") ||
            combined.contains("promo") ||
            combined.contains("voucher") ||
            combined.contains("cashback") ||
            (!isOngoing && !combined.contains("arriving") && !combined.contains("menuju") && !combined.contains("otw"))
        ) {
            return false
        }

        // Determine Order Type
        val orderType = when {
            pkg.contains("eats") || pkg.contains("zomato") || pkg.contains("swiggy") || combined.contains("food") || combined.contains("makanan") || combined.contains("restoran") -> OrderType.FOOD
            combined.contains("paket") || combined.contains("package") || combined.contains("parcel") -> OrderType.PACKAGE
            else -> OrderType.RIDE
        }

        // Determine Progress (0 - 100)
        var progress = 50
        val maxProgress = extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
        val currentProgress = extras.getInt(Notification.EXTRA_PROGRESS, 0)
        if (maxProgress > 0) {
            progress = ((currentProgress.toFloat() / maxProgress) * 100).toInt().coerceIn(5, 100)
        } else {
            // Heuristic progress based on status keywords
            progress = when {
                combined.contains("finding") || combined.contains("mencari") -> 15
                combined.contains("confirmed") || combined.contains("dikonfirmasi") -> 30
                combined.contains("preparing") || combined.contains("disiapkan") -> 45
                combined.contains("on the way") || combined.contains("menuju") || combined.contains("otw") -> 70
                combined.contains("arriving") || combined.contains("hampir sampai") -> 90
                combined.contains("arrived") || combined.contains("telah sampai") || combined.contains("selesai") -> 100
                else -> 50
            }
        }

        // Extract ETA
        val eta = parseEta(title, text, subText)

        // Driver / Store
        val driverOrStore = parseDriverOrVehicle(title, text)

        val appMeta = DEFAULT_PACKAGES[pkg] ?: ("Delivery" to "#388AF6")

        val rideInfo = RideDeliveryInfo(
            packageName = pkg,
            appName = appMeta.first,
            title = if (title.isNotEmpty()) title else "${appMeta.first} Active Order",
            status = if (text.isNotEmpty()) text else "En route",
            driverOrStore = driverOrStore,
            eta = eta,
            progressPercent = progress,
            orderType = orderType,
            accentColorHex = appMeta.second,
            timestamp = System.currentTimeMillis()
        )

        currentRide = rideInfo
        IslandStateMachine.postRideDelivery(rideInfo, autoExpand = progress >= 90)
        return true
    }

    fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (isRideOrDeliveryPackage(sbn.packageName)) {
            currentRide = null
            IslandStateMachine.clearRideDelivery()
        }
    }

    fun clear() {
        currentRide = null
        IslandStateMachine.clearRideDelivery()
    }

    private fun parseEta(title: String, text: String, subText: String): String {
        val combined = "$text • $subText • $title"
        val pattern = Pattern.compile("(\\d+\\s*(?:min|mins|menit)|\\d{1,2}:\\d{2})", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(combined)
        return if (matcher.find()) {
            matcher.group(1)?.trim() ?: "4 min"
        } else {
            "5 min"
        }
    }

    private fun parseDriverOrVehicle(title: String, text: String): String {
        // Match license plate or driver name pattern if available
        val platePattern = Pattern.compile("([A-Z]{1,2}\\s*\\d{1,4}\\s*[A-Z]{1,3})")
        val matcher = platePattern.matcher("$title $text")
        return if (matcher.find()) {
            "Driver (${matcher.group(1)})"
        } else if (text.isNotEmpty()) {
            text.take(32)
        } else {
            "Courier on the way"
        }
    }
}
