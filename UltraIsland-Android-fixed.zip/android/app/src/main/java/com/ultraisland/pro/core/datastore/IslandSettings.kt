package com.ultraisland.pro.core.datastore

enum class DisplayMode {
    CUTOUT_MERGE,
    FLOATING
}

enum class MergeStyle {
    MERGE,      // Pill connects directly and encloses cutout
    SEPARATE,   // Sits just below or detached from cutout
    WIDE,       // Wide dynamic island across top
    CENTER_HOLE // Centered punch hole expansion
}

enum class AnimationStyle {
    IOS_SPRING,          // Damping 0.72f, Stiffness 380f
    MATERIAL_EXPRESSIVE, // Damping 0.85f, Stiffness 500f
    BOUNCY,              // Damping 0.55f, Stiffness 320f
    SMOOTH_LINEAR,       // Fast responsive linear curve
    MINIMAL,             // Snappy micro-transitions
    INSTANT              // Zero duration
}

enum class OverlayEngine {
    ACCESSIBILITY_OVERLAY, // Primary: TYPE_ACCESSIBILITY_OVERLAY
    SYSTEM_ALERT_WINDOW    // Fallback: TYPE_APPLICATION_OVERLAY + FGS
}

enum class ColorTheme {
    NOIR_OLED,
    DARK_GREY,
    MATERIAL_YOU_DYNAMIC,
    IOS_MINIMAL,
    NEON_CYAN
}

enum class FontOption {
    SYSTEM,
    LED_DOT_5X7,
    MONOSPACE,
    SERIF,
    CUSTOM
}

data class CustomPreset(
    val name: String,
    val cutoutWidth: Int,
    val cutoutHeight: Int,
    val centreXOffset: Int,
    val topYOffset: Int,
    val cornerRadius: Int,
    val mergeStyle: MergeStyle
)

data class IslandSettings(
    val enabled: Boolean = true,
    val overlayEngine: OverlayEngine = OverlayEngine.ACCESSIBILITY_OVERLAY,
    val displayMode: DisplayMode = DisplayMode.CUTOUT_MERGE,
    val mergeStyle: MergeStyle = MergeStyle.MERGE,
    
    // Geometry & Calibration (in dp)
    val cutoutWidth: Int = 110,
    val cutoutHeight: Int = 36,
    val centreXOffset: Int = 0,
    val topYOffset: Int = 12,
    val cornerRadius: Int = 24,
    val minClosedWidth: Int = 96,
    val marginHorizontal: Int = 16,
    val islandWidthDp: Int = 110,
    val islandHeightDp: Int = 36,
    val collapsedCutoutWidthWithContent: Int = 160,

    // Orientation Alternates
    val alternateByOrientation: Boolean = false,
    val landscapeCutoutWidth: Int = 120,
    val landscapeCutoutHeight: Int = 34,
    val landscapeTopYOffset: Int = 8,
    val activePresetName: String = "Default",
    val customPresetsJson: String = "[]",

    // Appearance & Effects
    val backgroundOpacity: Float = 0.95f,
    val backgroundBlurRadius: Int = 16,
    val cardBlurEnabled: Boolean = true,
    val albumBackdropBlur: Boolean = true,
    val colorTheme: ColorTheme = ColorTheme.NOIR_OLED,
    val gradientEnabled: Boolean = false,
    val gradientSecondColorHex: String = "#8A2BE2",
    val showGlowFlash: Boolean = true,
    val showOutlineBorder: Boolean = true,
    val ambientShadow: Boolean = true,
    val glassmorphicBlur: Boolean = false,
    val dynamicAlbumColor: Boolean = true,
    val ledColorHex: String = "#00FF66",
    val perActivityTextScale: Float = 1.0f,
    val perActivityCornerRadius: Int = 24,

    // Fonts & Clock
    val fontOption: FontOption = FontOption.SYSTEM,
    val customFontUri: String? = null,
    val mixFonts: Boolean = false,
    val showHourTick: Boolean = true,
    val clockFormatStyle: String = "HH:mm",
    val weatherUnitCelsius: Boolean = true,
    val windSpeedUnit: String = "km/h",
    val batteryStyle: String = "PERCENT_ICON",

    // Animation Physics
    val animationStyle: AnimationStyle = AnimationStyle.IOS_SPRING,
    val animationSpeedMultiplier: Float = 1.0f,
    val speedMultiplierPortrait: Float = 1.0f,
    val speedMultiplierLandscape: Float = 1.0f,
    val springDamping: Float = 0.72f,
    val springStiffness: Float = 380f,
    val hapticEnabled: Boolean = true,
    val hapticIntensity: Int = 2, // 1: Light, 2: Medium, 3: Strong

    // Behavior & Triggers
    val autoHideWhenIdle: Boolean = false,
    val hideInFullscreen: Boolean = true,
    val showOnLockscreen: Boolean = true,
    val autoExpandNewNotification: Boolean = true,
    val antiSpamCooldownSeconds: Int = 30,
    val quietHoursEnabled: Boolean = false
)
