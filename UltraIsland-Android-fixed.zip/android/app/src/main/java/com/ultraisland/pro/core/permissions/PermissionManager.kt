package com.ultraisland.pro.core.permissions

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import com.ultraisland.pro.privileged.ShizukuBridge
import com.ultraisland.pro.services.accessibility.IslandAccessibilityService
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

data class PermissionsState(
    val isAccessibilityGranted: Boolean = false,
    val isOverlayGranted: Boolean = false,
    val isShizukuGranted: Boolean = false,
    val isBatteryOptimizationIgnored: Boolean = false,
    val isNotificationListenerGranted: Boolean = false
) {
    val hasCoreOverlayPermission: Boolean
        get() = isAccessibilityGranted || isOverlayGranted
}

@Singleton
class PermissionManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val shizukuBridge: ShizukuBridge
) {
    private val _state = MutableStateFlow(PermissionsState())
    val state: StateFlow<PermissionsState> = _state.asStateFlow()

    fun refresh() {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
        val enabledServices = am?.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK) ?: emptyList()
        val accessibilityGranted = enabledServices.any { 
            it.resolveInfo.serviceInfo.packageName == context.packageName &&
            it.resolveInfo.serviceInfo.name == IslandAccessibilityService::class.java.name
        }

        val overlayGranted = Settings.canDrawOverlays(context)

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val batteryIgnored = powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: false

        val notificationListenerGranted = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        )?.contains(context.packageName) ?: false

        val shizukuGranted = shizukuBridge.isPermissionGranted()

        _state.value = PermissionsState(
            isAccessibilityGranted = accessibilityGranted,
            isOverlayGranted = overlayGranted,
            isShizukuGranted = shizukuGranted,
            isBatteryOptimizationIgnored = batteryIgnored,
            isNotificationListenerGranted = notificationListenerGranted
        )
    }

    fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    companion object {
        const val ADB_GRANT_ACCESSIBILITY = "adb shell settings put secure enabled_accessibility_services com.ultraisland.pro/com.ultraisland.pro.services.accessibility.IslandAccessibilityService && adb shell settings put secure accessibility_enabled 1"
        const val ADB_GRANT_OVERLAY = "adb shell appops set com.ultraisland.pro SYSTEM_ALERT_WINDOW allow"
        const val ADB_GRANT_BATTERY = "adb shell dumpsys deviceidle whitelist +com.ultraisland.pro"
    }
}
