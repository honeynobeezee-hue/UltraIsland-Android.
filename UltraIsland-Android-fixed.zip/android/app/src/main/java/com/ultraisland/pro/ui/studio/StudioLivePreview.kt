package com.ultraisland.pro.ui.studio

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.R
import com.ultraisland.pro.core.datastore.ColorTheme
import com.ultraisland.pro.core.datastore.FontOption
import com.ultraisland.pro.core.datastore.IslandSettingsState
import com.ultraisland.pro.core.designsystem.motion.IslandSpringSpec
import com.ultraisland.pro.core.designsystem.shape.SquircleShape

enum class PreviewStageState {
    IDLE,
    COMPACT_MEDIA,
    EXPANDED_CALL
}

@Composable
fun StudioLivePreview(
    settings: IslandSettingsState,
    modifier: Modifier = Modifier
) {
    var previewState by remember { mutableStateOf(PreviewStageState.IDLE) }

    val springSpec = IslandSpringSpec.getSpec<androidx.compose.ui.unit.Dp>(
        style = settings.animationStyle,
        speedMultiplier = settings.speedMultiplierPortrait,
        customDamping = settings.springDamping,
        customStiffness = settings.springStiffness
    )

    // Dynamic width & height matching state
    val targetWidth = when (previewState) {
        PreviewStageState.IDLE -> settings.widthDp.dp
        PreviewStageState.COMPACT_MEDIA -> (settings.widthDp + 100).coerceAtLeast(180).dp
        PreviewStageState.EXPANDED_CALL -> 320.dp
    }

    val targetHeight = when (previewState) {
        PreviewStageState.IDLE -> settings.heightDp.dp
        PreviewStageState.COMPACT_MEDIA -> (settings.heightDp + 4).dp
        PreviewStageState.EXPANDED_CALL -> 130.dp
    }

    val animatedWidth by animateDpAsState(targetValue = targetWidth, animationSpec = springSpec, label = "prevWidth")
    val animatedHeight by animateDpAsState(targetValue = targetHeight, animationSpec = springSpec, label = "prevHeight")
    val animatedCornerRadius by animateDpAsState(
        targetValue = if (previewState == PreviewStageState.EXPANDED_CALL) 32.dp else settings.cornerRadius.dp,
        animationSpec = springSpec,
        label = "prevCorner"
    )

    val shape = SquircleShape(cornerRadiusDp = animatedCornerRadius)

    // Color theme resolution
    val baseIslandColor = when (settings.colorTheme) {
        ColorTheme.NOIR_OLED -> Color.Black
        ColorTheme.DARK_GREY -> Color(0xFF1E2128)
        ColorTheme.MATERIAL_YOU_DYNAMIC -> Color(0xFF182436)
        ColorTheme.IOS_MINIMAL -> Color(0xFF121214)
        ColorTheme.NEON_CYAN -> Color(0xFF06141D)
    }

    val islandBrush = if (settings.gradientEnabled) {
        val secondColor = try {
            Color(android.graphics.Color.parseColor(settings.gradientSecondColorHex))
        } catch (_: Exception) {
            Color(0xFF8A2BE2)
        }
        Brush.verticalGradient(
            listOf(baseIslandColor.copy(alpha = settings.backgroundOpacity), secondColor.copy(alpha = settings.backgroundOpacity))
        )
    } else {
        Brush.verticalGradient(
            listOf(baseIslandColor.copy(alpha = settings.backgroundOpacity), baseIslandColor.copy(alpha = settings.backgroundOpacity))
        )
    }

    val ledColor = try {
        Color(android.graphics.Color.parseColor(settings.ledColorHex))
    } catch (_: Exception) {
        Color(0xFF00FF66)
    }

    val activeFontFamily = when (settings.fontOption) {
        FontOption.SYSTEM -> FontFamily.Default
        FontOption.LED_DOT_5X7 -> FontFamily.Monospace
        FontOption.MONOSPACE -> FontFamily.Monospace
        FontOption.SERIF -> FontFamily.Serif
        FontOption.CUSTOM -> FontFamily.SansSerif
    }

    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 18.dp, horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.live_preview_tag),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    color = Color(0xFF388AF6)
                )

                Text(
                    text = when (previewState) {
                        PreviewStageState.IDLE -> "State: Idle"
                        PreviewStageState.COMPACT_MEDIA -> "State: Compact Media"
                        PreviewStageState.EXPANDED_CALL -> "State: Expanded Card"
                    },
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.6f),
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Simulated Status Bar Phone Display Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF07080A))
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.TopCenter
            ) {
                // Top status bar simulation icons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (settings.clockFormatStyle == "hh:mm a") "09:41 AM" else "09:41",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = activeFontFamily
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("5G", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (settings.batteryStyle == "PERCENT_ICON") "98%" else "■■■",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 10.sp
                        )
                    }
                }

                // Interactive Dynamic Island
                Box(
                    modifier = Modifier
                        .padding(top = (settings.offsetY + 4).dp)
                        .width(animatedWidth)
                        .height(animatedHeight)
                        .then(
                            if (settings.ambientDropShadow) {
                                Modifier.shadow(
                                    elevation = 12.dp,
                                    shape = shape,
                                    ambientColor = Color.Black.copy(alpha = 0.7f),
                                    spotColor = Color.Black.copy(alpha = 0.95f)
                                )
                            } else Modifier
                        )
                        .clip(shape)
                        .background(brush = islandBrush)
                        .then(
                            if (settings.showOutlineBorder) {
                                Modifier.border(
                                    width = 0.8.dp,
                                    brush = Brush.verticalGradient(
                                        listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.06f))
                                    ),
                                    shape = shape
                                )
                            } else Modifier
                        )
                        .clickable {
                            previewState = when (previewState) {
                                PreviewStageState.IDLE -> PreviewStageState.COMPACT_MEDIA
                                PreviewStageState.COMPACT_MEDIA -> PreviewStageState.EXPANDED_CALL
                                PreviewStageState.EXPANDED_CALL -> PreviewStageState.IDLE
                            }
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    when (previewState) {
                        PreviewStageState.IDLE -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // Camera cutout hole emulation
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF0F0F12))
                                )
                                // Status LED
                                if (settings.showGlowFlash) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(ledColor)
                                    )
                                }
                            }
                        }
                        PreviewStageState.COMPACT_MEDIA -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // Mini album art
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFE0245E))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Midnight Reverie",
                                    color = Color.White,
                                    fontSize = (12 * settings.perActivityTextScale).sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = activeFontFamily,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                // Sound wave
                                Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.width(2.dp).height(10.dp).clip(CircleShape).background(Color(0xFFE0245E)))
                                    Box(Modifier.width(2.dp).height(6.dp).clip(CircleShape).background(Color(0xFFE0245E)))
                                    Box(Modifier.width(2.dp).height(12.dp).clip(CircleShape).background(Color(0xFFE0245E)))
                                }
                            }
                        }
                        PreviewStageState.EXPANDED_CALL -> {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(4.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF34C759)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("JD", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                "Jane Doe",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = (14 * settings.perActivityTextScale).sp,
                                                fontFamily = activeFontFamily
                                            )
                                            Text(
                                                "Active Call • 01:24",
                                                color = Color(0xFF34C759),
                                                fontSize = (11 * settings.perActivityTextScale).sp,
                                                fontFamily = activeFontFamily
                                            )
                                        }
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFFF3B30)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("✕", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = stringResource(R.string.live_preview_hint),
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.5f)
            )
        }
    }
}
