package com.ultraisland.pro.services.timer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class TimerActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        when (intent?.action) {
            "com.ultraisland.pro.ACTION_TIMER_PAUSE",
            "com.ultraisland.pro.ACTION_TIMER_RESUME" -> {
                TimerManager.togglePauseResume()
            }
            "com.ultraisland.pro.ACTION_TIMER_RESET" -> {
                TimerManager.reset()
            }
        }
    }
}
