package com.ultraisland.pro.core.common

sealed interface IslandResult<out T> {
    data class Success<out T>(val data: T) : IslandResult<T>
    data class Error(val exception: Throwable, val message: String = exception.localizedMessage ?: "Unknown error") : IslandResult<Nothing>
    data object Loading : IslandResult<Nothing>
}
