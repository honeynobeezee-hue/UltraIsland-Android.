package com.ultraisland.pro.di

import android.content.Context
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.data.INotificationHistoryRepository
import com.ultraisland.pro.data.INotificationRepository
import com.ultraisland.pro.data.NotificationHistoryRepository
import com.ultraisland.pro.data.UltraIslandNotificationRepository
import com.ultraisland.pro.data.UltraIslandSettingsProvider
import com.ultraisland.pro.data.UltraIslandSettingsRepository
import com.ultraisland.pro.engine.overlay.IslandOverlayManager
import com.ultraisland.pro.privileged.PrivilegedBridgeManager
import com.ultraisland.pro.privileged.ShizukuBridge
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt tidak bisa meng-inject Kotlin `object`, sedangkan kode yang ada meng-inject beberapa di antaranya.
 * Module ini hanya mengekspos instance singleton yang sudah ada, tanpa mengubah perilakunya.
 */
@Module
@InstallIn(SingletonComponent::class)
object HiltAppModule {
    @Provides fun provideSettingsRepository(): SettingsRepository = SettingsRepository
    @Provides fun provideIslandOverlayManager(): IslandOverlayManager = IslandOverlayManager
    @Provides fun provideShizukuBridge(): ShizukuBridge = PrivilegedBridgeManager.shizuku

    /** Instance yang sama dengan yang dipakai Application/MainActivity (satu DataStore). */
    @Provides @Singleton
    fun provideUltraSettings(@ApplicationContext context: Context): UltraIslandSettingsRepository {
        UltraIslandSettingsProvider.init(context)
        return UltraIslandSettingsProvider.repository
    }

    @Provides @Singleton
    fun provideNotificationRepository(): INotificationRepository = UltraIslandNotificationRepository()

    @Provides @Singleton
    fun provideNotificationHistoryRepository(impl: NotificationHistoryRepository): INotificationHistoryRepository = impl
}
