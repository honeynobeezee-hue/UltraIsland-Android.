package com.ultraisland.pro.services.weather

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

data class WeatherData(
    val temperatureCelsius: Int = 28,
    val apparentTempCelsius: Int = 30,
    val conditionText: String = "Partly Cloudy",
    val weatherCode: Int = 2,
    val iconType: String = "cloud-sun",
    val humidityPercent: Int = 68,
    val windSpeedKmh: Float = 14.2f,
    val aqi: Int = 42,
    val locationName: String = "Local Weather",
    val lastUpdatedMillis: Long = System.currentTimeMillis()
)

object WeatherManager {
    private const val TAG = "WeatherManager"
    private const val CACHE_PREFS = "ultra_island_weather_cache"
    private val CACHE_EXPIRY_MS = TimeUnit.MINUTES.toMillis(30)

    private val _weatherState = MutableStateFlow(WeatherData())
    val weatherState: StateFlow<WeatherData> = _weatherState.asStateFlow()

    private var cachedData: WeatherData? = null

    fun init(context: Context) {
        loadFromCache(context)
    }

    /**
     * Fetches current weather from Open-Meteo REST API (free, no API key required).
     * Gracefully falls back to cache or safe defaults on network failure.
     */
    suspend fun refreshWeather(
        context: Context,
        lat: Double = -6.2088,
        lon: Double = 106.8456,
        forceRefresh: Boolean = false
    ): WeatherData = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val current = cachedData
        if (!forceRefresh && current != null && (now - current.lastUpdatedMillis < CACHE_EXPIRY_MS)) {
            return@withContext current
        }

        try {
            val urlString = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m"
            val url = URL(urlString)
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "UltraIslandPro/1.0")
            }

            if (connection.responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val response = reader.readText()
                reader.close()

                val json = JSONObject(response)
                val currentObj = json.getJSONObject("current")

                val temp = currentObj.getDouble("temperature_2m").toInt()
                val apparentTemp = currentObj.getDouble("apparent_temperature").toInt()
                val code = currentObj.getInt("weather_code")
                val humidity = currentObj.getInt("relative_humidity_2m")
                val wind = currentObj.getDouble("wind_speed_10m").toFloat()

                val conditionMeta = interpretWeatherCode(code)
                val aqiEstimate = calculateAqiEstimate(humidity, wind)

                val fresh = WeatherData(
                    temperatureCelsius = temp,
                    apparentTempCelsius = apparentTemp,
                    conditionText = conditionMeta.first,
                    weatherCode = code,
                    iconType = conditionMeta.second,
                    humidityPercent = humidity,
                    windSpeedKmh = wind,
                    aqi = aqiEstimate,
                    locationName = "Local",
                    lastUpdatedMillis = now
                )

                cachedData = fresh
                _weatherState.value = fresh
                saveToCache(context, fresh)
                return@withContext fresh
            } else {
                Log.w(TAG, "Open-Meteo returned status ${connection.responseCode}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to fetch weather from Open-Meteo, using offline fallback: ${e.message}")
        }

        // Offline / Graceful Degradation: return cached or default
        val fallback = cachedData ?: WeatherData()
        _weatherState.value = fallback
        return@withContext fallback
    }

    private fun interpretWeatherCode(code: Int): Pair<String, String> {
        return when (code) {
            0 -> "Clear Sky" to "sun"
            1 -> "Mainly Clear" to "sun"
            2 -> "Partly Cloudy" to "cloud-sun"
            3 -> "Overcast" to "cloud"
            45, 48 -> "Foggy" to "fog"
            51, 53, 55 -> "Drizzle" to "rain"
            61, 63, 65 -> "Rain" to "rain"
            71, 73, 75 -> "Snow" to "snow"
            80, 81, 82 -> "Rain Showers" to "rain"
            95, 96, 99 -> "Thunderstorm" to "thunder"
            else -> "Fair" to "cloud-sun"
        }
    }

    private fun calculateAqiEstimate(humidity: Int, windSpeed: Float): Int {
        // High wind clears particles; high humidity can trap particulate matter
        var est = 35 + (humidity / 5) - (windSpeed.toInt() * 2)
        return est.coerceIn(15, 120)
    }

    private fun saveToCache(context: Context, data: WeatherData) {
        try {
            val sp = context.getSharedPreferences(CACHE_PREFS, Context.MODE_PRIVATE)
            sp.edit()
                .putInt("temp", data.temperatureCelsius)
                .putInt("apparent", data.apparentTempCelsius)
                .putString("condition", data.conditionText)
                .putInt("code", data.weatherCode)
                .putString("icon", data.iconType)
                .putInt("humidity", data.humidityPercent)
                .putFloat("wind", data.windSpeedKmh)
                .putInt("aqi", data.aqi)
                .putLong("updated", data.lastUpdatedMillis)
                .apply()
        } catch (_: Exception) {}
    }

    private fun loadFromCache(context: Context) {
        try {
            val sp = context.getSharedPreferences(CACHE_PREFS, Context.MODE_PRIVATE)
            if (sp.contains("temp")) {
                val cached = WeatherData(
                    temperatureCelsius = sp.getInt("temp", 28),
                    apparentTempCelsius = sp.getInt("apparent", 30),
                    conditionText = sp.getString("condition", "Partly Cloudy") ?: "Partly Cloudy",
                    weatherCode = sp.getInt("code", 2),
                    iconType = sp.getString("icon", "cloud-sun") ?: "cloud-sun",
                    humidityPercent = sp.getInt("humidity", 68),
                    windSpeedKmh = sp.getFloat("wind", 14.2f),
                    aqi = sp.getInt("aqi", 42),
                    locationName = "Local",
                    lastUpdatedMillis = sp.getLong("updated", System.currentTimeMillis())
                )
                cachedData = cached
                _weatherState.value = cached
            }
        } catch (_: Exception) {}
    }
}
