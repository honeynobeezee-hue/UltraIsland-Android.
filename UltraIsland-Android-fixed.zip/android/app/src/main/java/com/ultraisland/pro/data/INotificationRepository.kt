/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.ultraisland.pro.data

import com.ultraisland.pro.model.IslandNotification
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

interface INotificationRepository {
    val notifications: StateFlow<List<IslandNotification>>
    val autoExpandEvent: SharedFlow<String>
    val resetTimerEvent: SharedFlow<Unit>
    val commands: SharedFlow<UltraIslandCommand>

    fun postNotification(notification: IslandNotification, autoExpand: Boolean = false)

    /**
     * Changes one stored card in place (never adds one, never auto-expands). Used for live fields that change faster
     * than the app re-posts its notification, such as the track shown by a media card.
     */
    fun updateNotification(key: String, transform: (IslandNotification) -> IslandNotification) {}
    fun removeNotification(key: String)
    fun removeNotificationsForPackage(packageName: String)
    fun removeAllNotifications()
    fun resetTimer()
    fun sendCommand(command: UltraIslandCommand)
}
