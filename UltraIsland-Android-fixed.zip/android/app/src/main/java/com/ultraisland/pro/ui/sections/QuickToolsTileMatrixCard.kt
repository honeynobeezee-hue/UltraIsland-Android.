/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.ultraisland.pro.ui.sections

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.DoNotDisturb
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.ScreenRecord
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.ui.components.CollapsibleCard
import com.ultraisland.pro.ui.glass.Switch

private val ProBlue = Color(0xFF388AF6)
private val ProGreen = Color(0xFF10B981)
private val ProAmber = Color(0xFFF59E0B)
private val ProRose = Color(0xFFF43F5E)
private val ProPurple = Color(0xFF8B5CF6)
private val ProCyan = Color(0xFF06B6D4)
private val ProTeal = Color(0xFF14B8A6)
private val ProOrange = Color(0xFFF97316)
private val ProSurface = Color(0xFF141720)
private val ProCodeBg = Color(0xFF0D0F14)

private val ACCENT_PALETTE = listOf(
    ProBlue,
    ProGreen,
    ProAmber,
    ProRose,
    ProPurple,
    ProCyan,
    ProTeal,
    ProOrange
)

enum class TileAction(
    val title: String,
    val icon: ImageVector,
    val description: String
) {
    FLASHLIGHT("Flashlight", Icons.Rounded.FlashlightOn, "Toggles device camera LED torch"),
    SCREEN_RECORD("Screen Record", Icons.Rounded.ScreenRecord, "Trigger native screen capture"),
    HOTSPOT("Hotspot", Icons.Rounded.WifiTethering, "Toggle Wi-Fi portable tethering"),
    DO_NOT_DISTURB("Do Not Disturb", Icons.Rounded.DoNotDisturb, "Silence alerts & priority calls"),
    ISLAND_EXPAND("Expand Island", Icons.Rounded.Widgets, "Force open the dynamic cutout pill"),
    VOLUME_DIALOG("Volume Panel", Icons.Rounded.VolumeUp, "Display system audio stream sliders"),
    CALCULATOR("Calculator", Icons.Rounded.Calculate, "Launch quick overlay calculator"),
    TIMER("Quick Timer", Icons.Rounded.Timer, "Start 5-min countdown on Island"),
    ISLAND_LOCK("Lock Island", Icons.Rounded.Lock, "Lock island from collapsing automatically"),
    MUTE_NOTIFICATIONS("Mute Alerts", Icons.Rounded.NotificationsOff, "Mute Island vibration & sounds")
}

data class QuickSettingsTileSlot(
    val slotNumber: Int,
    var isEnabled: Boolean,
    var label: String,
    var action: TileAction,
    var accentColor: Color
)

/**
 * Quick Tools Tile Matrix Card.
 * Allows deep customization of 10 Quick Settings tile slots that link directly to Island
 * and system utility actions.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuickToolsTileMatrixCard(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // 10 configurable slots
    val tileSlots = remember {
        mutableStateListOf(
            QuickSettingsTileSlot(1, true, "Flashlight", TileAction.FLASHLIGHT, ProBlue),
            QuickSettingsTileSlot(2, true, "Expand", TileAction.ISLAND_EXPAND, ProGreen),
            QuickSettingsTileSlot(3, true, "Volume", TileAction.VOLUME_DIALOG, ProPurple),
            QuickSettingsTileSlot(4, true, "Timer", TileAction.TIMER, ProAmber),
            QuickSettingsTileSlot(5, true, "Record", TileAction.SCREEN_RECORD, ProRose),
            QuickSettingsTileSlot(6, true, "DND", TileAction.DO_NOT_DISTURB, ProCyan),
            QuickSettingsTileSlot(7, false, "Hotspot", TileAction.HOTSPOT, ProOrange),
            QuickSettingsTileSlot(8, false, "Calc", TileAction.CALCULATOR, ProTeal),
            QuickSettingsTileSlot(9, false, "Lock", TileAction.ISLAND_LOCK, ProBlue),
            QuickSettingsTileSlot(10, false, "Mute", TileAction.MUTE_NOTIFICATIONS, ProRose)
        )
    }

    var editingSlot by remember { mutableStateOf<QuickSettingsTileSlot?>(null) }

    fun applyPreset(presetName: String) {
        when (presetName) {
            "Essentials" -> {
                tileSlots[0] = tileSlots[0].copy(isEnabled = true, label = "Torch", action = TileAction.FLASHLIGHT, accentColor = ProBlue)
                tileSlots[1] = tileSlots[1].copy(isEnabled = true, label = "Expand", action = TileAction.ISLAND_EXPAND, accentColor = ProGreen)
                tileSlots[2] = tileSlots[2].copy(isEnabled = true, label = "Volume", action = TileAction.VOLUME_DIALOG, accentColor = ProPurple)
                tileSlots[3] = tileSlots[3].copy(isEnabled = true, label = "DND", action = TileAction.DO_NOT_DISTURB, accentColor = ProCyan)
            }
            "Media & Tools" -> {
                tileSlots[0] = tileSlots[0].copy(isEnabled = true, label = "Volume", action = TileAction.VOLUME_DIALOG, accentColor = ProPurple)
                tileSlots[1] = tileSlots[1].copy(isEnabled = true, label = "Record", action = TileAction.SCREEN_RECORD, accentColor = ProRose)
                tileSlots[2] = tileSlots[2].copy(isEnabled = true, label = "Timer", action = TileAction.TIMER, accentColor = ProAmber)
                tileSlots[3] = tileSlots[3].copy(isEnabled = true, label = "Mute", action = TileAction.MUTE_NOTIFICATIONS, accentColor = ProOrange)
            }
            "All Active" -> {
                tileSlots.indices.forEach { i ->
                    tileSlots[i] = tileSlots[i].copy(isEnabled = true)
                }
            }
        }
        Toast.makeText(context, "Applied preset: $presetName", Toast.LENGTH_SHORT).show()
    }

    val activeCount = tileSlots.count { it.isEnabled }

    CollapsibleCard(
        title = "Quick Settings Tile Matrix (10 Slots)",
        stateKey = "card_quick_tools_tile_matrix",
        summary = "$activeCount of 10 Quick Settings tiles active",
        icon = Icons.Rounded.Dashboard,
        initiallyExpanded = true,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header explanation
            Text(
                text = "Map up to 10 Quick Settings tiles directly to Island utilities, toggles, and shortcut actions. Tap any tile slot to edit its action, label, or color.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Preset Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Presets:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
                listOf("Essentials", "Media & Tools", "All Active").forEach { preset ->
                    FilterChip(
                        selected = false,
                        onClick = { applyPreset(preset) },
                        label = { Text(preset, fontSize = 11.sp) }
                    )
                }
            }

            // Tile Matrix Grid (2 columns x 5 rows)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (row in 0 until 5) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val slot1 = tileSlots[row * 2]
                        val slot2 = tileSlots[row * 2 + 1]

                        TileMatrixSlotItem(
                            slot = slot1,
                            modifier = Modifier.weight(1f),
                            onClick = { editingSlot = slot1 },
                            onToggle = { isChecked ->
                                val index = tileSlots.indexOfFirst { it.slotNumber == slot1.slotNumber }
                                if (index != -1) {
                                    tileSlots[index] = slot1.copy(isEnabled = isChecked)
                                }
                            }
                        )

                        TileMatrixSlotItem(
                            slot = slot2,
                            modifier = Modifier.weight(1f),
                            onClick = { editingSlot = slot2 },
                            onToggle = { isChecked ->
                                val index = tileSlots.indexOfFirst { it.slotNumber == slot2.slotNumber }
                                if (index != -1) {
                                    tileSlots[index] = slot2.copy(isEnabled = isChecked)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Slot Editing Modal
    editingSlot?.let { slot ->
        var tempLabel by remember(slot) { mutableStateOf(slot.label) }
        var tempAction by remember(slot) { mutableStateOf(slot.action) }
        var tempColor by remember(slot) { mutableStateOf(slot.accentColor) }

        AlertDialog(
            onDismissRequest = { editingSlot = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(tempColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${slot.slotNumber}",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Edit Tile Slot #${slot.slotNumber}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Label field
                    OutlinedTextField(
                        value = tempLabel,
                        onValueChange = { tempLabel = it.take(12) },
                        label = { Text("Tile Label (Max 12 chars)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = tempColor)
                    )

                    // Accent Color Row
                    Text(
                        text = "Accent Color",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ACCENT_PALETTE.forEach { color ->
                            val isSelected = tempColor == color
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .clickable { tempColor = color }
                                    .border(
                                        2.dp,
                                        if (isSelected) Color.White else Color.Transparent,
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Action Selection
                    Text(
                        text = "Assigned Island Action",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TileAction.values().forEach { action ->
                            val isSelected = tempAction == action
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    tempAction = action
                                    if (tempLabel == slot.action.title) {
                                        tempLabel = action.title
                                    }
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = action.icon,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                },
                                label = { Text(action.title, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = tempColor.copy(alpha = 0.2f),
                                    selectedLabelColor = tempColor
                                )
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val index = tileSlots.indexOfFirst { it.slotNumber == slot.slotNumber }
                        if (index != -1) {
                            tileSlots[index] = slot.copy(
                                label = tempLabel.ifBlank { tempAction.title },
                                action = tempAction,
                                accentColor = tempColor
                            )
                        }
                        editingSlot = null
                        Toast.makeText(context, "Tile #${slot.slotNumber} updated!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = tempColor)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingSlot = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun TileMatrixSlotItem(
    slot: QuickSettingsTileSlot,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onToggle: (Boolean) -> Unit
) {
    val activeColor by animateColorAsState(
        targetValue = if (slot.isEnabled) slot.accentColor else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
        label = "tile_active_color"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(ProSurface)
            .border(
                1.dp,
                if (slot.isEnabled) slot.accentColor.copy(alpha = 0.35f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(activeColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = slot.action.icon,
                contentDescription = null,
                tint = activeColor,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "#${slot.slotNumber}",
                    style = MaterialTheme.typography.labelSmall,
                    color = activeColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
                Text(
                    text = slot.label,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = slot.action.title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Switch(
            checked = slot.isEnabled,
            onCheckedChange = onToggle
        )
    }
}
