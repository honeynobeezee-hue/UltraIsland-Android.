package com.ultraisland.pro.tools.tiles

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import com.ultraisland.pro.privileged.PrivilegedBridgeManager
import com.ultraisland.pro.privileged.PrivilegedCommandRegistry
import com.ultraisland.pro.privileged.SystemSettingsRestorer
import com.ultraisland.pro.services.accessibility.IslandAccessibilityService
import com.ultraisland.pro.tools.KeepScreenOnService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@RequiresApi(Build.VERSION_CODES.N)
class ToggleIslandTileService : TileService() {
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onStartListening() {
        super.onStartListening()
        scope.launch {
            val enabled = SettingsRepository.settingsFlow.first().enabled
            qsTile?.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            qsTile?.label = "UltraIsland"
            qsTile?.updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        scope.launch {
            val current = SettingsRepository.settingsFlow.first().enabled
            val newState = !current
            SettingsRepository.updateSettings { it.copy(enabled = newState) }
            qsTile?.state = if (newState) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            qsTile?.updateTile()

            if (!newState) {
                // Auto restore system settings if island disabled
                SystemSettingsRestorer.restoreAll(applicationContext, PrivilegedBridgeManager.getActiveBridge())
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.N)
class ScreenshotTileService : TileService() {
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.state = Tile.STATE_INACTIVE
        qsTile?.label = "Screenshot"
        qsTile?.updateTile()
    }

    override fun onClick() {
        super.onClick()
        scope.launch {
            // Flash QS tile
            qsTile?.state = Tile.STATE_ACTIVE
            qsTile?.updateTile()

            val accSuccess = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                IslandAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) ?: false
            } else false

            if (!accSuccess) {
                PrivilegedBridgeManager.exec(PrivilegedCommandRegistry.CMD_SCREENSHOT)
            }

            kotlinx.coroutines.delay(600)
            qsTile?.state = Tile.STATE_INACTIVE
            qsTile?.updateTile()
        }
    }
}

@RequiresApi(Build.VERSION_CODES.N)
class KeepScreenOnTileService : TileService() {
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onStartListening() {
        super.onStartListening()
        val running = KeepScreenOnService.isRunning.value
        qsTile?.state = if (running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        qsTile?.label = if (running) "Awake (On)" else "Keep Awake"
        qsTile?.updateTile()
    }

    override fun onClick() {
        super.onClick()
        KeepScreenOnService.toggle(applicationContext)
        val running = KeepScreenOnService.isRunning.value
        qsTile?.state = if (running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        qsTile?.label = if (running) "Awake (On)" else "Keep Awake"
        qsTile?.updateTile()
    }
}

@RequiresApi(Build.VERSION_CODES.N)
class VolumeModeTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        updateTileState()
    }

    override fun onClick() {
        super.onClick()
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when (audioManager.ringerMode) {
            AudioManager.RINGER_MODE_NORMAL -> audioManager.ringerMode = AudioManager.RINGER_MODE_VIBRATE
            AudioManager.RINGER_MODE_VIBRATE -> audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT
            else -> audioManager.ringerMode = AudioManager.RINGER_MODE_NORMAL
        }
        updateTileState()
    }

    private fun updateTileState() {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when (audioManager.ringerMode) {
            AudioManager.RINGER_MODE_NORMAL -> {
                qsTile?.state = Tile.STATE_ACTIVE
                qsTile?.label = "Sound: Ring"
            }
            AudioManager.RINGER_MODE_VIBRATE -> {
                qsTile?.state = Tile.STATE_ACTIVE
                qsTile?.label = "Sound: Vibrate"
            }
            else -> {
                qsTile?.state = Tile.STATE_INACTIVE
                qsTile?.label = "Sound: Mute"
            }
        }
        qsTile?.updateTile()
    }
}

@RequiresApi(Build.VERSION_CODES.N)
class BatteryOptimizationTileService : TileService() {
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.state = Tile.STATE_INACTIVE
        qsTile?.label = "Charge Protect"
        qsTile?.updateTile()
    }

    override fun onClick() {
        super.onClick()
        scope.launch {
            val bridge = PrivilegedBridgeManager.getActiveBridge()
            // Toggle power stay on or charge limiter
            SystemSettingsRestorer.recordAndSet(applicationContext, bridge, "GLOBAL", "stay_on_while_plugged_in", "0")
            qsTile?.state = Tile.STATE_ACTIVE
            qsTile?.updateTile()
            kotlinx.coroutines.delay(1000)
            qsTile?.state = Tile.STATE_INACTIVE
            qsTile?.updateTile()
        }
    }
}

@RequiresApi(Build.VERSION_CODES.N)
class PrivateDnsTileService : TileService() {
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onStartListening() {
        super.onStartListening()
        val mode = Settings.Global.getString(contentResolver, "private_dns_mode") ?: "off"
        qsTile?.state = if (mode != "off") Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        qsTile?.label = "DNS: ${mode.replaceFirstChar { it.uppercase() }}"
        qsTile?.updateTile()
    }

    override fun onClick() {
        super.onClick()
        scope.launch {
            val currentMode = Settings.Global.getString(contentResolver, "private_dns_mode") ?: "off"
            val nextMode = when (currentMode) {
                "off" -> "opportunistic"
                "opportunistic" -> "hostname"
                else -> "off"
            }
            val bridge = PrivilegedBridgeManager.getActiveBridge()
            if (nextMode == "hostname") {
                SystemSettingsRestorer.recordAndSet(applicationContext, bridge, "GLOBAL", "private_dns_mode", "hostname")
                SystemSettingsRestorer.recordAndSet(applicationContext, bridge, "GLOBAL", "private_dns_specifier", "dns.quad9.net")
            } else {
                SystemSettingsRestorer.recordAndSet(applicationContext, bridge, "GLOBAL", "private_dns_mode", nextMode)
            }
            qsTile?.state = if (nextMode != "off") Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            qsTile?.label = "DNS: ${nextMode.replaceFirstChar { it.uppercase() }}"
            qsTile?.updateTile()
        }
    }
}

@RequiresApi(Build.VERSION_CODES.N)
class GrayscaleTileService : TileService() {
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onStartListening() {
        super.onStartListening()
        val enabled = Settings.Secure.getInt(contentResolver, "accessibility_display_daltonizer_enabled", 0) == 1
        qsTile?.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        qsTile?.label = if (enabled) "Grayscale (On)" else "Grayscale"
        qsTile?.updateTile()
    }

    override fun onClick() {
        super.onClick()
        scope.launch {
            val isEnabled = Settings.Secure.getInt(contentResolver, "accessibility_display_daltonizer_enabled", 0) == 1
            val bridge = PrivilegedBridgeManager.getActiveBridge()
            if (isEnabled) {
                SystemSettingsRestorer.recordAndSet(applicationContext, bridge, "SECURE", "accessibility_display_daltonizer_enabled", "0")
            } else {
                SystemSettingsRestorer.recordAndSet(applicationContext, bridge, "SECURE", "accessibility_display_daltonizer_enabled", "1")
                SystemSettingsRestorer.recordAndSet(applicationContext, bridge, "SECURE", "accessibility_display_daltonizer", "0")
            }
            val updated = !isEnabled
            qsTile?.state = if (updated) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            qsTile?.label = if (updated) "Grayscale (On)" else "Grayscale"
            qsTile?.updateTile()
        }
    }
}

@RequiresApi(Build.VERSION_CODES.N)
class LockScreenTileService : TileService() {
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.state = Tile.STATE_INACTIVE
        qsTile?.label = "Lock Screen"
        qsTile?.updateTile()
    }

    override fun onClick() {
        super.onClick()
        scope.launch {
            val locked = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                IslandAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) ?: false
            } else false

            if (!locked) {
                PrivilegedBridgeManager.exec(PrivilegedCommandRegistry.CMD_LOCK_SCREEN)
            }
        }
    }
}
