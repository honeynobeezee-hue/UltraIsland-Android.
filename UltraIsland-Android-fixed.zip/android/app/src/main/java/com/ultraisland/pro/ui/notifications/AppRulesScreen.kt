package com.ultraisland.pro.ui.notifications

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.core.datastore.AppNotificationRule
import com.ultraisland.pro.core.datastore.IslandSettingsState
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.services.notification.HeadsUpManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class InstalledAppItem(
    val packageName: String,
    val appName: String
)

@Composable
fun AppRulesScreen(
    settings: IslandSettingsState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    var installedApps by remember { mutableStateOf<List<InstalledAppItem>>(emptyList()) }
    var isLoadingApps by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val list = packages
                .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || it.packageName.contains("google") }
                .map {
                    InstalledAppItem(
                        packageName = it.packageName,
                        appName = pm.getApplicationLabel(it).toString()
                    )
                }
                .sortedBy { it.appName.lowercase() }
            withContext(Dispatchers.Main) {
                installedApps = list
                isLoadingApps = false
            }
        }
    }

    val filteredApps = if (searchQuery.isBlank()) {
        installedApps
    } else {
        installedApps.filter {
            it.appName.contains(searchQuery, ignoreCase = true) ||
                    it.packageName.contains(searchQuery, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "App Alerts & Sound Manager",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "Per-app display rules, anti-spam thresholds, and privacy filters",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.6f)
            )
        }

        // Global Notification Policies Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Notification Policies", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    PolicyToggleRow(
                        title = "Auto-expand New Notifications",
                        subtitle = "Immediately opens expanded card when a notification arrives",
                        checked = settings.autoExpandNotification,
                        onCheckedChange = {
                            scope.launch {
                                SettingsRepository.updateSettings { s -> s.copy(autoExpandNotification = it) }
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    PolicyToggleRow(
                        title = "Hide on Lockscreen (Privacy)",
                        subtitle = "Hides notification message and photos when device is locked",
                        checked = settings.hideNotificationOnLockscreen,
                        onCheckedChange = {
                            scope.launch {
                                SettingsRepository.updateSettings { s -> s.copy(hideNotificationOnLockscreen = it) }
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    PolicyToggleRow(
                        title = "Dismiss Clears System Notification",
                        subtitle = "Swiping or closing on island also clears notification in drawer",
                        checked = settings.dismissClearsSystemNotification,
                        onCheckedChange = {
                            scope.launch {
                                SettingsRepository.updateSettings { s -> s.copy(dismissClearsSystemNotification = it) }
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    PolicyToggleRow(
                        title = "Hide System Heads-up Banners",
                        subtitle = "Suppresses default Android heads-up banners to avoid duplicates",
                        checked = settings.hideSystemHeadsUp,
                        onCheckedChange = { isChecked ->
                            scope.launch {
                                SettingsRepository.updateSettings { s -> s.copy(hideSystemHeadsUp = isChecked) }
                                HeadsUpManager.setSystemHeadsUpEnabled(!isChecked)
                            }
                        }
                    )
                }
            }
        }

        // Anti-Spam Cooldown Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Anti-Spam Cooldown", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        text = "If >= ${settings.antiSpamThreshold} notifications arrive from same app within ${settings.antiSpamCooldownSeconds}s, snooze notifications.",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Spam Threshold", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                        Text("${settings.antiSpamThreshold} notifications", color = Color(0xFF388AF6), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Slider(
                        value = settings.antiSpamThreshold.toFloat(),
                        onValueChange = { newVal ->
                            scope.launch {
                                SettingsRepository.updateSettings { s -> s.copy(antiSpamThreshold = newVal.toInt()) }
                            }
                        },
                        valueRange = 2f..15f,
                        steps = 12,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF388AF6),
                            activeTrackColor = Color(0xFF388AF6)
                        )
                    )
                }
            }
        }

        // Search Bar for Apps
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search installed apps...", fontSize = 13.sp, color = Color.White.copy(alpha = 0.4f)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White.copy(alpha = 0.5f)) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color(0xFF388AF6),
                    unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                    focusedContainerColor = Color(0xFF141720),
                    unfocusedContainerColor = Color(0xFF141720)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Per-App List
        items(filteredApps, key = { it.packageName }) { app ->
            val rule = settings.appRules[app.packageName] ?: AppNotificationRule(packageName = app.packageName)
            val isNeverOnCooldown = settings.antiSpamWhitelist.contains(app.packageName)

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF12141A)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF202636)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = app.appName.take(1).uppercase(),
                                    color = Color(0xFF388AF6),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = app.appName,
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = app.packageName,
                                    color = Color.White.copy(alpha = 0.4f),
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Switch(
                            checked = rule.enabled,
                            onCheckedChange = { isEnabled ->
                                scope.launch {
                                    val newRules = settings.appRules.toMutableMap()
                                    newRules[app.packageName] = rule.copy(enabled = isEnabled)
                                    SettingsRepository.updateSettings { s -> s.copy(appRules = newRules) }
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF388AF6)
                            )
                        )
                    }

                    if (rule.enabled) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Private Mode Chip
                            ChipOption(
                                label = "Private (Icon Only)",
                                active = rule.isPrivate,
                                onClick = {
                                    scope.launch {
                                        val newRules = settings.appRules.toMutableMap()
                                        newRules[app.packageName] = rule.copy(isPrivate = !rule.isPrivate)
                                        SettingsRepository.updateSettings { s -> s.copy(appRules = newRules) }
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )

                            // Whitelist Anti-Spam Chip
                            ChipOption(
                                label = "Never on Cooldown",
                                active = isNeverOnCooldown,
                                onClick = {
                                    scope.launch {
                                        val newWhitelist = settings.antiSpamWhitelist.toMutableSet()
                                        if (isNeverOnCooldown) {
                                            newWhitelist.remove(app.packageName)
                                        } else {
                                            newWhitelist.add(app.packageName)
                                        }
                                        SettingsRepository.updateSettings { s -> s.copy(antiSpamWhitelist = newWhitelist) }
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun PolicyToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF388AF6)
            )
        )
    }
}

@Composable
private fun ChipOption(
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) Color(0xFF388AF6).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f))
            .border(1.dp, if (active) Color(0xFF388AF6) else Color.White.copy(alpha = 0.1f), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(vertical = 6.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = if (active) Color(0xFF64B5F6) else Color.White.copy(alpha = 0.6f),
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
