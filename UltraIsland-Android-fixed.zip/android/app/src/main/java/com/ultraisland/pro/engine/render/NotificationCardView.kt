package com.ultraisland.pro.engine.render

import android.app.KeyguardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.core.datastore.IslandSettingsState
import com.ultraisland.pro.engine.activity.NotificationAction
import com.ultraisland.pro.engine.activity.NotificationActivity
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import com.ultraisland.pro.services.notification.IslandNotificationListener

@Composable
fun NotificationCardView(
    notification: NotificationActivity,
    settings: IslandSettingsState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
    val isDeviceLocked = keyguardManager?.isKeyguardLocked == true

    // Check lockscreen privacy setting
    val hideContent = (settings.hideNotificationOnLockscreen && isDeviceLocked) || notification.isPrivate

    val allNotifications by IslandStateMachine.notifications.collectAsState()
    val otherNotifications = allNotifications.filter { it.key != notification.key }

    var replyText by remember { mutableStateOf("") }
    var activeReplyAction by remember(notification.key) {
        mutableStateOf(notification.actions.firstOrNull { it.isQuickReply })
    }

    val accentColor = try {
        Color(android.graphics.Color.parseColor(notification.colorHex))
    } catch (_: Exception) {
        Color(0xFF388AF6)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .pointerInput(notification.key) {
                detectHorizontalDragGestures { _, dragAmount ->
                    if (kotlin.math.abs(dragAmount) > 35) {
                        // Swipe to dismiss
                        IslandStateMachine.removeNotification(
                            key = notification.key,
                            clearSystem = settings.dismissClearsSystemNotification
                        )
                    }
                }
            }
    ) {
        // Main Notification Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                // Header Row: App name & Title & Dismiss button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(accentColor.copy(alpha = 0.2f))
                                .border(1.dp, accentColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = notification.appName.take(1).uppercase(),
                                color = accentColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = if (hideContent) notification.appName else notification.title,
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (!hideContent && notification.subText.isNotBlank()) {
                                Text(
                                    text = notification.subText,
                                    color = Color.White.copy(alpha = 0.5f),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Dismiss Button
                    IconButton(
                        onClick = {
                            IslandStateMachine.removeNotification(
                                key = notification.key,
                                clearSystem = settings.dismissClearsSystemNotification
                            )
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss",
                            tint = Color.White.copy(alpha = 0.6f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Notification Body (with auto-scroll if text is long)
                val scrollState = rememberScrollState()
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 70.dp)
                        .verticalScroll(scrollState)
                ) {
                    Text(
                        text = if (hideContent) "Sensitive notification hidden on lockscreen" else notification.text,
                        color = Color.White.copy(alpha = if (hideContent) 0.5f else 0.85f),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Inline Reply Field (if RemoteInput available)
                if (!hideContent && activeReplyAction != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = replyText,
                            onValueChange = { replyText = it },
                            placeholder = { Text("Reply...", fontSize = 12.sp, color = Color.White.copy(alpha = 0.4f)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = accentColor,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                focusedContainerColor = Color.White.copy(alpha = 0.05f),
                                unfocusedContainerColor = Color.White.copy(alpha = 0.05f)
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                if (replyText.isNotBlank()) {
                                    val success = IslandNotificationListener.sendReply(
                                        context = context,
                                        action = activeReplyAction!!,
                                        replyText = replyText
                                    )
                                    if (success) {
                                        replyText = ""
                                        // Auto dismiss or collapse after reply
                                        IslandStateMachine.collapse()
                                    }
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(accentColor)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Notification Action Buttons Row (Mark read, etc.)
                if (!hideContent && notification.actions.isNotEmpty()) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(notification.actions.filter { !it.isQuickReply }) { action ->
                            Button(
                                onClick = {
                                    try {
                                        action.pendingIntent?.send()
                                        IslandStateMachine.removeNotification(notification.key, clearSystem = true)
                                    } catch (_: Exception) {}
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White.copy(alpha = 0.12f)
                                ),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text(action.title, fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Bubbles for other chats/notifications under card
        if (otherNotifications.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp)
            ) {
                items(otherNotifications) { other ->
                    val otherColor = try {
                        Color(android.graphics.Color.parseColor(other.colorHex))
                    } catch (_: Exception) {
                        Color(0xFF388AF6)
                    }
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color.Black)
                            .border(1.2.dp, otherColor, CircleShape)
                            .clickable {
                                IslandStateMachine.selectNotification(other)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = other.appName.take(1).uppercase(),
                            color = otherColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
