package com.ultraisland.pro.tools.tiles

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.core.datastore.TilePreferences
import com.ultraisland.pro.privileged.PrivilegedBridgeManager
import com.ultraisland.pro.privileged.PrivilegedCommandRegistry
import com.ultraisland.pro.services.accessibility.IslandAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@RequiresApi(Build.VERSION_CODES.N)
abstract class BaseCustomTileService(private val slotIndex: Int) : TileService() {
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onStartListening() {
        super.onStartListening()
        scope.launch {
            val tiles = TilePreferences.getTiles(applicationContext).first()
            val config = tiles.find { it.slot == slotIndex }
            if (config != null) {
                qsTile?.label = config.label
                qsTile?.state = if (config.isEnabled) Tile.STATE_INACTIVE else Tile.STATE_UNAVAILABLE
            } else {
                qsTile?.label = "Custom #$slotIndex"
                qsTile?.state = Tile.STATE_INACTIVE
            }
            qsTile?.updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        scope.launch {
            val tiles = TilePreferences.getTiles(applicationContext).first()
            val config = tiles.find { it.slot == slotIndex } ?: return@launch
            if (!config.isEnabled) return@launch

            qsTile?.state = Tile.STATE_ACTIVE
            qsTile?.updateTile()

            when (config.actionType.uppercase()) {
                "TOGGLE_ISLAND" -> {
                    val cur = SettingsRepository.settingsFlow.first().enabled
                    SettingsRepository.updateSettings { it.copy(enabled = !cur) }
                }
                "SCREENSHOT" -> {
                    val taken = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        IslandAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) ?: false
                    } else false
                    if (!taken) PrivilegedBridgeManager.exec(PrivilegedCommandRegistry.CMD_SCREENSHOT)
                }
                "LOCK_SCREEN" -> {
                    val locked = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        IslandAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) ?: false
                    } else false
                    if (!locked) PrivilegedBridgeManager.exec(PrivilegedCommandRegistry.CMD_LOCK_SCREEN)
                }
                "LAUNCH_APP" -> {
                    if (config.targetPayload.isNotEmpty()) {
                        val launchIntent = packageManager.getLaunchIntentForPackage(config.targetPayload)
                        if (launchIntent != null) {
                            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivityAndCollapse(launchIntent)
                        }
                    }
                }
                "SHELL" -> {
                    if (config.targetPayload.isNotEmpty()) {
                        PrivilegedBridgeManager.exec(config.targetPayload)
                    }
                }
            }

            kotlinx.coroutines.delay(400)
            qsTile?.state = Tile.STATE_INACTIVE
            qsTile?.updateTile()
        }
    }
}

@RequiresApi(Build.VERSION_CODES.N) class CustomTile1Service : BaseCustomTileService(1)
@RequiresApi(Build.VERSION_CODES.N) class CustomTile2Service : BaseCustomTileService(2)
@RequiresApi(Build.VERSION_CODES.N) class CustomTile3Service : BaseCustomTileService(3)
@RequiresApi(Build.VERSION_CODES.N) class CustomTile4Service : BaseCustomTileService(4)
@RequiresApi(Build.VERSION_CODES.N) class CustomTile5Service : BaseCustomTileService(5)
@RequiresApi(Build.VERSION_CODES.N) class CustomTile6Service : BaseCustomTileService(6)
@RequiresApi(Build.VERSION_CODES.N) class CustomTile7Service : BaseCustomTileService(7)
@RequiresApi(Build.VERSION_CODES.N) class CustomTile8Service : BaseCustomTileService(8)
@RequiresApi(Build.VERSION_CODES.N) class CustomTile9Service : BaseCustomTileService(9)
@RequiresApi(Build.VERSION_CODES.N) class CustomTile10Service : BaseCustomTileService(10)
