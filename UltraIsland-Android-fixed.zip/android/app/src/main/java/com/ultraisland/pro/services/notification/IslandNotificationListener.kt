package com.ultraisland.pro.services.notification

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.engine.activity.NotificationAction
import com.ultraisland.pro.engine.activity.NotificationActivity
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class IslandNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        isSystemConnected = true
        Log.i(TAG, "IslandNotificationListener connected successfully")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        instance = null
        isSystemConnected = false
        Log.w(TAG, "IslandNotificationListener disconnected - requesting rebind")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            requestRebind(ComponentName(this, IslandNotificationListener::class.java))
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val pkg = sbn.packageName
        if (pkg == packageName) return // Ignore self

        scope.launch {
            try {
                val settings = SettingsRepository.settingsFlow.first()
                if (!settings.islandEnabled) return@launch

                // Phase 5: Check Navigation (Google Maps, Waze, OsmAnd)
                if (com.ultraisland.pro.services.navigation.NavigationTracker.processNotification(sbn, applicationContext)) {
                    return@launch
                }

                // Phase 5: Check Ride & Delivery (Uber, Grab, Gojek, Zomato, Swiggy)
                if (com.ultraisland.pro.services.delivery.RideDeliveryTracker.processNotification(sbn, applicationContext)) {
                    return@launch
                }

                // 1. Check per-app rules
                val rule = settings.appRules[pkg]
                if (rule != null && !rule.enabled) {
                    Log.d(TAG, "Notification from $pkg ignored by user rule")
                    return@launch
                }

                // 2. Check Anti-Spam
                if (AntiSpamManager.shouldBlock(
                        packageName = pkg,
                        threshold = settings.antiSpamThreshold,
                        windowSeconds = settings.antiSpamCooldownSeconds,
                        whitelist = settings.antiSpamWhitelist
                    )
                ) {
                    return@launch
                }

                // 3. Extract Notification Data
                val notification = sbn.notification ?: return@launch
                val extras = notification.extras ?: Bundle()

                val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
                    ?: extras.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString()
                    ?: ""

                val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
                    ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
                    ?: ""

                val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""

                // Ignore completely empty notifications
                if (title.isBlank() && text.isBlank()) return@launch

                val pm = applicationContext.packageManager
                val appName = try {
                    val appInfo = pm.getApplicationInfo(pkg, 0)
                    pm.getApplicationLabel(appInfo).toString()
                } catch (_: Exception) {
                    pkg
                }

                // Extract Notification Actions & RemoteInputs
                val actionsList = mutableListOf<NotificationAction>()
                notification.actions?.forEach { act ->
                    val actTitle = act.title?.toString() ?: ""
                    var remoteInput: RemoteInput? = null
                    act.remoteInputs?.forEach { ri ->
                        if (ri.resultKey != null) {
                            remoteInput = ri
                        }
                    }
                    actionsList.add(
                        NotificationAction(
                            title = actTitle,
                            pendingIntent = act.actionIntent,
                            remoteInput = remoteInput,
                            isQuickReply = remoteInput != null
                        )
                    )
                }

                val colorHex = rule?.customColorHex ?: String.format("#%06X", 0xFFFFFF and (notification.color.takeIf { it != 0 } ?: 0x388AF6))

                val notifActivity = NotificationActivity(
                    key = sbn.key,
                    packageName = pkg,
                    appName = appName,
                    title = title,
                    text = text,
                    subText = subText,
                    timestamp = sbn.postTime,
                    colorHex = colorHex,
                    actions = actionsList,
                    groupKey = sbn.groupKey,
                    isPrivate = rule?.isPrivate ?: false
                )

                IslandStateMachine.postNotification(
                    notif = notifActivity,
                    autoExpand = settings.autoExpandNotification
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error processing notification", e)
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        if (sbn != null) {
            com.ultraisland.pro.services.navigation.NavigationTracker.onNotificationRemoved(sbn)
            com.ultraisland.pro.services.delivery.RideDeliveryTracker.onNotificationRemoved(sbn)
            IslandStateMachine.removeNotification(sbn.key)
        }
    }

    companion object {
        private const val TAG = "IslandNotificationListener"

        /** True selama sistem Android menghubungkan listener ini (dipakai SystemServiceRecovery). */
        @Volatile var isSystemConnected: Boolean = false
            private set
        var instance: IslandNotificationListener? = null
            private set

        /**
         * Dismiss / cancel notification in Android notification drawer
         */
        fun cancelNotification(key: String) {
            try {
                instance?.cancelNotification(key)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to cancel notification $key", e)
            }
        }

        /**
         * Send a direct reply back to the chat app using RemoteInput
         */
        fun sendReply(context: Context, action: NotificationAction, replyText: String): Boolean {
            val pendingIntent = action.pendingIntent ?: return false
            val remoteInput = action.remoteInput ?: return false

            return try {
                val intent = Intent()
                val bundle = Bundle()
                bundle.putCharSequence(remoteInput.resultKey, replyText)
                RemoteInput.addResultsToIntent(arrayOf(remoteInput), intent, bundle)
                pendingIntent.send(context, 0, intent)
                Log.i(TAG, "Quick reply sent successfully")
                true
            } catch (e: Exception) {
                Log.e(TAG, "Failed to send quick reply", e)
                false
            }
        }
    }
}
