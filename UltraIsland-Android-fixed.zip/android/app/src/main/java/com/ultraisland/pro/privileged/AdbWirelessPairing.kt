package com.ultraisland.pro.privileged

import android.content.Context
import android.os.Build
import com.ultraisland.pro.core.common.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AdbWirelessPairing @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun isSupported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

    suspend fun testPortConnectivity(host: String = "127.0.0.1", port: Int): Boolean = withContext(Dispatchers.IO) {
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 1500)
                true
            }
        } catch (e: Exception) {
            Logger.d(TAG, "Port $port not reachable: ${e.message}")
            false
        }
    }

    companion object {
        private const val TAG = "AdbWirelessPairing"
    }
}
