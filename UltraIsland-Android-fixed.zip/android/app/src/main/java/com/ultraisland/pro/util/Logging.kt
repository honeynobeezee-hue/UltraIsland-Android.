package com.ultraisland.pro.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import kotlin.coroutines.cancellation.CancellationException

/**
 * Menjalankan [block]; bila gagal, menulis log dan mengembalikan null (CancellationException tetap dilempar).
 */
inline fun <T> runCatchingLogged(tag: String, message: String, block: () -> T): T? =
    try {
        block()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Throwable) {
        Log.w(tag, message, e)
        null
    }

/**
 * Memulai Activity tanpa crash. Mengembalikan true bila berhasil. [errorMessage] (jika tidak null)
 * ditampilkan sebagai Toast saat gagal.
 */
fun Context.safeStartActivity(intent: Intent, errorMessage: String? = null): Boolean =
    try {
        if (this !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        true
    } catch (e: Exception) {
        Log.w("safeStartActivity", "Cannot start $intent", e)
        if (errorMessage != null) Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
        false
    }
