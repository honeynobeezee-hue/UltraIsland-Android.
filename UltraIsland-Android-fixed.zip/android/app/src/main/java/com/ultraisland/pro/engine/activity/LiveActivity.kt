package com.ultraisland.pro.engine.activity

data class LiveActivity(
    val id: String,
    val title: String,
    val subtitle: String,
    val iconType: String = "default",
    val colorHex: String = "#388AF6",
    val timestamp: Long = System.currentTimeMillis(),
    val progress: Int? = null,
    val durationSeconds: Long? = null,
    val actionIntent: String? = null
)
