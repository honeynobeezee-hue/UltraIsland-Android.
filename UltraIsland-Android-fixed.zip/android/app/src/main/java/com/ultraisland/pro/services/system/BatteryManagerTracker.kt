package com.ultraisland.pro.services.system

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.ultraisland.pro.engine.statemachine.IslandStateMachine

data class BatteryStatusInfo(
    val percentage: Int,
    val isCharging: Boolean,
    val chargingType: String, // "Fast Charging", "Wireless", "USB", "AC"
    val isLowBattery: Boolean,
    val isFull: Boolean
)

object BatteryManagerTracker {
    private const val TAG = "BatteryManagerTracker"
    private val mainHandler = Handler(Looper.getMainLooper())

    fun checkCurrentBattery(context: Context): BatteryStatusInfo {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, filter)

        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: 50
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: 100
        val percentage = if (scale > 0) (level * 100 / scale) else level

        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val isFull = status == BatteryManager.BATTERY_STATUS_FULL || percentage >= 100

        val plugged = batteryStatus?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: 0
        val chargingType = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless Charging"
            BatteryManager.BATTERY_PLUGGED_AC -> if (percentage < 80) "Fast Charging" else "AC Charging"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB Charging"
            else -> "Charging"
        }

        return BatteryStatusInfo(
            percentage = percentage,
            isCharging = isCharging,
            chargingType = chargingType,
            isLowBattery = !isCharging && percentage <= 20,
            isFull = isFull
        )
    }

    fun onPowerConnected(context: Context) {
        val status = checkCurrentBattery(context)
        Log.i(TAG, "Power connected: ${status.chargingType} (${status.percentage}%)")
        IslandStateMachine.postCharging(status, autoExpand = true)

        // Auto-collapse after 4 seconds
        mainHandler.postDelayed({
            IslandStateMachine.collapse()
        }, 4000L)
    }

    fun onPowerDisconnected(context: Context) {
        val status = checkCurrentBattery(context)
        Log.i(TAG, "Power disconnected: ${status.percentage}%")
        IslandStateMachine.clearCharging()
    }

    fun onBatteryLow(context: Context) {
        val status = checkCurrentBattery(context)
        Log.w(TAG, "Battery Low: ${status.percentage}%")
        IslandStateMachine.postCharging(status, autoExpand = true)
    }
}
