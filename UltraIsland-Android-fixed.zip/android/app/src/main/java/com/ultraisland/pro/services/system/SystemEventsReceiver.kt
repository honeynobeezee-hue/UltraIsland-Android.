package com.ultraisland.pro.services.system

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build

class SystemEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return

        when (intent.action) {
            Intent.ACTION_POWER_CONNECTED -> {
                BatteryManagerTracker.onPowerConnected(context)
            }

            Intent.ACTION_POWER_DISCONNECTED -> {
                BatteryManagerTracker.onPowerDisconnected(context)
            }

            Intent.ACTION_BATTERY_LOW -> {
                BatteryManagerTracker.onBatteryLow(context)
            }

            Intent.ACTION_HEADSET_PLUG -> {
                val state = intent.getIntExtra("state", -1)
                BluetoothTracker.onHeadsetPlugged(state)
            }

            BluetoothDevice.ACTION_ACL_CONNECTED -> {
                val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                }
                BluetoothTracker.onBluetoothDeviceConnected(device)
            }

            BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                BluetoothTracker.onBluetoothDeviceDisconnected()
            }

            AudioManager.RINGER_MODE_CHANGED_ACTION -> {
                SoundAndDeviceTracker.checkAndNotifySoundStatus()
            }
        }
    }
}
