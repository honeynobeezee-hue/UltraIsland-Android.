package com.ultraisland.pro.ui.studio

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.R
import com.ultraisland.pro.core.datastore.ColorTheme
import com.ultraisland.pro.core.datastore.IslandSettingsState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppearanceScreen(
    settings: IslandSettingsState,
    onUpdate: ((IslandSettingsState) -> IslandSettingsState) -> Unit,
    onBack: () -> Unit
) {
    val ledSwatches = listOf("#00FF66", "#388AF6", "#FF9500", "#FF3B30", "#AF52DE", "#FFFFFF")
    val gradientSwatches = listOf("#8A2BE2", "#388AF6", "#E0245E", "#00B14F", "#FF9500")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.appearance_title),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = stringResource(R.string.appearance_subtitle),
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF090A0D))
            )
        },
        containerColor = Color(0xFF090A0D)
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Preview Island
            item {
                Spacer(modifier = Modifier.height(4.dp))
                StudioLivePreview(settings = settings)
            }

            // Section 1: Glassmorphic & Opacity
            item {
                StudioSectionCard(
                    title = "Opacity & Frosted Glass",
                    subtitle = "Tune island backdrop transparency and blur physics"
                ) {
                    StudioSlider(
                        title = stringResource(R.string.bg_opacity_title),
                        value = settings.backgroundOpacity,
                        range = 0.2f..1.0f,
                        unit = "%",
                        decimalPlaces = 2,
                        onValueChange = { onUpdate { s -> s.copy(backgroundOpacity = it) } }
                    )

                    StudioSlider(
                        title = stringResource(R.string.bg_blur_title),
                        value = settings.backgroundBlurRadius.toFloat(),
                        range = 0f..30f,
                        unit = "dp",
                        decimalPlaces = 0,
                        onValueChange = { onUpdate { s -> s.copy(backgroundBlurRadius = it.toInt()) } }
                    )

                    StudioToggle(
                        title = stringResource(R.string.card_blur_title),
                        subtitle = stringResource(R.string.card_blur_desc),
                        checked = settings.cardBlurEnabled,
                        onCheckedChange = { onUpdate { s -> s.copy(cardBlurEnabled = it) } }
                    )

                    StudioToggle(
                        title = stringResource(R.string.album_backdrop_title),
                        subtitle = stringResource(R.string.album_backdrop_desc),
                        checked = settings.albumBackdropBlur,
                        onCheckedChange = { onUpdate { s -> s.copy(albumBackdropBlur = it) } }
                    )
                }
            }

            // Section 2: Color Themes & Gradient
            item {
                StudioSectionCard(
                    title = stringResource(R.string.color_themes_title),
                    subtitle = "Select a preset palette or blend custom gradients"
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioChip(
                            label = "Noir OLED",
                            isSelected = settings.colorTheme == ColorTheme.NOIR_OLED,
                            onClick = { onUpdate { s -> s.copy(colorTheme = ColorTheme.NOIR_OLED) } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Dark Grey",
                            isSelected = settings.colorTheme == ColorTheme.DARK_GREY,
                            onClick = { onUpdate { s -> s.copy(colorTheme = ColorTheme.DARK_GREY) } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Material You",
                            isSelected = settings.colorTheme == ColorTheme.MATERIAL_YOU_DYNAMIC,
                            onClick = { onUpdate { s -> s.copy(colorTheme = ColorTheme.MATERIAL_YOU_DYNAMIC) } },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioChip(
                            label = "iOS Minimal",
                            isSelected = settings.colorTheme == ColorTheme.IOS_MINIMAL,
                            onClick = { onUpdate { s -> s.copy(colorTheme = ColorTheme.IOS_MINIMAL) } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Neon Cyan",
                            isSelected = settings.colorTheme == ColorTheme.NEON_CYAN,
                            onClick = { onUpdate { s -> s.copy(colorTheme = ColorTheme.NEON_CYAN) } },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    StudioToggle(
                        title = stringResource(R.string.gradient_title),
                        subtitle = stringResource(R.string.gradient_desc),
                        checked = settings.gradientEnabled,
                        onCheckedChange = { onUpdate { s -> s.copy(gradientEnabled = it) } }
                    )

                    if (settings.gradientEnabled) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = stringResource(R.string.gradient_color_title),
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        ColorSwatchPicker(
                            selectedHex = settings.gradientSecondColorHex,
                            swatches = gradientSwatches,
                            onSelect = { onUpdate { s -> s.copy(gradientSecondColorHex = it) } }
                        )
                    }
                }
            }

            // Section 3: Ambient Elevation & LED
            item {
                StudioSectionCard(
                    title = "Ambient Lighting & LED",
                    subtitle = "Glow flares and physical status LED indicators"
                ) {
                    StudioToggle(
                        title = stringResource(R.string.ambient_shadow_title),
                        subtitle = stringResource(R.string.ambient_shadow_desc),
                        checked = settings.ambientDropShadow,
                        onCheckedChange = { onUpdate { s -> s.copy(ambientDropShadow = it) } }
                    )

                    StudioToggle(
                        title = "Glowing Outline Border",
                        subtitle = "High-contrast border outline for OLED clarity",
                        checked = settings.showOutlineBorder,
                        onCheckedChange = { onUpdate { s -> s.copy(showOutlineBorder = it) } }
                    )

                    StudioToggle(
                        title = "Activity Glow Flash",
                        subtitle = "Perimeter strobe when new live activity triggers",
                        checked = settings.showGlowFlash,
                        onCheckedChange = { onUpdate { s -> s.copy(showGlowFlash = it) } }
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = stringResource(R.string.led_color_title),
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    ColorSwatchPicker(
                        selectedHex = settings.ledColorHex,
                        swatches = ledSwatches,
                        onSelect = { onUpdate { s -> s.copy(ledColorHex = it) } }
                    )
                }
            }

            // Section 4: Per-Activity Typography & Corner Radius
            item {
                StudioSectionCard(
                    title = "Per-Activity Scaling",
                    subtitle = "Fine-tune card corner roundness and font scale across activities"
                ) {
                    StudioSlider(
                        title = stringResource(R.string.per_activity_text_scale),
                        value = settings.perActivityTextScale,
                        range = 0.8f..1.4f,
                        unit = "x",
                        decimalPlaces = 2,
                        onValueChange = { onUpdate { s -> s.copy(perActivityTextScale = it) } }
                    )

                    StudioSlider(
                        title = stringResource(R.string.per_activity_corner_radius),
                        value = settings.perActivityCornerRadius.toFloat(),
                        range = 14f..36f,
                        unit = "dp",
                        decimalPlaces = 0,
                        onValueChange = { onUpdate { s -> s.copy(perActivityCornerRadius = it.toInt()) } }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }
}
