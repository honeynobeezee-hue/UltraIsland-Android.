package com.ultraisland.pro.engine.idle

import android.content.Context
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import com.ultraisland.pro.services.calendar.CalendarTracker
import com.ultraisland.pro.services.network.NetworkSpeedTracker
import com.ultraisland.pro.services.weather.WeatherManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class IdleWidgetType {
    CLOCK_LED,
    DATE,
    WEATHER,
    BATTERY,
    NETWORK_SPEED,
    CALENDAR_EVENT,
    NEXT_ALARM
}

data class IdleWidgetInfo(
    val type: IdleWidgetType,
    val primaryText: String,
    val secondaryText: String,
    val iconName: String,
    val accentColorHex: String = "#388AF6"
)

object IdleWidgetManager {
    private val _currentWidget = MutableStateFlow(
        IdleWidgetInfo(
            type = IdleWidgetType.CLOCK_LED,
            primaryText = "10:41",
            secondaryText = "WED 24 OCT",
            iconName = "clock",
            accentColorHex = "#388AF6"
        )
    )
    val currentWidget: StateFlow<IdleWidgetInfo> = _currentWidget.asStateFlow()

    private var cycleJob: Job? = null
    private var cycleIntervalSeconds = 5
    private var isSplitPillEnabled = false
    private var autoHideIdle = false

    private val activeWidgetTypes = mutableListOf(
        IdleWidgetType.CLOCK_LED,
        IdleWidgetType.WEATHER,
        IdleWidgetType.NETWORK_SPEED,
        IdleWidgetType.CALENDAR_EVENT
    )
    private var currentIndex = 0

    fun init(context: Context, scope: CoroutineScope) {
        startCycle(context, scope)
    }

    fun setConfig(
        intervalSeconds: Int,
        splitPill: Boolean,
        autoHide: Boolean,
        context: Context,
        scope: CoroutineScope
    ) {
        cycleIntervalSeconds = intervalSeconds.coerceAtLeast(2)
        isSplitPillEnabled = splitPill
        autoHideIdle = autoHide
        IslandStateMachine.setIdleSplitPill(splitPill)
        IslandStateMachine.setAutoHideIdle(autoHide)
        startCycle(context, scope)
    }

    fun startCycle(context: Context, scope: CoroutineScope) {
        cycleJob?.cancel()
        cycleJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                updateCurrentWidget(context)
                delay(cycleIntervalSeconds * 1000L)
                currentIndex = (currentIndex + 1) % activeWidgetTypes.size
            }
        }
    }

    fun stopCycle() {
        cycleJob?.cancel()
        cycleJob = null
    }

    private fun updateCurrentWidget(context: Context) {
        if (activeWidgetTypes.isEmpty()) return
        val type = activeWidgetTypes[currentIndex % activeWidgetTypes.size]

        val widgetInfo = when (type) {
            IdleWidgetType.CLOCK_LED -> {
                val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                val dateFormat = SimpleDateFormat("EEE d MMM", Locale.getDefault())
                val now = Date()
                IdleWidgetInfo(
                    type = IdleWidgetType.CLOCK_LED,
                    primaryText = timeFormat.format(now),
                    secondaryText = dateFormat.format(now).uppercase(),
                    iconName = "clock",
                    accentColorHex = "#388AF6"
                )
            }
            IdleWidgetType.WEATHER -> {
                val weather = WeatherManager.weatherState.value
                IdleWidgetInfo(
                    type = IdleWidgetType.WEATHER,
                    primaryText = "${weather.temperatureCelsius}°C",
                    secondaryText = weather.conditionText,
                    iconName = weather.iconType,
                    accentColorHex = "#FFD600"
                )
            }
            IdleWidgetType.NETWORK_SPEED -> {
                val speed = NetworkSpeedTracker.speedState.value
                IdleWidgetInfo(
                    type = IdleWidgetType.NETWORK_SPEED,
                    primaryText = speed.downloadSpeedText,
                    secondaryText = "Network",
                    iconName = "wifi",
                    accentColorHex = "#30B0C7"
                )
            }
            IdleWidgetType.CALENDAR_EVENT -> {
                val cal = CalendarTracker.getNextUpcomingEvent(context)
                if (cal != null) {
                    IdleWidgetInfo(
                        type = IdleWidgetType.CALENDAR_EVENT,
                        primaryText = cal.formattedTime,
                        secondaryText = "${cal.title} (${cal.relativeTime})",
                        iconName = "calendar",
                        accentColorHex = "#FF9500"
                    )
                } else {
                    // Fallback to Date if no upcoming event
                    val dateFormat = SimpleDateFormat("d MMMM yyyy", Locale.getDefault())
                    IdleWidgetInfo(
                        type = IdleWidgetType.DATE,
                        primaryText = dateFormat.format(Date()),
                        secondaryText = "No events",
                        iconName = "calendar",
                        accentColorHex = "#34C759"
                    )
                }
            }
            IdleWidgetType.DATE -> {
                val dateFormat = SimpleDateFormat("EEEE, d MMM", Locale.getDefault())
                IdleWidgetInfo(
                    type = IdleWidgetType.DATE,
                    primaryText = dateFormat.format(Date()),
                    secondaryText = "Today",
                    iconName = "calendar",
                    accentColorHex = "#34C759"
                )
            }
            IdleWidgetType.BATTERY -> {
                IdleWidgetInfo(
                    type = IdleWidgetType.BATTERY,
                    primaryText = "85%",
                    secondaryText = "Battery Normal",
                    iconName = "battery",
                    accentColorHex = "#34C759"
                )
            }
            IdleWidgetType.NEXT_ALARM -> {
                IdleWidgetInfo(
                    type = IdleWidgetType.NEXT_ALARM,
                    primaryText = "07:00",
                    secondaryText = "Alarm",
                    iconName = "alarm",
                    accentColorHex = "#FF9500"
                )
            }
        }

        _currentWidget.value = widgetInfo
        IslandStateMachine.setIdleWidget(widgetInfo)
    }
}
