/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.ultraisland.pro.ui.sections

import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import android.util.LruCache
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.BluetoothConnected
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DoNotDisturbOn
import androidx.compose.material.icons.rounded.OpenInFull
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import com.ultraisland.pro.ui.SliderSettingItem
import com.ultraisland.pro.ui.bounceClick
import kotlin.math.roundToInt
import com.ultraisland.pro.ui.glass.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import com.ultraisland.pro.ui.glass.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.R
import com.ultraisland.pro.ui.search.searchAnchor
import com.ultraisland.pro.data.AppShortcutProvider
import com.ultraisland.pro.data.LaunchableApp
import com.ultraisland.pro.data.UltraIslandSettings
import com.ultraisland.pro.data.UltraIslandSettingsRepository
import com.ultraisland.pro.util.AppAutoExpand
import com.ultraisland.pro.util.AppEventRules
import com.ultraisland.pro.util.NotificationFilter
import com.ultraisland.pro.util.OemDeviceRules
import com.ultraisland.pro.util.OemDeviceType
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.style.TextOverflow
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsAndPrivacySection(
    settings: UltraIslandSettings,
    repository: UltraIslandSettingsRepository
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val detectedDevice = remember { OemDeviceRules.detectCurrentDevice() }
    val effectiveDevice = remember(settings.deviceType) { OemDeviceRules.resolveEffectiveDevice(settings.deviceType) }
    var isDeviceMenuExpanded by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Smartphone,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.oem_rules_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = stringResource(R.string.oem_rules_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                ExposedDropdownMenuBox(
                    expanded = isDeviceMenuExpanded,
                    onExpandedChange = { isDeviceMenuExpanded = it },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val currentSelectionText = if (settings.deviceType == "AUTO") {
                        stringResource(R.string.auto_detect_device, detectedDevice.displayName)
                    } else {
                        effectiveDevice.displayName
                    }

                    OutlinedTextField(
                        value = currentSelectionText,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(stringResource(R.string.select_device_oem)) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDeviceMenuExpanded) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable, true)
                            .fillMaxWidth()
                    )

                    ExposedDropdownMenu(
                        expanded = isDeviceMenuExpanded,
                        onDismissRequest = { isDeviceMenuExpanded = false }
                    ) {
                        OemDeviceType.entries.forEach { deviceTypeOption ->
                            val isSelected = (settings.deviceType == "AUTO" && deviceTypeOption == OemDeviceType.AUTO) ||
                                (settings.deviceType == deviceTypeOption.name)
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (deviceTypeOption == OemDeviceType.AUTO) stringResource(R.string.auto_detect_device, detectedDevice.displayName) else deviceTypeOption.displayName,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Rounded.CheckCircle,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    scope.launch { repository.setDeviceType(deviceTypeOption.name) }
                                    isDeviceMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = stringResource(R.string.active_rules_title, effectiveDevice.displayName),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = stringResource(R.string.active_rules_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = stringResource(R.string.notifications_master_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                ToggleRowItem(
                    searchKey = "np.notifications_enabled",
                    title = stringResource(R.string.toggle_notifications_enabled_title),
                    subtitle = stringResource(R.string.toggle_notifications_enabled_desc),
                    icon = Icons.Rounded.Notifications,
                    checked = settings.notificationsEnabled,
                    onCheckedChange = { scope.launch { repository.setNotificationsEnabled(it) } }
                )
                if (!settings.notificationsEnabled) {
                    Text(
                        text = stringResource(R.string.notifications_master_off_note),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = stringResource(R.string.lock_screen_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = stringResource(R.string.lock_screen_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                // Presets on top of the switches; the one the switches add up to is highlighted.
                Column(
                    modifier = Modifier.fillMaxWidth().searchAnchor("np.lock_screen_preset"),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = stringResource(R.string.lock_screen_preset_title),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    val currentPreset = com.ultraisland.pro.model.LockScreenPreset.from(settings)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            com.ultraisland.pro.model.LockScreenPreset.ShowAll to R.string.lock_screen_preset_show_all,
                            com.ultraisland.pro.model.LockScreenPreset.MessagesOnly to R.string.lock_screen_preset_messages,
                            com.ultraisland.pro.model.LockScreenPreset.CallsOnly to R.string.lock_screen_preset_calls,
                            com.ultraisland.pro.model.LockScreenPreset.Off to R.string.lock_screen_preset_nothing
                        ).forEach { (preset, label) ->
                            PrivacySegmentButton(
                                label = stringResource(label),
                                selected = currentPreset == preset,
                                onClick = { scope.launch { repository.applyLockScreenPreset(preset) } },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Text(
                        text = stringResource(R.string.lock_screen_preset_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                ToggleRowItem(
                    searchKey = "np.show_lock_screen",
                    title = stringResource(R.string.toggle_show_lock_screen_title),
                    subtitle = stringResource(R.string.toggle_show_lock_screen_desc),
                    icon = Icons.Rounded.Lock,
                    checked = settings.showOnLockScreen,
                    onCheckedChange = { scope.launch { repository.setShowOnLockScreen(it) } }
                )

                if (settings.showOnLockScreen) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.privacy_level_title),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PrivacySegmentButton(
                                label = stringResource(R.string.privacy_app_icon_only),
                                selected = settings.lockScreenPrivacy == "AppIconOnly",
                                onClick = { scope.launch { repository.setLockScreenPrivacy("AppIconOnly") } },
                                modifier = Modifier.weight(1f)
                            )
                            PrivacySegmentButton(
                                label = stringResource(R.string.privacy_full_content),
                                selected = settings.lockScreenPrivacy == "FullContent",
                                onClick = { scope.launch { repository.setLockScreenPrivacy("FullContent") } },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                if (settings.showOnLockScreen) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                    ToggleRowItem(
                        searchKey = "np.hide_all_lock_screen",
                        title = stringResource(R.string.toggle_hide_all_lock_screen_title),
                        subtitle = stringResource(R.string.toggle_hide_all_lock_screen_desc),
                        icon = Icons.Rounded.VisibilityOff,
                        checked = settings.hideAllOnLockScreen,
                        onCheckedChange = { scope.launch { repository.setHideAllOnLockScreen(it) } }
                    )
                    // The per-event switches only matter while the universal one is off.
                    if (!settings.hideAllOnLockScreen) {
                        LockScreenEventList(settings = settings, repository = repository)
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                ToggleRowItem(
                    searchKey = "np.live_events_foreground",
                    title = stringResource(R.string.toggle_live_events_foreground_title),
                    subtitle = stringResource(R.string.toggle_live_events_foreground_desc),
                    icon = Icons.Rounded.OpenInFull,
                    checked = settings.showLiveEventsInForeground,
                    onCheckedChange = { scope.launch { repository.setShowLiveEventsInForeground(it) } }
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                ToggleRowItem(
                    searchKey = "np.network_access",
                    title = stringResource(R.string.toggle_network_access_title),
                    subtitle = stringResource(R.string.toggle_network_access_desc),
                    icon = Icons.Rounded.Public,
                    checked = settings.allowNetworkChecks,
                    onCheckedChange = { scope.launch { repository.setAllowNetworkChecks(it) } }
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                ToggleRowItem(
                    searchKey = "np.transfer_speed",
                    title = stringResource(R.string.toggle_transfer_speed_title),
                    subtitle = stringResource(R.string.toggle_transfer_speed_desc),
                    icon = Icons.Rounded.Speed,
                    checked = settings.detectTransfersBySpeed,
                    onCheckedChange = { scope.launch { repository.setDetectTransfersBySpeed(it) } }
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = stringResource(R.string.display_rules_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = stringResource(R.string.display_rules_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                ToggleRowItem(
                    searchKey = "np.auto_expand",
                    title = stringResource(R.string.toggle_auto_expand_title),
                    subtitle = stringResource(R.string.toggle_auto_expand_desc),
                    icon = Icons.Rounded.NotificationsActive,
                    checked = settings.autoExpandOnNotification,
                    onCheckedChange = { scope.launch { repository.setAutoExpandOnNotification(it) } }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                ToggleRowItem(
                    searchKey = "np.auto_expand_lock_screen",
                    title = stringResource(R.string.toggle_auto_expand_lock_screen_title),
                    subtitle = stringResource(R.string.toggle_auto_expand_lock_screen_desc),
                    icon = Icons.Rounded.Lock,
                    checked = settings.autoExpandOnLockScreen,
                    onCheckedChange = { scope.launch { repository.setAutoExpandOnLockScreen(it) } }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                ToggleRowItem(
                    searchKey = "np.show_during_dnd",
                    title = stringResource(R.string.toggle_show_during_dnd_title),
                    subtitle = stringResource(R.string.toggle_show_during_dnd_desc),
                    icon = Icons.Rounded.DoNotDisturbOn,
                    checked = settings.showDuringDnd,
                    onCheckedChange = { scope.launch { repository.setShowDuringDnd(it) } }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                ToggleRowItem(
                    searchKey = "np.quick_actions",
                    title = stringResource(R.string.toggle_quick_actions_title),
                    subtitle = stringResource(R.string.toggle_quick_actions_desc),
                    icon = Icons.Rounded.TouchApp,
                    checked = settings.showNotificationActions,
                    onCheckedChange = { scope.launch { repository.setShowNotificationActions(it) } }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                ToggleRowItem(
                    searchKey = "np.mirror_only",
                    title = stringResource(R.string.toggle_mirror_only_title),
                    subtitle = stringResource(R.string.toggle_mirror_only_desc),
                    icon = Icons.Rounded.VisibilityOff,
                    checked = settings.hideFromNotificationShade,
                    onCheckedChange = { scope.launch { repository.setHideFromNotificationShade(it) } }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                ToggleRowItem(
                    searchKey = "np.hide_when_idle",
                    title = stringResource(R.string.toggle_auto_hide_idle_title),
                    subtitle = stringResource(R.string.toggle_auto_hide_idle_desc),
                    icon = Icons.Rounded.VisibilityOff,
                    checked = settings.hideWhenIdle,
                    onCheckedChange = { scope.launch { repository.setHideWhenIdle(it) } }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                ToggleRowItem(
                    searchKey = "np.auto_hide_pill",
                    title = stringResource(R.string.toggle_auto_hide_pill_title),
                    subtitle = stringResource(R.string.toggle_auto_hide_pill_desc),
                    icon = Icons.Rounded.Timer,
                    checked = settings.autoHidePill,
                    onCheckedChange = { scope.launch { repository.setAutoHidePill(it) } }
                )

                AnimatedVisibility(
                    visible = settings.autoHidePill,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(3, 5, 10, 15, 30).forEach { sec ->
                                val isSelected = settings.autoHideTimeoutSeconds == sec
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        scope.launch { repository.setAutoHideTimeoutSeconds(sec) }
                                    },
                                    label = { Text("${sec}s", fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                )
                            }
                        }

                        SliderSettingItem(
                            label = stringResource(R.string.auto_hide_timeout_label),
                            value = settings.autoHideTimeoutSeconds.toFloat(),
                            range = 1f..60f,
                            step = 1f,
                            suffix = "s",
                            onValueChange = { newVal ->
                                scope.launch { repository.setAutoHideTimeoutSeconds(newVal.roundToInt()) }
                            }
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                ToggleRowItem(
                    searchKey = "np.bluetooth_battery",
                    title = stringResource(R.string.toggle_bluetooth_battery_title),
                    subtitle = stringResource(R.string.toggle_bluetooth_battery_desc),
                    icon = Icons.Rounded.BluetoothConnected,
                    checked = settings.showBluetoothBattery,
                    onCheckedChange = { scope.launch { repository.setShowBluetoothBattery(it) } }
                )

            }
        }

        val installedApps by produceState(initialValue = emptyList<LaunchableApp>(), context) {
            value = withContext(Dispatchers.IO) {
                val apps = AppShortcutProvider.installedApps(context)
                    .filter { NotificationFilter.isAppEligibleForIsland(it.packageName, context.packageManager) }
                // The system Download Manager posts its notifications as com.android.providers.downloads, which has no
                // launcher icon, so the launcher query never lists it and its expand setting could not be changed.
                val dmPackage = "com.android.providers.downloads"
                if (apps.any { it.packageName == dmPackage }) {
                    apps
                } else {
                    val label = runCatching {
                        val pm = context.packageManager
                        pm.getApplicationLabel(pm.getApplicationInfo(dmPackage, 0)).toString()
                    }.getOrNull()?.takeIf { it.isNotBlank() } ?: "Download Manager"
                    (apps + LaunchableApp(packageName = dmPackage, label = label))
                        .sortedBy { it.label.lowercase() }
                }
            }
        }

        var cooldownAppQuery by rememberSaveable { mutableStateOf("") }
        val cooldownFilteredApps = remember(installedApps, cooldownAppQuery) {
            if (cooldownAppQuery.isBlank()) installedApps
            else installedApps.filter {
                it.label.contains(cooldownAppQuery, ignoreCase = true) ||
                    it.packageName.contains(cooldownAppQuery, ignoreCase = true)
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = stringResource(R.string.notification_cooldown_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = stringResource(R.string.notification_cooldown_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                ToggleRowItem(
                    searchKey = "np.enable_cooldown",
                    title = stringResource(R.string.toggle_enable_cooldown_title),
                    subtitle = stringResource(R.string.toggle_enable_cooldown_desc),
                    icon = Icons.Rounded.HourglassBottom,
                    checked = settings.enableNotificationCooldown,
                    onCheckedChange = { scope.launch { repository.setEnableNotificationCooldown(it) } }
                )

                AnimatedVisibility(
                    visible = settings.enableNotificationCooldown,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = stringResource(R.string.cooldown_duration_title, settings.notificationCooldownDurationMinutes),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(1, 2, 3, 5, 10, 15).forEach { min ->
                                    val isSelected = settings.notificationCooldownDurationMinutes == min
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            scope.launch { repository.setNotificationCooldownDurationMinutes(min) }
                                        },
                                        label = { Text("${min}m", fontSize = 12.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    )
                                }
                            }

                            SliderSettingItem(
                                label = stringResource(R.string.cooldown_duration_slider),
                                value = settings.notificationCooldownDurationMinutes.toFloat(),
                                range = 1f..30f,
                                step = 1f,
                                suffix = " min",
                                onValueChange = { newVal ->
                                    scope.launch { repository.setNotificationCooldownDurationMinutes(newVal.roundToInt()) }
                                }
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = stringResource(R.string.cooldown_threshold_title, settings.notificationCooldownThreshold),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(2, 3, 4, 5, 8, 10).forEach { count ->
                                    val isSelected = settings.notificationCooldownThreshold == count
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            scope.launch { repository.setNotificationCooldownThreshold(count) }
                                        },
                                        label = { Text("$count", fontSize = 12.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    )
                                }
                            }

                            SliderSettingItem(
                                label = stringResource(R.string.cooldown_threshold_slider),
                                value = settings.notificationCooldownThreshold.toFloat(),
                                range = 2f..10f,
                                step = 1f,
                                suffix = " alerts",
                                onValueChange = { newVal ->
                                    scope.launch { repository.setNotificationCooldownThreshold(newVal.roundToInt()) }
                                }
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                        // System events (battery, Wi-Fi, VPN, Bluetooth, flashlight): not apps, so they get their own list.
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = stringResource(R.string.cooldown_system_events_title),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(R.string.cooldown_system_events_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = stringResource(
                                        R.string.cooldown_system_events_count,
                                        settings.notificationCooldownSystemEvents.size
                                    ),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            val all = com.ultraisland.pro.util.NotificationCooldownManager.SYSTEM_EVENTS
                                                .map { it.id }.toSet()
                                            scope.launch { repository.setNotificationCooldownSystemEvents(all) }
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text(stringResource(R.string.btn_select_all_events), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    OutlinedButton(
                                        onClick = { scope.launch { repository.setNotificationCooldownSystemEvents(emptySet()) } },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text(stringResource(R.string.btn_clear_events), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                            com.ultraisland.pro.util.NotificationCooldownManager.SYSTEM_EVENTS.forEach { event ->
                                val inCooldown = event.id in settings.notificationCooldownSystemEvents
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = event.shortLabel,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = event.label,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    FilterChip(
                                        selected = inCooldown,
                                        onClick = {
                                            scope.launch { repository.toggleNotificationCooldownSystemEvent(event.id) }
                                        },
                                        label = {
                                            Text(
                                                text = if (inCooldown) stringResource(R.string.chip_cooldown_active) else stringResource(R.string.chip_always_alert),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = stringResource(R.string.cooldown_excluded_apps_title),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(R.string.cooldown_excluded_apps_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            OutlinedTextField(
                                value = cooldownAppQuery,
                                onValueChange = { cooldownAppQuery = it },
                                placeholder = { Text(stringResource(R.string.search_installed_apps)) },
                                leadingIcon = {
                                    Icon(Icons.Rounded.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                val excludedCount = settings.notificationCooldownExcludedPackages.size
                                Text(
                                    text = stringResource(R.string.cooldown_excluded_count, excludedCount),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            val targets = installedApps.map { it.packageName }.toSet()
                                            scope.launch {
                                                repository.setNotificationCooldownExcludedPackages(targets)
                                            }
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text(stringResource(R.string.btn_exclude_all), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            scope.launch {
                                                repository.setNotificationCooldownExcludedPackages(emptySet())
                                            }
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text(stringResource(R.string.btn_clear_exclusions), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }

                            val displayApps = if (cooldownAppQuery.isBlank()) cooldownFilteredApps.take(15) else cooldownFilteredApps
                            displayApps.forEach { app ->
                                val isExcluded = app.packageName in settings.notificationCooldownExcludedPackages

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = app.label,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = app.packageName,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    FilterChip(
                                        selected = isExcluded,
                                        onClick = {
                                            scope.launch {
                                                repository.toggleNotificationCooldownExcludedPackage(app.packageName)
                                            }
                                        },
                                        label = {
                                            Text(
                                                text = if (isExcluded) stringResource(R.string.chip_excluded) else stringResource(R.string.chip_cooldown_active),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        var showAppManagerDialog by rememberSaveable { mutableStateOf(false) }
        var selectedAppForOptions by rememberSaveable(stateSaver = LaunchableAppSaver) {
            mutableStateOf<LaunchableApp?>(null)
        }

        val customizedApps = remember(
            installedApps,
            settings.disabledNotificationPackages,
            settings.disabledSoundPackages,
            settings.notificationCooldownExcludedPackages,
            settings.noExpandPackages,
            settings.noAutoExpandPackages,
            settings.autoExpandPackages
        ) {
            installedApps.filter { app ->
                app.packageName in settings.disabledNotificationPackages ||
                    app.packageName in settings.disabledSoundPackages ||
                    app.packageName in settings.notificationCooldownExcludedPackages ||
                    app.packageName in settings.noExpandPackages ||
                    app.packageName in settings.noAutoExpandPackages ||
                    app.packageName in settings.autoExpandPackages
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.NotificationsActive,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.app_alerts_manager_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = stringResource(R.string.app_alerts_manager_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                val activeCount = installedApps.count { it.packageName !in settings.disabledNotificationPackages }
                val excludedCount = settings.disabledNotificationPackages.size
                val mutedCount = settings.disabledSoundPackages.size

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "$activeCount",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Active",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (excludedCount > 0) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f)
                               else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "$excludedCount",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (excludedCount > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Excluded",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (excludedCount > 0) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (mutedCount > 0) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)
                               else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "$mutedCount",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (mutedCount > 0) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Muted",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (mutedCount > 0) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                if (customizedApps.isNotEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.customized_apps_title, customizedApps.size),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        customizedApps.take(4).forEach { app ->
                            val isExcluded = app.packageName in settings.disabledNotificationPackages
                            val isMuted = app.packageName in settings.disabledSoundPackages
                            val isCooldownBypassed = app.packageName in settings.notificationCooldownExcludedPackages

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                                    .clickable { selectedAppForOptions = app }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                val icon = rememberAppIcon(app.packageName)
                                if (icon != null) {
                                    Image(
                                        bitmap = icon,
                                        contentDescription = app.label,
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = app.label.firstOrNull()?.uppercase() ?: "A",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = app.label,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (isExcluded) {
                                            Text(
                                                text = stringResource(R.string.tag_excluded_from_island),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.error,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                        if (isMuted) {
                                            Text(
                                                text = stringResource(R.string.tag_sound_muted),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.tertiary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                        if (isCooldownBypassed) {
                                            Text(
                                                text = stringResource(R.string.tag_cooldown_bypassed),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Rounded.Tune,
                                    contentDescription = "Configure",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        if (customizedApps.size > 4) {
                            Text(
                                text = "+${customizedApps.size - 4} more customized apps",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clickable { showAppManagerDialog = true }
                                    .padding(vertical = 2.dp)
                            )
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = stringResource(R.string.all_apps_enabled_note),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                FilledTonalButton(
                    onClick = { showAppManagerDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Tune,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.btn_manage_apps),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        if (showAppManagerDialog) {
            var query by rememberSaveable { mutableStateOf("") }
            var filterTab by rememberSaveable { mutableIntStateOf(0) } // 0: All, 1: Customized, 2: Excluded

            val filteredApps = remember(installedApps, query, filterTab, settings.disabledNotificationPackages, settings.disabledSoundPackages, settings.notificationCooldownExcludedPackages, settings.noExpandPackages, settings.noAutoExpandPackages, settings.autoExpandPackages) {
                installedApps.filter { app ->
                    val matchesQuery = query.isBlank() ||
                        app.label.contains(query, ignoreCase = true) ||
                        app.packageName.contains(query, ignoreCase = true)

                    val matchesTab = when (filterTab) {
                        1 -> app.packageName in settings.disabledNotificationPackages ||
                             app.packageName in settings.disabledSoundPackages ||
                             app.packageName in settings.notificationCooldownExcludedPackages ||
                             app.packageName in settings.noExpandPackages ||
                             app.packageName in settings.noAutoExpandPackages ||
                             app.packageName in settings.autoExpandPackages
                        2 -> app.packageName in settings.disabledNotificationPackages
                        else -> true
                    }

                    matchesQuery && matchesTab
                }
            }

            AlertDialog(
                onDismissRequest = { showAppManagerDialog = false },
                icon = {
                    Icon(
                        imageVector = Icons.Rounded.NotificationsActive,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                },
                title = {
                    Text(
                        text = stringResource(R.string.app_alerts_manager_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            placeholder = { Text(stringResource(R.string.search_installed_apps)) },
                            leadingIcon = {
                                Icon(Icons.Rounded.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            },
                            trailingIcon = {
                                if (query.isNotEmpty()) {
                                    IconButton(onClick = { query = "" }) {
                                        Icon(Icons.Rounded.Close, contentDescription = "Clear search", modifier = Modifier.size(18.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = filterTab == 0,
                                onClick = { filterTab = 0 },
                                label = { Text(stringResource(R.string.filter_tab_all, installedApps.size), fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                            FilterChip(
                                selected = filterTab == 1,
                                onClick = { filterTab = 1 },
                                label = { Text(stringResource(R.string.filter_tab_customized, customizedApps.size), fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                            FilterChip(
                                selected = filterTab == 2,
                                onClick = { filterTab = 2 },
                                label = { Text(stringResource(R.string.filter_tab_excluded, settings.disabledNotificationPackages.size), fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${filteredApps.size} apps",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        val targets = filteredApps.map { it.packageName }.toSet()
                                        scope.launch {
                                            repository.setDisabledNotificationPackages(settings.disabledNotificationPackages - targets)
                                        }
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text(stringResource(R.string.btn_select_all), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        val targets = filteredApps.map { it.packageName }.toSet()
                                        scope.launch {
                                            repository.setDisabledNotificationPackages(settings.disabledNotificationPackages + targets)
                                        }
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text(stringResource(R.string.btn_deselect_all), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                        if (filteredApps.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (query.isBlank()) stringResource(R.string.no_installed_apps_found)
                                           else stringResource(R.string.no_apps_matching_query, query),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 380.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(filteredApps, key = { it.packageName }) { app ->
                                    val isNotificationEnabled = app.packageName !in settings.disabledNotificationPackages
                                    val isSoundMuted = app.packageName in settings.disabledSoundPackages

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable { selectedAppForOptions = app }
                                            .padding(vertical = 6.dp, horizontal = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            val icon = rememberAppIcon(app.packageName)
                                            if (icon != null) {
                                                Image(
                                                    bitmap = icon,
                                                    contentDescription = app.label,
                                                    modifier = Modifier
                                                        .size(34.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                )
                                            } else {
                                                Box(
                                                    modifier = Modifier
                                                        .size(34.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = app.label.firstOrNull()?.uppercase() ?: "A",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }

                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = app.label,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.SemiBold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Row(
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    if (!isNotificationEnabled) {
                                                        Text(
                                                            text = stringResource(R.string.tag_excluded_from_island),
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.error,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    } else {
                                                        Text(
                                                            text = if (isSoundMuted) "Active • Muted" else "Active",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = if (isSoundMuted) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Switch(
                                                checked = isNotificationEnabled,
                                                onCheckedChange = { enabled ->
                                                    val updated = if (enabled) {
                                                        settings.disabledNotificationPackages - app.packageName
                                                    } else {
                                                        settings.disabledNotificationPackages + app.packageName
                                                    }
                                                    scope.launch { repository.setDisabledNotificationPackages(updated) }
                                                }
                                            )

                                            IconButton(
                                                onClick = { selectedAppForOptions = app },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.Tune,
                                                    contentDescription = "Options",
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showAppManagerDialog = false }) {
                        Text("Done", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        selectedAppForOptions?.let { app ->
            val isNotificationEnabled = app.packageName !in settings.disabledNotificationPackages
            val isSoundEnabled = app.packageName !in settings.disabledSoundPackages
            val isCooldownBypassed = app.packageName in settings.notificationCooldownExcludedPackages
            val mayExpandCard = app.packageName !in settings.noExpandPackages
            val autoExpandChoice = AppEventRules.autoExpandChoice(
                settings.noAutoExpandPackages, settings.autoExpandPackages, app.packageName
            )

            AlertDialog(
                onDismissRequest = { selectedAppForOptions = null },
                icon = {
                    val icon = rememberAppIcon(app.packageName)
                    if (icon != null) {
                        Image(
                            bitmap = icon,
                            contentDescription = app.label,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = app.label.firstOrNull()?.uppercase() ?: "A",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                title = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = stringResource(R.string.app_options_title, app.label),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = app.packageName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ToggleRowItem(
                            title = stringResource(R.string.option_island_notifications),
                            subtitle = if (isNotificationEnabled)
                                stringResource(R.string.option_island_notifications_desc)
                            else
                                stringResource(R.string.tag_excluded_from_island),
                            icon = if (isNotificationEnabled) Icons.Rounded.NotificationsActive else Icons.Rounded.NotificationsOff,
                            iconColor = if (isNotificationEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            checked = isNotificationEnabled,
                            onCheckedChange = { enabled ->
                                val updated = if (enabled) {
                                    settings.disabledNotificationPackages - app.packageName
                                } else {
                                    settings.disabledNotificationPackages + app.packageName
                                }
                                scope.launch { repository.setDisabledNotificationPackages(updated) }
                            }
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                        ToggleRowItem(
                            title = stringResource(R.string.option_island_sound),
                            subtitle = if (isSoundEnabled)
                                stringResource(R.string.option_island_sound_desc)
                            else
                                stringResource(R.string.tag_sound_muted),
                            icon = if (isSoundEnabled) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                            checked = isSoundEnabled && isNotificationEnabled,
                            onCheckedChange = { enabled ->
                                val updated = if (enabled) {
                                    settings.disabledSoundPackages - app.packageName
                                } else {
                                    settings.disabledSoundPackages + app.packageName
                                }
                                scope.launch { repository.setDisabledSoundPackages(updated) }
                            }
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                        ToggleRowItem(
                            title = stringResource(R.string.option_expanded_card),
                            subtitle = if (mayExpandCard)
                                stringResource(R.string.option_expanded_card_desc)
                            else
                                stringResource(R.string.tag_card_never_expands),
                            icon = Icons.Rounded.OpenInFull,
                            checked = mayExpandCard && isNotificationEnabled,
                            onCheckedChange = { enabled ->
                                val updated = if (enabled) {
                                    settings.noExpandPackages - app.packageName
                                } else {
                                    settings.noExpandPackages + app.packageName
                                }
                                scope.launch { repository.setNoExpandPackages(updated) }
                            }
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                        // Auto-expand: Loud only is the default for every app; Always also opens silent ones; Never beats loud.
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.NotificationsActive,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = stringResource(R.string.option_auto_expand),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = when {
                                            !(mayExpandCard && isNotificationEnabled) -> stringResource(R.string.tag_card_never_expands)
                                            autoExpandChoice == AppAutoExpand.NEVER -> stringResource(R.string.tag_no_auto_expand)
                                            autoExpandChoice == AppAutoExpand.ALWAYS -> stringResource(R.string.option_auto_expand_always_desc)
                                            else -> stringResource(R.string.option_auto_expand_desc)
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(
                                    AppAutoExpand.DEFAULT to R.string.auto_expand_choice_default,
                                    AppAutoExpand.ALWAYS to R.string.auto_expand_choice_always,
                                    AppAutoExpand.NEVER to R.string.auto_expand_choice_never
                                ).forEach { (choice, label) ->
                                    PrivacySegmentButton(
                                        label = stringResource(label),
                                        selected = autoExpandChoice == choice,
                                        onClick = { scope.launch { repository.setAppAutoExpand(app.packageName, choice) } },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                        ToggleRowItem(
                            title = stringResource(R.string.option_hide_on_lock_screen),
                            subtitle = stringResource(R.string.option_hide_on_lock_screen_desc),
                            icon = Icons.Rounded.VisibilityOff,
                            checked = app.packageName in settings.hideOnLockScreenPackages,
                            onCheckedChange = { scope.launch { repository.setAppHiddenOnLockScreen(app.packageName, it) } }
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

                        ToggleRowItem(
                            title = stringResource(R.string.option_cooldown_bypass),
                            subtitle = stringResource(R.string.option_cooldown_bypass_desc),
                            icon = Icons.Rounded.HourglassBottom,
                            checked = isCooldownBypassed,
                            onCheckedChange = {
                                scope.launch {
                                    repository.toggleNotificationCooldownExcludedPackage(app.packageName)
                                }
                            }
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = { selectedAppForOptions = null }) {
                        Text("Done", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            scope.launch {
                                repository.setDisabledNotificationPackages(settings.disabledNotificationPackages - app.packageName)
                                repository.setDisabledSoundPackages(settings.disabledSoundPackages - app.packageName)
                                repository.setNotificationCooldownExcludedPackages(settings.notificationCooldownExcludedPackages - app.packageName)
                                repository.setNoExpandPackages(settings.noExpandPackages - app.packageName)
                                repository.setAppAutoExpand(app.packageName, AppAutoExpand.DEFAULT)
                                repository.setAppHiddenOnLockScreen(app.packageName, false)
                            }
                        }
                    ) {
                        Text(
                            stringResource(R.string.btn_reset_default),
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            )
        }
    }
}

@Composable
private fun ToggleRowItem(
    searchKey: String? = null,
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    iconColor: Color = MaterialTheme.colorScheme.primary,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .searchAnchor(searchKey)
            .clip(RoundedCornerShape(8.dp))
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (checked) iconColor.copy(alpha = 0.14f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (checked) iconColor else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.size(18.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 14.sp
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}

@Composable
private fun PrivacySegmentButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            .border(0.5.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .bounceClick(onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

private object AppIconCache {
    private val cache = LruCache<String, ImageBitmap>(150)
    fun get(pkg: String): ImageBitmap? = cache.get(pkg)
    fun put(pkg: String, bmp: ImageBitmap) { cache.put(pkg, bmp) }
}

@Composable
private fun rememberAppIcon(packageName: String): ImageBitmap? {
    val context = LocalContext.current
    var iconBitmap by remember(packageName) { mutableStateOf(AppIconCache.get(packageName)) }

    LaunchedEffect(packageName) {
        if (iconBitmap == null) {
            val loaded = withContext(Dispatchers.IO) {
                runCatching {
                    val drawable = context.packageManager.getApplicationIcon(packageName)
                    val bmp = drawable.toBitmap(width = 72, height = 72)
                    bmp.asImageBitmap()
                }.getOrNull()
            }
            if (loaded != null) {
                AppIconCache.put(packageName, loaded)
                iconBitmap = loaded
            }
        }
    }
    return iconBitmap
}

private val LaunchableAppSaver: Saver<LaunchableApp?, Any> = listSaver(
    save = { app -> if (app == null) emptyList<Any>() else listOf(app.packageName, app.label) },
    restore = { saved ->
        if (saved.size < 2) null else LaunchableApp(saved[0] as String, saved[1] as String)
    }
)

@Composable
private fun LockScreenEventList(
    settings: UltraIslandSettings,
    repository: UltraIslandSettingsRepository
) {
    val scope = rememberCoroutineScope()
    var open by rememberSaveable { mutableStateOf(false) }
    val events = com.ultraisland.pro.model.IslandEvent.entries.filter { it.canHideOnLockScreen }
    val hiddenCount = events.count { it.id in settings.hideOnLockScreenEvents }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .searchAnchor("np.hide_events_lock_screen")
                .clip(RoundedCornerShape(8.dp))
                .clickable { open = !open }
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.lock_screen_per_event_title),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = stringResource(R.string.lock_screen_per_event_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = "$hiddenCount / ${events.size}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (open) {
            events.forEach { event ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = event.label,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = event.id in settings.hideOnLockScreenEvents,
                        onCheckedChange = { hide ->
                            scope.launch { repository.setEventHiddenOnLockScreen(event.id, hide) }
                        }
                    )
                }
            }
        }
    }
}
