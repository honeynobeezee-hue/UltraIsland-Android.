/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.ultraisland.pro.di

import android.content.Context
import com.ultraisland.pro.data.INotificationHistoryRepository
import com.ultraisland.pro.data.INotificationRepository
import com.ultraisland.pro.data.UltraIslandSettingsRepository
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent

@EntryPoint
@InstallIn(SingletonComponent::class)
interface UltraIslandRepositoriesEntryPoint {
    fun settingsRepository(): UltraIslandSettingsRepository
    fun notificationRepository(): INotificationRepository
    fun notificationHistoryRepository(): INotificationHistoryRepository
}

object UltraIslandRepositories {
    fun settingsRepository(context: Context): UltraIslandSettingsRepository =
        entryPoint(context).settingsRepository()

    fun notificationRepository(context: Context): INotificationRepository =
        entryPoint(context).notificationRepository()

    fun historyRepository(context: Context): INotificationHistoryRepository =
        entryPoint(context).notificationHistoryRepository()

    private fun entryPoint(context: Context): UltraIslandRepositoriesEntryPoint =
        EntryPointAccessors.fromApplication(
            context.applicationContext,
            UltraIslandRepositoriesEntryPoint::class.java
        )
}
