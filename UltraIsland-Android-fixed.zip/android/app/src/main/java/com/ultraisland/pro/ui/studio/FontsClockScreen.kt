package com.ultraisland.pro.ui.studio

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.R
import com.ultraisland.pro.core.datastore.FontOption
import com.ultraisland.pro.core.datastore.IslandSettingsState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FontsClockScreen(
    settings: IslandSettingsState,
    onUpdate: ((IslandSettingsState) -> IslandSettingsState) -> Unit,
    onPickCustomFont: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.fonts_clock_title),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = stringResource(R.string.fonts_clock_subtitle),
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF090A0D))
            )
        },
        containerColor = Color(0xFF090A0D)
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Preview Island
            item {
                Spacer(modifier = Modifier.height(4.dp))
                StudioLivePreview(settings = settings)
            }

            // Section 1: Typography Options
            item {
                StudioSectionCard(
                    title = stringResource(R.string.font_family_title),
                    subtitle = "Select typography for live activities, countdowns and clocks"
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioChip(
                            label = "System Default",
                            isSelected = settings.fontOption == FontOption.SYSTEM,
                            onClick = { onUpdate { s -> s.copy(fontOption = FontOption.SYSTEM) } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "5x7 Dot LED",
                            isSelected = settings.fontOption == FontOption.LED_DOT_5X7,
                            onClick = { onUpdate { s -> s.copy(fontOption = FontOption.LED_DOT_5X7) } },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioChip(
                            label = "Monospace",
                            isSelected = settings.fontOption == FontOption.MONOSPACE,
                            onClick = { onUpdate { s -> s.copy(fontOption = FontOption.MONOSPACE) } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Serif",
                            isSelected = settings.fontOption == FontOption.SERIF,
                            onClick = { onUpdate { s -> s.copy(fontOption = FontOption.SERIF) } },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = onPickCustomFont,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f))
                    ) {
                        Text(
                            text = if (settings.customFontUri != null) "Custom Font Loaded ✓ (Change)" else stringResource(R.string.add_custom_font_title),
                            fontSize = 12.sp,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    StudioToggle(
                        title = stringResource(R.string.mix_fonts_title),
                        subtitle = stringResource(R.string.mix_fonts_desc),
                        checked = settings.mixFonts,
                        onCheckedChange = { onUpdate { s -> s.copy(mixFonts = it) } }
                    )
                }
            }

            // Section 2: Clock & Time Formats
            item {
                StudioSectionCard(
                    title = "Clock & Hour Markers",
                    subtitle = "Format time representation in compact and idle pills"
                ) {
                    StudioToggle(
                        title = stringResource(R.string.hour_tick_title),
                        subtitle = stringResource(R.string.hour_tick_desc),
                        checked = settings.showHourTick,
                        onCheckedChange = { onUpdate { s -> s.copy(showHourTick = it) } }
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = stringResource(R.string.clock_style_title),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioChip(
                            label = "24h (14:30)",
                            isSelected = settings.clockFormatStyle == "HH:mm",
                            onClick = { onUpdate { s -> s.copy(clockFormatStyle = "HH:mm") } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "12h (2:30 PM)",
                            isSelected = settings.clockFormatStyle == "hh:mm a",
                            onClick = { onUpdate { s -> s.copy(clockFormatStyle = "hh:mm a") } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Secs (14:30:15)",
                            isSelected = settings.clockFormatStyle == "HH:mm:ss",
                            onClick = { onUpdate { s -> s.copy(clockFormatStyle = "HH:mm:ss") } },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Section 3: Weather & Units
            item {
                StudioSectionCard(
                    title = "Units & Formatting",
                    subtitle = "Weather temperature scales, wind speed & battery style"
                ) {
                    StudioToggle(
                        title = "Celsius Temperature Scale",
                        subtitle = "Display idle weather widget in °C instead of °F",
                        checked = settings.weatherUnitCelsius,
                        onCheckedChange = { onUpdate { s -> s.copy(weatherUnitCelsius = it) } }
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = stringResource(R.string.wind_unit_title),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioChip(
                            label = "km/h",
                            isSelected = settings.windSpeedUnit == "km/h",
                            onClick = { onUpdate { s -> s.copy(windSpeedUnit = "km/h") } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "mph",
                            isSelected = settings.windSpeedUnit == "mph",
                            onClick = { onUpdate { s -> s.copy(windSpeedUnit = "mph") } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "m/s",
                            isSelected = settings.windSpeedUnit == "m/s",
                            onClick = { onUpdate { s -> s.copy(windSpeedUnit = "m/s") } },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = stringResource(R.string.battery_style_title),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioChip(
                            label = "Percent + Icon",
                            isSelected = settings.batteryStyle == "PERCENT_ICON",
                            onClick = { onUpdate { s -> s.copy(batteryStyle = "PERCENT_ICON") } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Icon Only",
                            isSelected = settings.batteryStyle == "BARS_ONLY",
                            onClick = { onUpdate { s -> s.copy(batteryStyle = "BARS_ONLY") } },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }
}
