package com.ultraisland.pro.core.common

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LogEntry(
    val timestamp: Long,
    val level: String,
    val tag: String,
    val message: String
) {
    fun format(): String {
        val sdf = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
        return "${sdf.format(Date(timestamp))} [$level/$tag] $message"
    }
}

object Logger {
    private var maxCapacity = 500
    private val buffer = ArrayDeque<LogEntry>()
    private val _logsFlow = MutableStateFlow<List<LogEntry>>(emptyList())
    val logsFlow: StateFlow<List<LogEntry>> = _logsFlow.asStateFlow()

    fun init(maxEntries: Int = 500) {
        maxCapacity = maxEntries
    }

    @Synchronized
    private fun append(level: String, tag: String, message: String) {
        val entry = LogEntry(System.currentTimeMillis(), level, tag, message)
        if (buffer.size >= maxCapacity) {
            buffer.removeFirst()
        }
        buffer.addLast(entry)
        _logsFlow.value = buffer.toList()
    }

    fun d(tag: String, message: String) {
        Log.d(tag, message)
        append("DEBUG", tag, message)
    }

    fun i(tag: String, message: String) {
        Log.i(tag, message)
        append("INFO", tag, message)
    }

    fun w(tag: String, message: String, tr: Throwable? = null) {
        val msg = if (tr != null) "$message: ${tr.message}" else message
        Log.w(tag, msg, tr)
        append("WARN", tag, msg)
    }

    fun e(tag: String, message: String, tr: Throwable? = null) {
        val msg = if (tr != null) "$message\n${Log.getStackTraceString(tr)}" else message
        Log.e(tag, msg, tr)
        append("ERROR", tag, msg)
    }

    fun exportPlainText(): String {
        return buffer.joinToString("\n") { it.format() }
    }

    fun clear() {
        buffer.clear()
        _logsFlow.value = emptyList()
    }
}
