package com.ultraisland.pro.services.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.res.Configuration
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.ultraisland.pro.engine.overlay.IslandOverlayManager

class IslandAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        isSystemConnected = true
        Log.i(TAG, "Accessibility service connected")
        IslandOverlayManager.attach(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Event handling for window state
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted")
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        Log.d(TAG, "Configuration changed: orientation=${newConfig.orientation}")
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        isSystemConnected = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        isSystemConnected = false
        IslandOverlayManager.detach()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "IslandAccessibility"

        /** True selama sistem Android menghubungkan service ini (dipakai SystemServiceRecovery). */
        @Volatile var isSystemConnected: Boolean = false
            private set
    }
}
