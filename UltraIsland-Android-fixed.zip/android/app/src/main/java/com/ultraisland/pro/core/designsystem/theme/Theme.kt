package com.ultraisland.pro.core.designsystem.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

val NoirBackground = Color(0xFF000000)
val NoirSurface = Color(0xFF101216)
val NoirCard = Color(0xFF181B20)
val IslandPureBlack = Color(0xFF000000)
val ElectricBlue = Color(0xFF388AF6)
val EmeraldGreen = Color(0xFF34C759)
val AmberGlow = Color(0xFFFF9500)
val CrimsonAlert = Color(0xFFFF3B30)

private val DarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1A3B66),
    onPrimaryContainer = Color(0xFFD6E4FF),
    background = NoirBackground,
    surface = NoirSurface,
    surfaceVariant = NoirCard,
    onBackground = Color(0xFFEDEDED),
    onSurface = Color(0xFFF2F2F2),
    outline = Color(0xFF2E333D)
)

private val LightColorScheme = lightColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    background = Color(0xFFF6F7F9),
    surface = Color.White,
    surfaceVariant = Color(0xFFEBEFF5),
    onBackground = Color(0xFF121417),
    onSurface = Color(0xFF181B20),
    outline = Color(0xFFD0D5DD)
)

@Composable
fun UltraIslandTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> DarkColorScheme // UltraIsland defaults to sleek dark mode
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
