package com.ultraisland.pro.ui.diagnostics

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.privileged.PrivilegedBackend
import com.ultraisland.pro.privileged.PrivilegedBridgeManager
import com.ultraisland.pro.privileged.PrivilegedCommandRegistry
import com.ultraisland.pro.privileged.SystemSettingsRestorer
import com.ultraisland.pro.privileged.wireless.AdbWirelessManager
import com.ultraisland.pro.privileged.wireless.AdbWirelessState
import kotlinx.coroutines.launch

@Composable
fun PrivilegedDiagnosticsScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val activeBridge = PrivilegedBridgeManager.getActiveBridge()
    val isShizukuDead by PrivilegedBridgeManager.isShizukuDead.collectAsState()
    val wirelessState by AdbWirelessManager.connectionState.collectAsState()
    val changelog by SystemSettingsRestorer.getChangelog(context).collectAsState(initial = emptyList())

    var pairingPortText by remember { mutableStateOf("") }
    var pairingCodeText by remember { mutableStateOf("") }
    var testLog by remember { mutableStateOf<String?>(null) }
    var isPairingLoading by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }

    val pcCommands = listOf(
        "adb shell pm grant com.ultraisland.pro android.permission.WRITE_SECURE_SETTINGS",
        "adb shell pm grant com.ultraisland.pro android.permission.DUMP",
        "adb shell dumpsys deviceidle whitelist +com.ultraisland.pro",
        "adb shell appops set com.ultraisland.pro RUN_ANY_IN_BACKGROUND allow",
        "adb shell appops set com.ultraisland.pro RECEIVE_SENSITIVE_NOTIFICATIONS allow"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090A0D))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Column(modifier = Modifier.padding(start = 4.dp)) {
                    Text("Diagnostics & Privileged", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Shizuku v13, Local Wireless ADB & System Safety", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
                }
            }
        }

        // Active Backend Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Active Backend", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Box(
                            modifier = Modifier
                                .background(
                                    if (activeBridge.hasPermission) Color(0xFF34C759).copy(alpha = 0.15f)
                                    else Color(0xFFFF9500).copy(alpha = 0.15f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                if (activeBridge.hasPermission) "CONNECTED" else "STANDBY",
                                color = if (activeBridge.hasPermission) Color(0xFF34C759) else Color(0xFFFF9500),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        activeBridge.backend.displayName,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF388AF6)
                    )
                    Text(
                        "Shell UID: ${if (activeBridge.hasPermission) activeBridge.shellUid else "N/A (Non-privileged)"}",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                }
            }
        }

        // Shizuku Reboot/Died Alert Card
        if (isShizukuDead || (!activeBridge.hasPermission && activeBridge.backend == PrivilegedBackend.SHIZUKU)) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B1B17)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFF9500), modifier = Modifier.size(20.dp))
                            Text(
                                " Shizuku Service Inactive or Rebooted",
                                color = Color(0xFFFF9500),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Device rebooted or Shizuku server was closed. Launch Shizuku to start it, or connect via on-device ADB Wireless below.",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val launchIntent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                                if (launchIntent != null) {
                                    context.startActivity(launchIntent)
                                } else {
                                    Toast.makeText(context, "Shizuku app not found", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9500))
                        ) {
                            Text("Start Shizuku App", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // On-device ADB Wireless Pairing Wizard Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Wifi, contentDescription = null, tint = Color(0xFF388AF6))
                        Text(" ADB Wireless On-Device Pairing", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    Text("No PC required. Pair directly via Android 11+ Developer Options.", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("1. Open Developer Options > Wireless Debugging", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                    Text("2. Tap 'Pair device with pairing code' in split-screen", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                    Text("3. Enter the 5-digit Pairing Port & 6-digit Wi-Fi code below", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = pairingPortText,
                            onValueChange = { pairingPortText = it },
                            label = { Text("Port (e.g. 37849)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF388AF6),
                                unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        OutlinedTextField(
                            value = pairingCodeText,
                            onValueChange = { pairingCodeText = it },
                            label = { Text("6-digit Code", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF388AF6),
                                unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val port = pairingPortText.toIntOrNull()
                            if (port == null || pairingCodeText.length < 6) {
                                Toast.makeText(context, "Please enter valid 5-digit port and 6-digit code", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isPairingLoading = true
                            scope.launch {
                                val res = AdbWirelessManager.pairAndConnect(port, pairingCodeText)
                                isPairingLoading = false
                                if (res.isSuccess) {
                                    Toast.makeText(context, "Connected to local adbd!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Pairing failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388AF6))
                    ) {
                        Text(if (isPairingLoading) "Pairing & Connecting..." else "Pair & Connect Local ADB")
                    }

                    when (wirelessState) {
                        is AdbWirelessState.Connected -> {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("✓ Local Wireless ADB Connected on 127.0.0.1", color = Color(0xFF34C759), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        is AdbWirelessState.Error -> {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("✗ ${(wirelessState as AdbWirelessState.Error).message}", color = Color(0xFFFF3B30), fontSize = 12.sp)
                        }
                        else -> {}
                    }
                }
            }
        }

        // Capability Test Matrix Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Privileged Capabilities Test", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Execute whitelisted actions to verify shell integration", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                scope.launch {
                                    val cmds = PrivilegedCommandRegistry.cmdAntiKill(context.packageName)
                                    val sb = StringBuilder()
                                    for (c in cmds) {
                                        val res = PrivilegedBridgeManager.exec(c)
                                        sb.append(if (res.isSuccess) "✓ " else "✗ ").append(c).append("\n")
                                    }
                                    testLog = sb.toString()
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF242936)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Anti-Kill", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                scope.launch {
                                    val res = PrivilegedBridgeManager.exec(PrivilegedCommandRegistry.CMD_SCREENSHOT)
                                    testLog = if (res.isSuccess) "✓ Screenshot captured via shell" else "✗ Screenshot failed: ${res.exceptionOrNull()?.message}"
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF242936)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Screenshot", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                scope.launch {
                                    val res = PrivilegedBridgeManager.exec(PrivilegedCommandRegistry.CMD_WIFI_ENABLE)
                                    testLog = if (res.isSuccess) "✓ Wi-Fi verified active" else "✗ Wi-Fi exec failed: ${res.exceptionOrNull()?.message}"
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF242936)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Test Wi-Fi", fontSize = 11.sp)
                        }
                    }

                    if (testLog != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(testLog!!, color = Color(0xFF34C759), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
            }
        }

        // System Settings Changelog & Restore Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("System Settings Safety", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("${changelog.size} modified", color = Color(0xFF388AF6), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("All altered Secure/Global settings are tracked with rollback safety", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)

                    if (changelog.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        changelog.forEach { rec ->
                            Text(
                                "• ${rec.namespace}:${rec.key} = ${rec.currentValue} (orig: ${rec.originalValue ?: "default"})",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = { showRestoreDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE0245E))
                    ) {
                        Text("Restore All System Settings")
                    }
                }
            }
        }

        // PC ADB Fallback Copy Block
        item {
            Text("One-Time PC ADB Setup Commands", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
        }

        items(pcCommands) { cmd ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101217)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = cmd,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                    )
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("ADB Command", cmd))
                            Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF242936))
                    ) {
                        Text("Copy", fontSize = 11.sp)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }

    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("Restore Modified Settings?") },
            text = { Text("This will revert all Global/Secure settings altered by UltraIsland (Heads-up, Daltonizer, Private DNS, Stay On) back to their original recorded values.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showRestoreDialog = false
                        scope.launch {
                            val res = SystemSettingsRestorer.restoreAll(context, activeBridge)
                            if (res.isSuccess) {
                                Toast.makeText(context, "Restored ${res.getOrNull()} settings successfully", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Restore failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                ) {
                    Text("Restore Now", color = Color(0xFFE0245E))
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
