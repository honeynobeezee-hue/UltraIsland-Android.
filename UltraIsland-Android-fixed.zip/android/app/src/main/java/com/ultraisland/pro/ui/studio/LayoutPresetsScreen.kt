package com.ultraisland.pro.ui.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.R
import com.ultraisland.pro.core.datastore.CustomPreset
import com.ultraisland.pro.core.datastore.IslandSettingsState
import com.ultraisland.pro.core.datastore.MergeStyle
import com.ultraisland.pro.core.datastore.SettingsRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LayoutPresetsScreen(
    settings: IslandSettingsState,
    onUpdate: ((IslandSettingsState) -> IslandSettingsState) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var newPresetName by remember { mutableStateOf("") }
    val customPresets = remember(settings.customPresetsJson) {
        SettingsRepository.parseCustomPresets(settings.customPresetsJson)
    }

    val builtinPresets = listOf(
        "iPhone 15 Pro",
        "iPhone 16 Pro",
        "Center Hole",
        "Wide Island",
        "Nothing-style",
        "Minimal"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.layout_title),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = stringResource(R.string.layout_subtitle),
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF090A0D))
            )
        },
        containerColor = Color(0xFF090A0D)
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Preview Island
            item {
                Spacer(modifier = Modifier.height(4.dp))
                StudioLivePreview(settings = settings)
            }

            // Section 1: Cutout Calibration Sliders
            item {
                StudioSectionCard(
                    title = "Cutout Calibration",
                    subtitle = "Align island bounds exactly with hardware camera punch hole"
                ) {
                    StudioSlider(
                        title = stringResource(R.string.cutout_width_title),
                        value = settings.widthDp.toFloat(),
                        range = 60f..240f,
                        unit = "dp",
                        decimalPlaces = 0,
                        onValueChange = { onUpdate { s -> s.copy(widthDp = it.toInt()) } }
                    )

                    StudioSlider(
                        title = stringResource(R.string.cutout_height_title),
                        value = settings.heightDp.toFloat(),
                        range = 20f..60f,
                        unit = "dp",
                        decimalPlaces = 0,
                        onValueChange = { onUpdate { s -> s.copy(heightDp = it.toInt()) } }
                    )

                    StudioSlider(
                        title = stringResource(R.string.offset_x_title),
                        value = settings.offsetX.toFloat(),
                        range = -150f..150f,
                        unit = "dp",
                        decimalPlaces = 0,
                        onValueChange = { onUpdate { s -> s.copy(offsetX = it.toInt()) } }
                    )

                    StudioSlider(
                        title = stringResource(R.string.offset_y_title),
                        value = settings.offsetY.toFloat(),
                        range = 0f..60f,
                        unit = "dp",
                        decimalPlaces = 0,
                        onValueChange = { onUpdate { s -> s.copy(offsetY = it.toInt()) } }
                    )

                    StudioSlider(
                        title = stringResource(R.string.corner_radius_title),
                        value = settings.cornerRadius.toFloat(),
                        range = 10f..40f,
                        unit = "dp",
                        decimalPlaces = 0,
                        onValueChange = { onUpdate { s -> s.copy(cornerRadius = it.toInt()) } }
                    )

                    StudioSlider(
                        title = stringResource(R.string.collapsed_width_title),
                        value = settings.collapsedCutoutWidthWithContent.toFloat(),
                        range = 120f..260f,
                        unit = "dp",
                        decimalPlaces = 0,
                        onValueChange = { onUpdate { s -> s.copy(collapsedCutoutWidthWithContent = it.toInt()) } }
                    )
                }
            }

            // Section 2: Merge Style
            item {
                StudioSectionCard(
                    title = stringResource(R.string.merge_style_title),
                    subtitle = "Define how the island anchors to or surrounds the camera"
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioChip(
                            label = "Merge",
                            isSelected = settings.mergeStyle == MergeStyle.MERGE,
                            onClick = { onUpdate { s -> s.copy(mergeStyle = MergeStyle.MERGE) } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Separate",
                            isSelected = settings.mergeStyle == MergeStyle.SEPARATE,
                            onClick = { onUpdate { s -> s.copy(mergeStyle = MergeStyle.SEPARATE) } },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StudioChip(
                            label = "Wide Island",
                            isSelected = settings.mergeStyle == MergeStyle.WIDE,
                            onClick = { onUpdate { s -> s.copy(mergeStyle = MergeStyle.WIDE) } },
                            modifier = Modifier.weight(1f)
                        )
                        StudioChip(
                            label = "Center Hole",
                            isSelected = settings.mergeStyle == MergeStyle.CENTER_HOLE,
                            onClick = { onUpdate { s -> s.copy(mergeStyle = MergeStyle.CENTER_HOLE) } },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Section 3: Alternate by Orientation
            item {
                StudioSectionCard(
                    title = stringResource(R.string.alternate_orientation_title),
                    subtitle = stringResource(R.string.alternate_orientation_desc)
                ) {
                    StudioToggle(
                        title = "Enable Alternate Landscape Layout",
                        subtitle = "Maintain separate geometry calibration when phone rotates",
                        checked = settings.alternateByOrientation,
                        onCheckedChange = { onUpdate { s -> s.copy(alternateByOrientation = it) } }
                    )

                    if (settings.alternateByOrientation) {
                        Spacer(modifier = Modifier.height(8.dp))
                        StudioSlider(
                            title = stringResource(R.string.landscape_cutout_width),
                            value = settings.landscapeCutoutWidth.toFloat(),
                            range = 70f..260f,
                            unit = "dp",
                            decimalPlaces = 0,
                            onValueChange = { onUpdate { s -> s.copy(landscapeCutoutWidth = it.toInt()) } }
                        )

                        StudioSlider(
                            title = stringResource(R.string.landscape_cutout_height),
                            value = settings.landscapeCutoutHeight.toFloat(),
                            range = 20f..50f,
                            unit = "dp",
                            decimalPlaces = 0,
                            onValueChange = { onUpdate { s -> s.copy(landscapeCutoutHeight = it.toInt()) } }
                        )

                        StudioSlider(
                            title = stringResource(R.string.landscape_top_y),
                            value = settings.landscapeTopYOffset.toFloat(),
                            range = 0f..40f,
                            unit = "dp",
                            decimalPlaces = 0,
                            onValueChange = { onUpdate { s -> s.copy(landscapeTopYOffset = it.toInt()) } }
                        )
                    }
                }
            }

            // Section 4: Built-in Presets
            item {
                StudioSectionCard(
                    title = stringResource(R.string.builtin_presets_title),
                    subtitle = "One-tap presets matching popular flagships and styles"
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        builtinPresets.chunked(2).forEach { rowPresets ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rowPresets.forEach { presetName ->
                                    StudioChip(
                                        label = presetName,
                                        isSelected = settings.activePresetName == presetName,
                                        onClick = {
                                            scope.launch {
                                                SettingsRepository.applyBuiltinPreset(presetName)
                                            }
                                        },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Section 5: Custom Saved Presets
            item {
                StudioSectionCard(
                    title = stringResource(R.string.custom_presets_title),
                    subtitle = "Save current calibration to apply or restore at any time"
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newPresetName,
                            onValueChange = { newPresetName = it },
                            placeholder = {
                                Text(
                                    stringResource(R.string.preset_name_hint),
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.5f)
                                )
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF388AF6),
                                unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                                focusedContainerColor = Color(0xFF0F1117),
                                unfocusedContainerColor = Color(0xFF0F1117),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.width(10.dp))

                        Button(
                            onClick = {
                                if (newPresetName.isNotBlank()) {
                                    val name = newPresetName.trim()
                                    scope.launch {
                                        SettingsRepository.saveCustomPreset(name)
                                        newPresetName = ""
                                    }
                                }
                            },
                            enabled = newPresetName.isNotBlank(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388AF6))
                        ) {
                            Text("Save", fontSize = 12.sp)
                        }
                    }

                    if (customPresets.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            customPresets.forEach { preset ->
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1117)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = preset.name,
                                                color = Color.White,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = "${preset.cutoutWidth}x${preset.cutoutHeight} dp • ${preset.mergeStyle.name}",
                                                color = Color.White.copy(alpha = 0.6f),
                                                fontSize = 11.sp
                                            )
                                        }

                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Button(
                                                onClick = {
                                                    scope.launch {
                                                        SettingsRepository.applyCustomPreset(preset)
                                                    }
                                                },
                                                shape = RoundedCornerShape(10.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388AF6))
                                            ) {
                                                Text(stringResource(R.string.apply_preset), fontSize = 11.sp)
                                            }

                                            IconButton(
                                                onClick = {
                                                    scope.launch {
                                                        SettingsRepository.deleteCustomPreset(preset.name)
                                                    }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Delete",
                                                    tint = Color(0xFFFF3B30),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }
}
