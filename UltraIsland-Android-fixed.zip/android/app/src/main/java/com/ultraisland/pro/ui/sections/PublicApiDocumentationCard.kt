/*
 * Smart Island (2026)
 * © Animesh Gupta — github.com/agupta07505
 * Licensed under the GNU GPL v3 License
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.ultraisland.pro.ui.sections

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Api
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.ui.components.CollapsibleCard

private val ProBlue = Color(0xFF388AF6)
private val ProGreen = Color(0xFF10B981)
private val ProAmber = Color(0xFFF59E0B)
private val ProPurple = Color(0xFF8B5CF6)
private val ProSurface = Color(0xFF141720)
private val ProCodeBg = Color(0xFF0D0F14)

private enum class BroadcastAction(
    val actionName: String,
    val title: String,
    val description: String
) {
    TRIGGER_EVENT(
        "com.ultraisland.pro.ACTION_TRIGGER_EVENT",
        "Trigger Event",
        "Displays a simulated or custom live event on the Island"
    ),
    UPDATE_WIDGET(
        "com.ultraisland.pro.ACTION_UPDATE_WIDGET",
        "Update Widget",
        "Pushes real-time text, weather or net metrics to Idle widgets"
    ),
    TOGGLE_ISLAND(
        "com.ultraisland.pro.ACTION_TOGGLE_ISLAND",
        "Toggle Island",
        "Enables, disables, expands or collapses the Island pill"
    )
}

/**
 * Public Broadcast API documentation & Interactive Intent Runner.
 * Enables Tasker, MacroDroid, Automate, and ADB shell scripts to trigger events,
 * update widgets, or toggle Island states programmatically.
 */
@Composable
fun PublicApiDocumentationCard(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var selectedAction by remember { mutableStateOf(BroadcastAction.TRIGGER_EVENT) }

    // Parameters for TRIGGER_EVENT
    var eventType by remember { mutableStateOf("custom") }
    var eventTitle by remember { mutableStateOf("Tasker Alert") }
    var eventMessage by remember { mutableStateOf("Battery charged to 80%") }
    var eventPriority by remember { mutableStateOf("high") }

    // Parameters for UPDATE_WIDGET
    var widgetType by remember { mutableStateOf("weather") }
    var widgetContent by remember { mutableStateOf("26°C Clear") }
    var widgetSubcontent by remember { mutableStateOf("Humidity 65%") }

    // Parameters for TOGGLE_ISLAND
    var toggleExpand by remember { mutableStateOf(true) }

    // Build the adb command string
    val adbCommand = remember(selectedAction, eventType, eventTitle, eventMessage, eventPriority, widgetType, widgetContent, widgetSubcontent, toggleExpand) {
        when (selectedAction) {
            BroadcastAction.TRIGGER_EVENT -> {
                "adb shell am broadcast -a ${selectedAction.actionName} \\\n" +
                        "  --es event_type \"$eventType\" \\\n" +
                        "  --es title \"$eventTitle\" \\\n" +
                        "  --es message \"$eventMessage\" \\\n" +
                        "  --es priority \"$eventPriority\""
            }
            BroadcastAction.UPDATE_WIDGET -> {
                "adb shell am broadcast -a ${selectedAction.actionName} \\\n" +
                        "  --es widget_type \"$widgetType\" \\\n" +
                        "  --es content \"$widgetContent\" \\\n" +
                        "  --es subcontent \"$widgetSubcontent\""
            }
            BroadcastAction.TOGGLE_ISLAND -> {
                "adb shell am broadcast -a ${selectedAction.actionName} \\\n" +
                        "  --ez expand $toggleExpand"
            }
        }
    }

    fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(context, "Copied: $label", Toast.LENGTH_SHORT).show()
    }

    fun fireBroadcastIntent() {
        val intent = Intent(selectedAction.actionName).apply {
            setPackage(context.packageName)
            when (selectedAction) {
                BroadcastAction.TRIGGER_EVENT -> {
                    putExtra("event_type", eventType)
                    putExtra("title", eventTitle)
                    putExtra("message", eventMessage)
                    putExtra("priority", eventPriority)
                }
                BroadcastAction.UPDATE_WIDGET -> {
                    putExtra("widget_type", widgetType)
                    putExtra("content", widgetContent)
                    putExtra("subcontent", widgetSubcontent)
                }
                BroadcastAction.TOGGLE_ISLAND -> {
                    putExtra("expand", toggleExpand)
                }
            }
        }

        context.sendBroadcast(intent)
        Toast.makeText(context, "Fired broadcast: ${selectedAction.name}", Toast.LENGTH_SHORT).show()
    }

    CollapsibleCard(
        title = "Broadcast API & Automation (Tasker)",
        stateKey = "card_public_api_doc",
        summary = "Integrate with Tasker, MacroDroid, or ADB shell scripts",
        icon = Icons.Rounded.Api,
        initiallyExpanded = false,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "UltraIsland exposes public broadcast actions. Any automation tool or local script can send standard Android broadcasts to control the Island.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Action Selection Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BroadcastAction.values().forEach { action ->
                    val isSelected = selectedAction == action
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedAction = action },
                        label = { Text(action.title, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ProPurple.copy(alpha = 0.2f),
                            selectedLabelColor = ProPurple
                        )
                    )
                }
            }

            // Description of current action
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ProSurface)
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.Code,
                    contentDescription = null,
                    tint = ProPurple,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = selectedAction.actionName,
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                        fontWeight = FontWeight.Bold,
                        color = ProPurple
                    )
                    Text(
                        text = selectedAction.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
            }

            // Parameter Editor Form
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(ProSurface)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Payload Extras & Parameters",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                when (selectedAction) {
                    BroadcastAction.TRIGGER_EVENT -> {
                        // Event type chips
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("charging", "music", "timer", "call", "custom").forEach { type ->
                                FilterChip(
                                    selected = eventType == type,
                                    onClick = { eventType = type },
                                    label = { Text(type, fontSize = 11.sp) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = eventTitle,
                            onValueChange = { eventTitle = it },
                            label = { Text("Extra: title (String)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ProPurple)
                        )

                        OutlinedTextField(
                            value = eventMessage,
                            onValueChange = { eventMessage = it },
                            label = { Text("Extra: message (String)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ProPurple)
                        )
                    }

                    BroadcastAction.UPDATE_WIDGET -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("weather", "netspeed", "calendar", "custom_text").forEach { type ->
                                FilterChip(
                                    selected = widgetType == type,
                                    onClick = { widgetType = type },
                                    label = { Text(type, fontSize = 11.sp) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = widgetContent,
                            onValueChange = { widgetContent = it },
                            label = { Text("Extra: content (String)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ProPurple)
                        )

                        OutlinedTextField(
                            value = widgetSubcontent,
                            onValueChange = { widgetSubcontent = it },
                            label = { Text("Extra: subcontent (String)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ProPurple)
                        )
                    }

                    BroadcastAction.TOGGLE_ISLAND -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = toggleExpand,
                                onClick = { toggleExpand = true },
                                label = { Text("Expand Island", fontSize = 11.sp) }
                            )
                            FilterChip(
                                selected = !toggleExpand,
                                onClick = { toggleExpand = false },
                                label = { Text("Collapse Island", fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }

            // ADB Command Snippet Box
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ProCodeBg)
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ADB Shell Test Command",
                        style = MaterialTheme.typography.labelSmall,
                        color = ProPurple,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton(
                        onClick = { copyToClipboard("ADB Broadcast Command", adbCommand) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ContentCopy,
                            contentDescription = "Copy Command",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = adbCommand,
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 11.sp
                )
            }

            // Tasker Instructions Snippet
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ProSurface)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "Tasker / MacroDroid Configuration:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "\u2022 Action: Send Intent\n" +
                            "\u2022 Action Name: ${selectedAction.actionName}\n" +
                            "\u2022 Package: com.ultraisland.pro\n" +
                            "\u2022 Target: Broadcast Receiver",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            // Send Test Broadcast Button
            Button(
                onClick = { fireBroadcastIntent() },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ProPurple)
            ) {
                Icon(Icons.Rounded.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Send Test Broadcast", fontWeight = FontWeight.Bold)
            }
        }
    }
}
