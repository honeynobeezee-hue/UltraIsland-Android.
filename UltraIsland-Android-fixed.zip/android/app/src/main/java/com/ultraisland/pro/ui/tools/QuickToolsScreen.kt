package com.ultraisland.pro.ui.tools

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.core.datastore.CustomTileConfig
import com.ultraisland.pro.core.datastore.SettingsRepository
import com.ultraisland.pro.core.datastore.TilePreferences
import com.ultraisland.pro.privileged.PrivilegedBridgeManager
import com.ultraisland.pro.privileged.PrivilegedCommandRegistry
import com.ultraisland.pro.services.accessibility.IslandAccessibilityService
import com.ultraisland.pro.tools.KeepScreenOnService
import kotlinx.coroutines.launch

@Composable
fun QuickToolsScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val isKeepAwakeActive by KeepScreenOnService.isRunning.collectAsState()
    val tiles by TilePreferences.getTiles(context).collectAsState(initial = TilePreferences.defaultTiles())

    var selectedSlot by remember { mutableIntStateOf(1) }
    val currentSlotConfig = tiles.find { it.slot == selectedSlot } ?: CustomTileConfig(selectedSlot, "Tile #$selectedSlot")

    var editLabel by remember(currentSlotConfig) { mutableStateOf(currentSlotConfig.label) }
    var editActionType by remember(currentSlotConfig) { mutableStateOf(currentSlotConfig.actionType) }
    var editPayload by remember(currentSlotConfig) { mutableStateOf(currentSlotConfig.targetPayload) }
    var editEnabled by remember(currentSlotConfig) { mutableStateOf(currentSlotConfig.isEnabled) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090A0D))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Column(modifier = Modifier.padding(start = 4.dp)) {
                    Text("Quick Tools & QS Tiles", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("System quick tiles, keep-awake, and custom action slots", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
                }
            }
        }

        // Built-in Tiles Quick Test Panel
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Standard QS Tiles (8 Active)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Tap to test actions directly from the app", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val taken = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                                    IslandAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) ?: false
                                } else false
                                if (!taken) {
                                    scope.launch { PrivilegedBridgeManager.exec(PrivilegedCommandRegistry.CMD_SCREENSHOT) }
                                }
                                Toast.makeText(context, "Screenshot requested", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF242936)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Screenshot", fontSize = 11.sp)
                        }

                        Button(
                            onClick = { KeepScreenOnService.toggle(context) },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isKeepAwakeActive) Color(0xFF388AF6) else Color(0xFF242936)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (isKeepAwakeActive) "Awake: ON" else "Keep Awake", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                                when (audioManager.ringerMode) {
                                    AudioManager.RINGER_MODE_NORMAL -> audioManager.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                                    AudioManager.RINGER_MODE_VIBRATE -> audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT
                                    else -> audioManager.ringerMode = AudioManager.RINGER_MODE_NORMAL
                                }
                                Toast.makeText(context, "Sound mode toggled", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF242936)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Volume Mode", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val locked = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                                    IslandAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) ?: false
                                } else false
                                if (!locked) {
                                    scope.launch { PrivilegedBridgeManager.exec(PrivilegedCommandRegistry.CMD_LOCK_SCREEN) }
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF242936)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Lock Screen", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                scope.launch {
                                    val cur = SettingsRepository.settingsFlow.first().enabled
                                    SettingsRepository.updateSettings { it.copy(enabled = !cur) }
                                    Toast.makeText(context, "Island ${if (!cur) "Enabled" else "Disabled"}", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF242936)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Toggle Island", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Custom Tile Editor (Slots 1 to 10)
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141720)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Custom QS Tile Editor (10 Slots)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Select a slot and bind custom launcher, intent, or shell triggers", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(14.dp))

                    // Slot selector pills
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        (1..5).forEach { slot ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (selectedSlot == slot) Color(0xFF388AF6) else Color(0xFF242936),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedSlot = slot }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("#$slot", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        (6..10).forEach { slot ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (selectedSlot == slot) Color(0xFF388AF6) else Color(0xFF242936),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedSlot = slot }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("#$slot", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = editLabel,
                        onValueChange = { editLabel = it },
                        label = { Text("Tile Label", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF388AF6),
                            unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Action Type", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("TOGGLE_ISLAND", "SCREENSHOT", "LOCK_SCREEN").forEach { type ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (editActionType == type) Color(0xFF388AF6) else Color(0xFF1E222D),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { editActionType = type }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(type.replace("_", " "), color = Color.White, fontSize = 10.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("LAUNCH_APP", "SHELL").forEach { type ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (editActionType == type) Color(0xFF388AF6) else Color(0xFF1E222D),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { editActionType = type }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(type.replace("_", " "), color = Color.White, fontSize = 10.sp)
                            }
                        }
                    }

                    if (editActionType == "LAUNCH_APP" || editActionType == "SHELL") {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = editPayload,
                            onValueChange = { editPayload = it },
                            label = {
                                Text(
                                    if (editActionType == "LAUNCH_APP") "Package Name (e.g. com.spotify.music)"
                                    else "Whitelisted Shell Command (e.g. svc wifi disable)",
                                    fontSize = 11.sp
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF388AF6),
                                unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Tile Enabled in QS", color = Color.White, fontSize = 13.sp)
                        Switch(
                            checked = editEnabled,
                            onCheckedChange = { editEnabled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF388AF6)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            scope.launch {
                                TilePreferences.saveTile(
                                    context,
                                    CustomTileConfig(
                                        slot = selectedSlot,
                                        label = editLabel.ifBlank { "Tile #$selectedSlot" },
                                        iconType = "custom",
                                        actionType = editActionType,
                                        targetPayload = editPayload,
                                        isEnabled = editEnabled
                                    )
                                )
                                Toast.makeText(context, "Tile #$selectedSlot configuration saved!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388AF6))
                    ) {
                        Text("Save Slot #$selectedSlot Configuration")
                    }
                }
            }
        }

        // Tutorial Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101217)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("How to Add Tiles to Quick Settings Panel", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("1. Swipe down twice from the top of your screen to open the full QS panel.\n2. Tap the Pencil / Edit icon.\n3. Scroll down to find UltraIsland tiles and drag them into your active tiles section.", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
