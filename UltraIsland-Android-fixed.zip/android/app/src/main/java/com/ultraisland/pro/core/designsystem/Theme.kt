package com.ultraisland.pro.core.designsystem

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PureBlack = Color(0xFF000000)
val DarkSurface = Color(0xFF101216)
val DarkCard = Color(0xFF161920)
val ElectricBlue = Color(0xFF388AF6)
val EmeraldGreen = Color(0xFF34C759)
val AmberGlow = Color(0xFFFF9500)
val CoralRed = Color(0xFFFF3B30)

private val DarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    background = PureBlack,
    surface = DarkSurface,
    surfaceVariant = DarkCard,
    onBackground = Color(0xFFEDEDED),
    onSurface = Color(0xFFF2F2F2),
    outline = Color(0xFF2E333D)
)

@Composable
fun UltraIslandTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
