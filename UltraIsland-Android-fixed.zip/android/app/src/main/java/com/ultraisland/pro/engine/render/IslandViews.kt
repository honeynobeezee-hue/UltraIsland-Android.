package com.ultraisland.pro.engine.render

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraisland.pro.core.datastore.IslandSettingsState
import com.ultraisland.pro.engine.activity.LiveActivity
import com.ultraisland.pro.engine.statemachine.IslandContentType
import com.ultraisland.pro.engine.statemachine.IslandState
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import com.ultraisland.pro.services.system.PrivacyIndicatorsState

@Composable
fun IslandOverlayRoot(
    settings: IslandSettingsState,
    modifier: Modifier = Modifier
) {
    if (!settings.islandEnabled) return

    val state by IslandStateMachine.state.collectAsState()
    val context = LocalContext.current

    val triggerHaptic = {
        if (settings.hapticEnabled) {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(18)
            }
        }
    }

    AnimatedVisibility(
        visible = state !is IslandState.Hidden,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .padding(top = settings.offsetY.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            val springSpec = spring<androidx.compose.ui.unit.Dp>(
                dampingRatio = 0.72f,
                stiffness = 380f * settings.animSpeed
            )

            val targetWidth = when (val s = state) {
                is IslandState.Idle -> if (s.nextAlarm != null) (settings.widthDp + 50).dp else settings.widthDp.dp
                is IslandState.Compact -> (settings.widthDp + 110).coerceAtMost(320).dp
                is IslandState.Expanded -> 350.dp
                IslandState.Hidden -> 0.dp
            }

            val targetHeight = when (val s = state) {
                is IslandState.Idle -> settings.heightDp.dp
                is IslandState.Compact -> (settings.heightDp + 6).dp
                is IslandState.Expanded -> when (s.contentType) {
                    is IslandContentType.Call -> 155.dp
                    is IslandContentType.Timer -> 175.dp
                    is IslandContentType.Media -> 180.dp
                    is IslandContentType.Notification -> 220.dp
                    is IslandContentType.Charging -> 130.dp
                    is IslandContentType.Bluetooth -> 135.dp
                    is IslandContentType.Volume -> 140.dp
                    is IslandContentType.Sound -> 125.dp
                    is IslandContentType.Navigation -> 135.dp
                    is IslandContentType.Ride -> 140.dp
                    is IslandContentType.Weather -> 130.dp
                    is IslandContentType.Calendar -> 130.dp
                    IslandContentType.QuickLauncher -> 155.dp
                    else -> 160.dp
                }
                IslandState.Hidden -> 0.dp
            }

            val targetRadius = when (state) {
                is IslandState.Expanded -> 34.dp
                else -> settings.cornerRadius.dp
            }

            val animatedWidth by animateDpAsState(targetValue = targetWidth, animationSpec = springSpec, label = "width")
            val animatedHeight by animateDpAsState(targetValue = targetHeight, animationSpec = springSpec, label = "height")
            val animatedRadius by animateDpAsState(targetValue = targetRadius, animationSpec = springSpec, label = "radius")

            val shape = RoundedCornerShape(animatedRadius)
            val privacyState by IslandStateMachine.privacyState.collectAsState()

            Box(
                modifier = Modifier
                    .width(animatedWidth)
                    .height(animatedHeight)
                    .shadow(elevation = 12.dp, shape = shape, spotColor = Color.Black)
                    .clip(shape)
                    .background(Color.Black)
                    .border(width = 0.8.dp, color = Color.White.copy(alpha = 0.16f), shape = shape)
                    .clickable {
                        if (state is IslandState.Compact || state is IslandState.Idle) {
                            triggerHaptic()
                            IslandStateMachine.toggleExpand()
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                when (val s = state) {
                    is IslandState.Idle -> {
                        if (s.isSplitPill) {
                            IdleSplitPillView(
                                timeText = s.widget?.primaryText ?: "10:41",
                                batteryText = "85%"
                            )
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (s.widget != null) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(Color(android.graphics.Color.parseColor(s.widget.accentColorHex)))
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = s.widget.primaryText,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = s.widget.secondaryText,
                                            color = Color.White.copy(alpha = 0.65f),
                                            fontSize = 10.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                } else if (s.nextAlarm != null) {
                                    Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFF9500)))
                                    Text(s.nextAlarm, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF161616))
                                    )
                                    Spacer(modifier = Modifier.weight(1f))
                                }

                                // Privacy Indicator Dots
                                if (privacyState.hasActiveIndicator) {
                                    PrivacyDotsRow(privacy = privacyState)
                                }
                            }
                        }
                    }
                    is IslandState.Compact -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Box(modifier = Modifier.weight(1f)) {
                                CompactContent(activity = s.activity, contentType = s.contentType, pendingCount = s.pendingCount)
                            }
                            if (privacyState.hasActiveIndicator) {
                                Spacer(modifier = Modifier.width(6.dp))
                                PrivacyDotsRow(privacy = privacyState)
                            }
                        }
                    }
                    is IslandState.Expanded -> {
                        when (val c = s.contentType) {
                            is IslandContentType.Call -> CallCardView(call = c.call)
                            is IslandContentType.Media -> MediaCardView(track = c.track)
                            is IslandContentType.Timer -> TimerCardView(timer = c.timer)
                            is IslandContentType.Notification -> NotificationCardView(notification = c.notif, settings = settings)
                            is IslandContentType.Charging -> ChargingCardView(battery = c.battery)
                            is IslandContentType.Bluetooth -> BluetoothCardView(bluetooth = c.bluetooth)
                            is IslandContentType.Volume -> VolumeBrightnessCardView(info = c.volume)
                            is IslandContentType.Sound -> SoundModeCardView(sound = c.sound)
                            is IslandContentType.Navigation -> NavigationCardView(nav = c.nav)
                            is IslandContentType.Ride -> RideDeliveryCardView(ride = c.ride)
                            is IslandContentType.Weather -> WeatherCardView(weather = c.weather)
                            is IslandContentType.Calendar -> CalendarCardView(event = c.event)
                            IslandContentType.QuickLauncher -> QuickLauncherBar()
                            is IslandContentType.Generic -> ExpandedGenericContent(activity = s.activity)
                            else -> ExpandedGenericContent(activity = s.activity)
                        }
                    }
                    IslandState.Hidden -> {}
                }
            }
        }
    }
}

@Composable
private fun CompactContent(
    activity: LiveActivity,
    contentType: IslandContentType,
    pendingCount: Int = 1
) {
    val accentColor = try {
        Color(android.graphics.Color.parseColor(activity.colorHex))
    } catch (_: Exception) {
        Color(0xFF388AF6)
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(accentColor),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = activity.title.take(1).uppercase(),
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = activity.title,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            if (contentType is IslandContentType.Media) {
                AudioWaveVisualizer(isPlaying = contentType.track.isPlaying, accentColor = accentColor)
            } else {
                Text(
                    text = activity.subtitle,
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }

            if (pendingCount > 1) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(accentColor.copy(alpha = 0.3f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "+$pendingCount",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun ExpandedGenericContent(activity: LiveActivity) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = activity.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(text = activity.subtitle, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp)
                .clip(RoundedCornerShape(17.dp))
                .background(Color.White.copy(alpha = 0.1f))
                .clickable { IslandStateMachine.collapse() },
            contentAlignment = Alignment.Center
        ) {
            Text(text = "Tap to collapse", color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp)
        }
    }
}

@Composable
fun PrivacyDotsRow(privacy: PrivacyIndicatorsState, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (privacy.isCameraInUse) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF34C759))
            )
        }
        if (privacy.isMicInUse) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFF9500))
            )
        }
        if (privacy.isScreenRecording) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFF3B30))
            )
        }
    }
}
