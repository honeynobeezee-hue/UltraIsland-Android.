package com.ultraisland.pro

import com.ultraisland.pro.engine.overlay.CutoutDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class CutoutDetectorTest {

    @Test
    fun `detect with null insets returns centered cutout`() {
        val density = 2.0f
        val screenWidthPx = 1080

        val info = CutoutDetector.detect(null, screenWidthPx, density)

        assertFalse(info.hasHardwareCutout)
        assertEquals(540, info.centerX)
        assertEquals((12 * density).toInt(), info.topY)
        assertEquals((110 * density).toInt(), info.bounds.width())
    }
}
