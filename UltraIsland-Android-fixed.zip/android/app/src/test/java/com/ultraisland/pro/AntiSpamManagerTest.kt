package com.ultraisland.pro

import com.ultraisland.pro.services.notification.AntiSpamManager
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class AntiSpamManagerTest {

    @Before
    fun setup() {
        AntiSpamManager.clearAll()
    }

    @Test
    fun `notifications below threshold are not blocked`() {
        val pkg = "com.chat.sample"
        assertFalse(AntiSpamManager.shouldBlock(pkg, threshold = 3, windowSeconds = 30))
        assertFalse(AntiSpamManager.shouldBlock(pkg, threshold = 3, windowSeconds = 30))
    }

    @Test
    fun `exceeding threshold triggers cooldown`() {
        val pkg = "com.chat.sample"
        assertFalse(AntiSpamManager.shouldBlock(pkg, threshold = 3, windowSeconds = 30))
        assertFalse(AntiSpamManager.shouldBlock(pkg, threshold = 3, windowSeconds = 30))
        // 3rd notification hits threshold -> blocked & triggers cooldown
        assertTrue(AntiSpamManager.shouldBlock(pkg, threshold = 3, windowSeconds = 30))
        // 4th notification during cooldown is also blocked
        assertTrue(AntiSpamManager.shouldBlock(pkg, threshold = 3, windowSeconds = 30))
    }

    @Test
    fun `whitelisted app is never blocked`() {
        val pkg = "com.chat.vip"
        val whitelist = setOf("com.chat.vip")
        repeat(10) {
            assertFalse(AntiSpamManager.shouldBlock(pkg, threshold = 3, windowSeconds = 30, whitelist = whitelist))
        }
    }
}
