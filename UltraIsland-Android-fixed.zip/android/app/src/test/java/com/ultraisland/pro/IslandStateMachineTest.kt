package com.ultraisland.pro

import com.ultraisland.pro.engine.activity.LiveActivity
import com.ultraisland.pro.engine.statemachine.IslandState
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class IslandStateMachineTest {

    @Before
    fun setup() {
        IslandStateMachine.clearActivity()
    }

    @Test
    fun `initial state is Idle`() {
        assertEquals(IslandState.Idle, IslandStateMachine.state.value)
    }

    @Test
    fun `posting activity transitions to Compact state`() {
        val activity = LiveActivity(
            id = "demo_1",
            title = "Midnight Reverie",
            subtitle = "Artist"
        )
        IslandStateMachine.postActivity(activity)

        val state = IslandStateMachine.state.value
        assertTrue(state is IslandState.Compact)
        assertEquals("Midnight Reverie", (state as IslandState.Compact).activity.title)
    }

    @Test
    fun `toggleExpand alternates between Compact and Expanded`() {
        val activity = LiveActivity(
            id = "demo_1",
            title = "Midnight Reverie",
            subtitle = "Artist"
        )
        IslandStateMachine.postActivity(activity)
        assertTrue(IslandStateMachine.state.value is IslandState.Compact)

        // Expand
        IslandStateMachine.toggleExpand()
        assertTrue(IslandStateMachine.state.value is IslandState.Expanded)

        // Collapse
        IslandStateMachine.toggleExpand()
        assertTrue(IslandStateMachine.state.value is IslandState.Compact)
    }

    @Test
    fun `setHidden hides island regardless of activity`() {
        val activity = LiveActivity("act_1", "Title", "Subtitle")
        IslandStateMachine.postActivity(activity)

        IslandStateMachine.setHidden(true)
        assertEquals(IslandState.Hidden, IslandStateMachine.state.value)

        IslandStateMachine.setHidden(false)
        assertTrue(IslandStateMachine.state.value is IslandState.Compact)
    }
}
