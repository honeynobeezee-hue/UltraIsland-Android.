package com.ultraisland.pro

import com.ultraisland.pro.engine.statemachine.IslandContentType
import com.ultraisland.pro.engine.statemachine.IslandState
import com.ultraisland.pro.engine.statemachine.IslandStateMachine
import com.ultraisland.pro.services.media.MediaTrackInfo
import com.ultraisland.pro.services.telephony.ActiveCallInfo
import com.ultraisland.pro.services.timer.ActiveTimerInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class Phase3PriorityTest {

    @Before
    fun setup() {
        IslandStateMachine.clearAll()
    }

    @Test
    fun `media playback enters Compact or Expanded state`() {
        val media = MediaTrackInfo("Midnight Reverie", "Artist", isPlaying = true)
        IslandStateMachine.postMedia(media)

        val state = IslandStateMachine.state.value
        assertTrue(state is IslandState.Compact)
        val compact = state as IslandState.Compact
        assertTrue(compact.contentType is IslandContentType.Media)
        assertEquals("Midnight Reverie", compact.activity.title)
    }

    @Test
    fun `incoming call preempts playing media`() {
        val media = MediaTrackInfo("Midnight Reverie", "Artist", isPlaying = true)
        IslandStateMachine.postMedia(media)

        // Incoming call arrives
        val call = ActiveCallInfo("Jane Doe", "+15550199", isIncoming = true, isOngoing = false)
        IslandStateMachine.postCall(call, autoExpand = true)

        val state = IslandStateMachine.state.value
        assertTrue(state is IslandState.Expanded)
        val expanded = state as IslandState.Expanded
        assertTrue(expanded.contentType is IslandContentType.Call)
        assertEquals("Incoming Call", expanded.activity.title)
    }

    @Test
    fun `ending call automatically restores media playback`() {
        val media = MediaTrackInfo("Midnight Reverie", "Artist", isPlaying = true)
        IslandStateMachine.postMedia(media)

        val call = ActiveCallInfo("Jane Doe", "+15550199", isIncoming = true, isOngoing = false)
        IslandStateMachine.postCall(call)

        // Call ends
        IslandStateMachine.clearCall()

        // Media resumes on island
        val state = IslandStateMachine.state.value
        assertTrue(state is IslandState.Compact)
        val compact = state as IslandState.Compact
        assertTrue(compact.contentType is IslandContentType.Media)
        assertEquals("Midnight Reverie", compact.activity.title)
    }

    @Test
    fun `timer runs and has higher priority than media`() {
        val media = MediaTrackInfo("Midnight Reverie", "Artist", isPlaying = true)
        IslandStateMachine.postMedia(media)

        val timer = ActiveTimerInfo("Tea Timer", 120, 120, isRunning = true)
        IslandStateMachine.postTimer(timer)

        val state = IslandStateMachine.state.value
        assertTrue(state is IslandState.Compact)
        val compact = state as IslandState.Compact
        assertTrue(compact.contentType is IslandContentType.Timer)
        assertEquals("Tea Timer", compact.activity.title)
    }
}
