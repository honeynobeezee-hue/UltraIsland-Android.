# Notice and License Information

## UltraIsland Pro
Copyright (c) 2026 UltraIsland Contributors.
Licensed under the GNU General Public License v3.0 (GPLv3).

### Third-Party Software and UI Attribution
This project incorporates and adapts user interface components, layout architecture, and styling from **SmartIsland**:
- **Author**: Animesh Gupta ([@agupta07505](https://github.com/agupta07505))
- **Source Repository**: [https://github.com/agupta07505/smartisland](https://github.com/agupta07505/smartisland)
- **License**: GNU General Public License v3.0 (GPLv3)

Per Sections 4 and 5 of the GNU General Public License v3.0, appropriate copyright notices and license headers are maintained in all derived source files.
