# SmartIsland APP UI bundle (home screen + settings, tanpa pill)

Sumber: https://github.com/agupta07505/SmartIsland v7.6.0 - GPLv3 (c) agupta07505.
Turunan WAJIB mempertahankan LICENSE + atribusi.

## Isi
- app/src/main/java/com/agupta07505/smartisland/
  - ui/SmartIslandHomeScreen.kt, Theme.kt, PermissionCard.kt, SliderSettingItem.kt, BounceClick.kt
  - ui/sections/ (41 layar/kartu settings), ui/components/, ui/search/, ui/pickers/, ui/glass/
  - model/, util/, data/, di/SmartIslandRepositories.kt  (dependensi non-UI)
- pill_side_files_reference/ : 6 file sisi-pill yang masih dirujuk UI aplikasi
  (IslandFonts, LedRaster, LedTickSlot, IdleWidgets, FaceIdLayer, IslandViewModel).
  Ambil yang dipakai fitur yang kamu pertahankan, atau buat stub.
- glue_service_reference/ : SmartIslandApp, MainActivity, Overlay/NotificationListener service
  (dirujuk HomeScreen/SupportSection untuk status service & tombol start/stop).
- app_src_main_res/ : resource.  build_reference/ : gradle + manifest acuan.

## Peringatan
- Daftar file hasil analisis nama simbol (heuristik), bukan hasil compile.
- UI settings membaca/menulis SmartIslandSettings + SmartIslandSettingsRepository (DataStore).
  Layar yang tidak relevan dengan fitur proyekmu sebaiknya dihapus + hapus key-nya.
