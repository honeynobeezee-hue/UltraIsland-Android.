# PROMPT: Integrasi UI Aplikasi SmartIsland ke proyek saya (disesuaikan dengan fitur proyek saya)

Salin semua di bawah ini ke Claude / Claude Code, lampirkan smartisland_app_ui.zip, dan ISI semua [ ... ].

---
Kamu adalah senior Android engineer (Kotlin, Jetpack Compose, Material 3).

## 1. Konteks
Terlampir UI aplikasi dari SmartIsland (GPLv3): home screen + settings (ui/SmartIslandHomeScreen.kt,
ui/sections/*, ui/components/*, ui/search/*, ui/pickers/*, Theme.kt). Pill/overlay TIDAK akan saya pakai.
Tujuan: pakai UI ini sebagai antarmuka aplikasi saya, tapi isinya HANYA menampilkan fitur yang proyek saya punya.

## 2. Proyek saya
- Nama & tujuan aplikasi: [ISI]
- Package name: [ISI]          - minSdk/targetSdk: [ISI]
- Arsitektur: [MVVM/MVI/...]   - DI: [Hilt/Koin/manual]
- Penyimpanan setting: [DataStore/SharedPreferences/Room]
- Navigasi: [Navigation Compose/manual]
- Tema saat ini: [Material3 + dynamic color? warna utama?]
- Bahasa/lokalisasi: [ISI]
- Lisensi proyek saya: [GPLv3 / lainnya -> bila bukan GPLv3, STOP dan tanya saya dulu]

## 3. Fitur proyek saya (isi tabel; ini menentukan layar mana yang dipakai)
| Fitur di proyek saya | Setting yang perlu ditampilkan | Tipe (toggle/slider/pilihan/izin) |
|---|---|---|
| [fitur 1] | [...] | [...] |
| [fitur 2] | [...] | [...] |
| [fitur 3] | [...] | [...] |

Fitur SmartIsland yang TIDAK ada di proyek saya (hapus UI-nya): [mis. pill/overlay, Face ID, cuaca, widget idle,
landscape, kalender, Shizuku, riwayat notifikasi, ... -> tulis yang mau dibuang, atau "putuskan sendiri lalu tanya"].

## 4. Tugas (berurutan, berhenti di akhir tiap langkah menunggu konfirmasi saya)

LANGKAH 1 - Inventaris & pemetaan (tanpa menulis kode)
- Baca ui/sections/*.kt dan SmartIslandHomeScreen.kt. Buat tabel: layar/kartu -> fitur SmartIsland -> status:
  KEEP (cocok dengan fitur saya) / ADAPT (ganti isi/label) / REMOVE (tidak relevan) / NEW (fitur saya belum punya UI).
- Untuk tiap layar KEEP/ADAPT: sebutkan field SmartIslandSettings, repository, dan util/model yang disentuh.
- Daftar file sisi-pill (pill_side_files_reference/) yang masih dirujuk dan usulan: stub / ambil / buang.
- Tampilkan estimasi jumlah file yang akan masuk ke proyek saya.

LANGKAH 2 - Lapisan data
- Rancang model setting SAYA (data class + repository di [DataStore/...]) yang hanya berisi key untuk fitur saya.
- Buat adapter/interface supaya layar settings tidak bergantung langsung ke SmartIslandSettings asli.
- Hapus key/field yatim; jangan menyisakan referensi ke service/overlay yang tidak ada.

LANGKAH 3 - Pindahkan UI
- Salin hanya file KEEP/ADAPT beserta dependensi minimal (model/util). Ganti package -> [package saya].
- Sesuaikan HomeScreen: kartu kategori sesuai fitur saya; hapus tombol/status overlay service & demo pill.
- Terapkan tema saya (warna, tipografi, dynamic color). Pertahankan komponen (CollapsibleCard, SliderSettingItem,
  ClickableRowItem, dll.) tapi samakan gaya dengan aplikasi saya.
- String: pindahkan ke strings.xml saya, buang string yatim; [pertahankan/hapus] terjemahan yang ada.

LANGKAH 4 - Fitur baru saya (NEW)
- Untuk tiap fitur saya yang belum punya UI, buat layar/kartu baru memakai komponen & pola yang sama.

LANGKAH 5 - Integrasi & build
- Berikan perubahan build.gradle (hanya dependency yang benar-benar dipakai; jangan bawa Hilt/Shizuku/hiddenapibypass
  kalau tidak diperlukan), manifest, dan navigasi.
- Pastikan kompilasi bersih: tidak ada "Unresolved reference", tidak ada import ke class yang tidak disalin.
- Sediakan @Preview untuk HomeScreen dan tiap section.

LANGKAH 6 - Verifikasi
- Checklist uji manual (dark mode, rotasi, font besar, back navigation, restore state).
- Daftar sisa TODO & risiko.

## 5. Aturan output
- Kode lengkap per file dengan path; jangan dipotong "..." dan jangan mengarang API yang tidak ada di source terlampir.
- Kalau butuh file yang tidak ada di zip, tanyakan; jangan menebak.
- Pertahankan header lisensi GPLv3 + atribusi ke agupta07505 pada file turunan; tambahkan NOTICE di proyek saya.
- Jangan ubah perilaku logika non-UI kecuali perlu; jelaskan tiap perubahan besar 1-2 kalimat.
- Kerjakan LANGKAH 1 sekarang, lalu tunggu konfirmasi saya.
---
