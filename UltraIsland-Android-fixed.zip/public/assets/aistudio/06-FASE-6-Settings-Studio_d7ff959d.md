# FASE 6: Settings Studio (gaya Smart Island Studio)

Lanjutkan project yang sudah ada. Fase ini BESAR, jadi dikerjakan dalam 3 sub-langkah. Kerjakan HANYA sub-langkah yang saya sebut. Mulai dengan **6A**.

Jika saya melampirkan screenshot SmartIsland, jadikan acuan akhir untuk warna, spasi, dan ikon.


## ATURAN BUILD (agar lolos GitHub Actions)
- Gradle 8.9, Android Gradle Plugin 8.6.1, Kotlin 2.0.20 + plugin `org.jetbrains.kotlin.plugin.compose`, Compose BOM 2024.09.00, JDK 17, compileSdk 35, targetSdk 35, minSdk 26.
- Jangan membuat gradle wrapper. Jangan memakai dependency/versi yang tidak pasti ada. Jika ragu soal versi, pilih versi stabil yang lebih lama.
- Semua file yang direferensikan (resource, XML accessibility config, ikon, string) HARUS ikut dibuat. Tidak boleh ada referensi ke file yang tidak ada.
- Package dasar: `com.ultraisland.pro`.
- Pertahankan kode yang sudah ada dari fase sebelumnya; ubah seminimal mungkin dan jangan merusak build yang sudah hijau.

## SPESIFIKASI UI (acuan untuk semua sub-langkah)
## 15. SPESIFIKASI UI: GAYA "SMART ISLAND STUDIO"

Tiru struktur dan nuansa SmartIsland (Compose + Material 3), diperkaya fitur gabungan. Jika saya melampirkan screenshot SmartIsland, pakai sebagai acuan akhir untuk warna, spasi, dan ikon; bila belum ada, ikuti panduan di bawah.

### 15.1 Bahasa desain
- Aplikasi bernama **"UltraIsland Studio"**, layar sambutan "Welcome to UltraIsland Studio" (padanan "Welcome to Smart Island Studio").
- Tema gelap utama (hitam/abu pekat, aksen terang), opsi Light dan "Dark mode" toggle, Material You dynamic color opsional.
- Kartu bersudut besar (radius ≥ 24dp) dengan ikon di kiri, judul + deskripsi satu baris di bawahnya; pengelompokan setting dalam section card; toggle Material 3 di kanan.
- Slider dengan nilai numerik di samping; tiap pengaturan visual punya **Live Preview island di bagian atas layar** yang langsung berubah saat slider digeser.
- Mikro-animasi halus pada transisi halaman (shared-axis/fade-through), ripple, dan haptic ringan.
- Teks bantuan singkat di bawah tiap pengaturan (contoh gaya: "How long Low battery, Battery saver and Fully charged cards stay").
- Banner "Action Required" di Home bila ada izin yang belum aktif (tap untuk langsung ke solusi).

### 15.2 Navigasi (pertahankan urutan & penamaan ala SmartIsland)
Home berisi daftar kartu kategori, tiap kartu membuka sub-halaman:
1. **Live Activities**: aktivitas dan timer langsung (notifikasi, media, telepon, timer, stopwatch, alarm, charging, bluetooth, navigasi, delivery/ride, privasi, koneksi, mode suara, volume/brightness, download, kalender, cuaca). Tiap aktivitas ada toggle, prioritas, durasi, dan pengaturan khusus ("Tune how long things stay on the island").
2. **Appearance, Opacity & Colors**: background opacity (glassmorphic), Background Blur + Blur Strength, Card blur, album backdrop, color themes, gradient (pill → warna kedua), ambient drop shadow (efek melayang), warna LED, tema bawaan (iOS, Material You, Noir OLED, Dark Grey, Neon), per-activity text size & corner.
3. **Layout & Presets**: ukuran/posisi/radius/merge style, cutout width/height/centre X/top Y, collapsed cutout width with content, tinggi & lebar island, preset siap pakai (Center Hole, Wide Island, iPhone 15/16 Pro, Nothing-style, Minimal) yang bisa dibuat/disimpan sendiri; nilai terpisah untuk portrait dan landscape ("Alternate by orientation").
4. **Fonts & Clock**: font LED (bawaan 5x7 dot), font teks island, **Add font (.ttf/.otf)**, Mix fonts, Hour tick, gaya jam/tanggal/cuaca/kecepatan angin/baterai.
5. **Animations**: gaya animasi, kecepatan portrait/landscape, spring, haptic, Cutout merge style per orientasi.
6. **Swipe Actions & Gesture Controls**: aksi swipe pada pill ter-collapse dan kartu ter-expand (kiri/kanan/bawah), tap, long-press, double-tap, drag; opsi aktif/nonaktif per gesture.
7. **App Alerts & Sound Manager**: daftar semua aplikasi, per-app: tampil/tidak, suara, Always Alert, prioritas, warna/ikon, "App Icon Only (Private)", Auto-fill with Recent Apps, Delete by App, Anti-Spam Cooldown (pengecualian "Apps never on cooldown"), pengaturan tampil 1 aplikasi vs semua.
8. **Idle & Widgets**: widget idle bergantian (jam, tanggal, cuaca animasi, kualitas udara, suhu, kecepatan jaringan, baterai, event kalender berikutnya, alarm berikutnya, kalkulator, app widget, app shortcuts), interval pergantian, durasi.
9. **Utilities & Toolbar**: toolbar cepat yang bisa dibuka/disembunyikan, "Add to Utilities", pinned apps, App Shortcuts Launcher, shortcut senter, kalkulator, catatan, screenshot, Quick Tools (dari Tooler) dan custom tiles.
10. **Calendar / Weather / Network settings**: izin & sumber kalender, pengaturan cuaca (API key opsional, lokasi perkiraan), pengaturan kecepatan jaringan.
11. **Accessibility, Notification Access & Battery** (halaman izin): status semua izin, Grant all, Battery Optimization Bypass, Autostart per OEM (pilih Manufacturer/ROM), Shell Access (Shizuku/ADB, Auto Setup, Check Shizuku methods).
12. **History & Logs**: Riwayat notifikasi (aktifkan), Auto-Cleanup Retention Period, Copy Logs, Clear All, Diagnostics.
13. **Backup & Restore Settings**: export/import JSON (juga preset layout), reset semua ("All settings reset to defaults") dengan konfirmasi.
14. **Updates & About**: update checker (opsional, bisa dimatikan), release notes, About UltraIsland Studio, versi, link komunitas, Support, lisensi open-source.

### 15.3 Pola UX wajib
- Pencarian pengaturan global di atas layar.
- Setiap pengaturan yang berisiko (mis. sembunyikan heads-up sistem) ada tombol "Preview/Test" dan "Reset item ini".
- Mode "Test island": simulasikan setiap Live Activity dan tampilkan di island asli.
- Empty state dan pesan error ramah, bukan kosong.
- Semua teks lewat `strings.xml` (ID + EN lengkap, struktur siap untuk bahasa lain).

---

## 16. MATRIKS FITUR GABUNGAN (SUPERSET, tidak boleh ada yang terlewat)

## 6. KUSTOMISASI PENUH (Settings Studio)
- **Layout**: ukuran pill (idle/compact/expanded), posisi, radius, merge style, margin, kalibrasi cutout, preset (Wide, iPhone 15 Pro, iPhone 16 Pro, Nothing-style, Minimal).
- **Tampilan**: warna dasar, gradient, opacity, blur kartu/background, glow, border, warna LED & font jam, tema (iOS, Material You dynamic accent, Noir OLED, Dark Grey, Neon), tampilan kartu per-aktivitas (ukuran teks & radius).
- **Animasi**: gaya, durasi, kecepatan (portrait/landscape), spring damping/stiffness, haptic.
- **Per-app**: daftar semua app terpasang; atur tampil/tidak, prioritas, warna, ikon, durasi, suara, "delete by app", tampilkan hanya ikon (privat).
- **Perilaku**: auto-hide, auto-expand, quiet hours, lockscreen, blacklist fullscreen, interval widget, anti-spam.
- **Manajemen**: Backup/Restore JSON (validasi skema, pesan error jelas), reset per-kategori, pencarian pengaturan (search), profil (Kerja, Tidur, Game), multi-bahasa (ID, EN, + string resource lengkap), mode test/simulasi tiap aktivitas, live preview island saat membuka halaman pengaturan.

## 5. GESTURE (semua bisa dipetakan ulang per konteks)
Tap, long-press, double-tap, swipe kiri/kanan/atas/bawah pada pill ter-collapse & pada kartu, drag (floating mode), tap di luar kartu untuk menutup. Aksi: expand, collapse, buka app, ganti aktivitas, dismiss, next/prev track, senter, screenshot, kunci layar, buka launcher, aksi kustom.


## SUB-LANGKAH
### 6A: Kerangka Settings + Appearance + Layout + Fonts + Animations
- Home bergaya kartu kategori, pencarian pengaturan global, banner "Action Required", live preview island di atas tiap halaman.
- Halaman: Appearance (opacity, blur, gradient, shadow, tema), Layout & Presets (ukuran, posisi, radius, merge style, nilai terpisah portrait/landscape, preset bawaan + simpan preset sendiri), Fonts & Clock (font LED, font kustom .ttf/.otf, Mix fonts), Animations (gaya, kecepatan, spring, haptic).
- Semua nilai tersimpan di DataStore dan langsung memengaruhi island.

### 6B: Gesture + App Alerts + Idle + Utilities
- Swipe Actions & Gesture Controls (pemetaan aksi per gesture, per konteks).
- App Alerts & Sound Manager lengkap (suara per-app, Delete by App, Auto-fill with Recent Apps, pengecualian anti-spam).
- Idle & Widgets (urutan/interval), Utilities & Toolbar (Add to Utilities, pinned apps).
- Pengaturan Calendar / Weather / Network speed.

### 6C: History, Backup, Profiles, Updates, About
- Riwayat notifikasi + Auto-Cleanup Retention Period, Copy Logs, Clear All.
- Backup & Restore JSON (validasi skema, pesan error jelas, import/export preset), reset per-kategori dan reset semua.
- Profil (Kerja, Tidur, Game) yang menyimpan kumpulan pengaturan.
- Updates & About (update checker opsional yang bisa dimatikan, release notes, lisensi open-source).

## FORMAT JAWABAN (WAJIB)
1. Mulai dengan tree file yang dibuat/diubah.
2. Tiap file diawali satu baris `// FILE: path/lengkap/Nama.ext` (untuk XML: `<!-- FILE: path -->`), diikuti isi file dalam satu code block.
3. Isi file LENGKAP. Dilarang memakai "...", placeholder, atau "bagian lain tetap sama". Hanya tulis file yang baru/berubah.
4. Jika jawaban akan terlalu panjang, berhenti di batas file yang rapi, tulis "BERSAMBUNG: file berikutnya = <daftar>", lalu tunggu saya mengirim "LANJUTKAN".
5. Setelah semua file: (a) cara build & install, (b) checklist tes manual beserta hasil yang diharapkan, (c) batasan/catatan OEM/Shizuku.
6. Setelah itu BERHENTI dan tunggu konfirmasi saya. Jangan mengerjakan fase berikutnya.

## CHECKLIST TES FASE INI (tiap sub-langkah)
- [ ] Setiap slider/toggle langsung mengubah island pada live preview.
- [ ] Nilai tersimpan setelah aplikasi ditutup dan dibuka lagi.
- [ ] Pencarian pengaturan menemukan item yang benar.
- [ ] Backup lalu restore mengembalikan tampilan yang sama; file rusak ditolak dengan pesan jelas.
- [ ] Preset dan profil bisa dibuat, dipakai, dan dihapus.
