# FASE 7: Quick Tools, Public API, Privileged Lanjutan

Lanjutkan project yang sudah ada. Kerjakan HANYA Fase 7.

## TUJUAN
Menambahkan Quick Settings tiles dan alat dari Tooler, API publik yang aman, dan lapisan Shizuku/ADB yang penuh termasuk ADB Wireless on-device.


## ATURAN BUILD (agar lolos GitHub Actions)
- Gradle 8.9, Android Gradle Plugin 8.6.1, Kotlin 2.0.20 + plugin `org.jetbrains.kotlin.plugin.compose`, Compose BOM 2024.09.00, JDK 17, compileSdk 35, targetSdk 35, minSdk 26.
- Jangan membuat gradle wrapper. Jangan memakai dependency/versi yang tidak pasti ada. Jika ragu soal versi, pilih versi stabil yang lebih lama.
- Semua file yang direferensikan (resource, XML accessibility config, ikon, string) HARUS ikut dibuat. Tidak boleh ada referensi ke file yang tidak ada.
- Package dasar: `com.ultraisland.pro`.
- Pertahankan kode yang sudah ada dari fase sebelumnya; ubah seminimal mungkin dan jangan merusak build yang sudah hijau.

## YANG HARUS DIBUAT
1. **Quick Tools** (`tools`): tile Screenshot, Keep Screen On (FGS keep-awake), Volume Mode, Battery Charge Optimization, Private DNS, Grayscale, 10 Custom Tiles + editor tile, shortcut kunci layar, tile "Toggle UltraIsland".
2. **Public API**: `IslandApiReceiver` dengan permission signature `POST_ISLAND_ACTIVITY` (judul, ikon, progress, durasi, warna) agar Tasker/app sendiri bisa mengirim aktivitas; dokumentasi singkat intent.
3. **ADB Wireless on-device**: pairing code + koneksi ke adbd lokal sebagai backend ketiga `PrivilegedBridge`, dengan wizard langkah demi langkah dan deteksi status.
4. **Fitur privileged dari tabel 14.3** yang belum ada: toggle Wi-Fi/BT/Airplane/Hotspot, screenshot & tombol sistem via gesture, anti-kill (whitelist baterai, standby bucket), kontrol Private DNS dan grayscale, force-stop per-app.
5. Keamanan: whitelist perintah, log perubahan setting sistem (nilai lama/baru), tombol "Pulihkan semua pengaturan sistem", deteksi Shizuku mati setelah reboot beserta tombol "Mulai Shizuku".

## SPESIFIKASI TERKAIT (acuan)
## 7. QUICK TOOLS (dari Tooler, opsional via modul `tools/`)
QS tiles: Screenshot, Keep Screen On (FGS keep-awake), Volume Mode, Battery Charge Optimization, Private DNS, Grayscale, 10 Custom Tiles + editor tile, shortcut kunci layar. Tile "Toggle UltraIsland". Memakai Shizuku / `WRITE_SECURE_SETTINGS` (diberikan lewat ADB) bila tersedia; tampilkan tutorial perintah ADB di app.

| # | Fitur | Sumber inspirasi | Detail |
|---|---|---|---|
| 18 | Public API | Island | `IslandApiReceiver` (permission signature `POST_ISLAND_ACTIVITY`) agar Tasker/app lain bisa mengirim Live Activity kustom (judul, ikon, progress, durasi, warna) |

## 14. LAPISAN PRIVILEGED: SHIZUKU & ADB SHELL (WAJIB DIBANGUN)

Asumsi: pengguna bersedia memakai Shizuku atau ADB. Bangun `PrivilegedBridge` sebagai interface tunggal dengan 3 backend, dipilih otomatis berdasarkan ketersediaan:
1. **Shizuku** (utama): `ShizukuProvider`, minta permission via `Shizuku.requestPermission`, jalankan perintah lewat `UserService` (AIDL) agar berjalan sebagai shell UID (2000). Tangani event binder dead/received dan restart otomatis.
2. **ADB Wireless Debugging (on-device)**: pairing code + koneksi ke `adbd` lokal (tanpa PC), sebagai pengganti bila Shizuku tidak terpasang. Sediakan wizard langkah demi langkah dan deteksi status.
3. **ADB dari PC (sekali jalan)**: tampilkan perintah siap-salin dan tombol "Copy semua", plus QR/teks. Setelah izin diberikan, aplikasi bekerja tanpa PC.
4. **Fallback non-privileged**: cara manual lewat Settings.

Semua pemanggilan lewat `PrivilegedBridge.exec(command)` yang mengembalikan `Result<String>` (timeout, logging, tidak pernah crash). Sediakan halaman **Diagnostics > Privileged** yang menampilkan backend aktif, UID, dan hasil tes tiap kemampuan.

### 14.2 Otomatisasi setup (satu tombol "Auto Setup")
Jika Shizuku/ADB aktif: grant semua izin di atas, aktifkan Accessibility + Notification Listener, whitelist baterai, set appops, lalu verifikasi dan tampilkan laporan. Tanpa Shizuku/ADB: arahkan ke layar pengaturan yang tepat satu per satu dengan deteksi status otomatis.

### 14.3 Fitur yang dibuka oleh Shizuku/ADB
| Kemampuan | Cara (contoh) | Dipakai untuk |
|---|---|---|
| Auto-enable service & izin | `pm grant`, `settings put secure`, `cmd notification allow_listener` | Onboarding 1 klik, auto-recover bila service mati |
| Anti-kill | `dumpsys deviceidle whitelist`, `appops RUN_ANY_IN_BACKGROUND`, `am set-standby-bucket PKG active` | Service island tidak dimatikan OEM |
| Sembunyikan heads-up bawaan sistem | `settings put global heads_up_notifications_enabled 0` (simpan nilai asli, pulihkan saat island dimatikan/uninstall/crash) | Island menggantikan banner sistem |
| Notifikasi sensitif | `appops RECEIVE_SENSITIVE_NOTIFICATIONS` | OTP/pesan sensitif di Android 15+ |
| Screenshot & tombol sistem | `input keyevent`, `screencap` / `cmd statusbar` | Aksi gesture: screenshot, kunci layar, back/home/recents |
| Kontrol koneksi | `svc wifi`, `svc bluetooth`, `cmd connectivity`, `cmd wifi`, `settings put global airplane_mode_on` | Toggle Wi-Fi/BT/Airplane/Hotspot dari island |
| Private DNS, grayscale, dsb. | `settings put global private_dns_mode/specifier`, `settings put secure accessibility_display_daltonizer_enabled` | Quick Tools & tile (dari Tooler) |
| Keep screen on / charging limit | `svc power stayon`, `settings put global stay_on_while_plugged_in` | Quick Tools |
| Data baterai Bluetooth, status hotspot, panggilan | `dumpsys bluetooth_manager`, `dumpsys telephony.registry`, `dumpsys connectivity` | Kartu earbuds, hotspot, call state yang lebih akurat |
| Deteksi privasi (kamera/mic/lokasi aktif) | `appops get`/`dumpsys appops`, `cmd appops` | Titik hijau/oranye lebih akurat |
| Foreground app & fullscreen | `dumpsys window`, `dumpsys activity` | Auto-hide di game/video lebih tepat |
| Force-stop / bersihkan app | `am force-stop`, `KILL_BACKGROUND_PROCESSES` | Tindakan cepat per-app |
| Baca log | `READ_LOGS` | Diagnostics & deteksi event notifikasi yang terlewat |

### 14.4 Keamanan & keandalan lapisan privileged
- Whitelist perintah: hanya perintah yang didefinisikan di kode (tidak ada eksekusi string bebas dari input pengguna/aplikasi lain).
- Setiap perubahan setting sistem dicatat (nilai lama, nilai baru) di Room, dan ada tombol **"Pulihkan semua pengaturan sistem"** (juga dijalankan otomatis saat island dimatikan).
- Tangani Shizuku mati setelah reboot (tanpa root, perlu start ulang): deteksi, notifikasi ke pengguna, tombol "Mulai Shizuku", dan jalur ADB Wireless otomatis (Android 11+).
- `IslandApiReceiver` tetap dilindungi permission signature; jangan pernah mengekspos `PrivilegedBridge` ke aplikasi lain.
- Rilis: sebutkan jelas di README bahwa fitur privileged opsional dan aplikasi cocok didistribusikan via GitHub/F-Droid (kebijakan Play Store ketat pada Accessibility, `QUERY_ALL_PACKAGES`, dan `WRITE_SECURE_SETTINGS`).
- Uji pada: Android 11–16, Shizuku mode ADB dan root, ADB Wireless on-device, tanpa Shizuku (fallback).


---


## FORMAT JAWABAN (WAJIB)
1. Mulai dengan tree file yang dibuat/diubah.
2. Tiap file diawali satu baris `// FILE: path/lengkap/Nama.ext` (untuk XML: `<!-- FILE: path -->`), diikuti isi file dalam satu code block.
3. Isi file LENGKAP. Dilarang memakai "...", placeholder, atau "bagian lain tetap sama". Hanya tulis file yang baru/berubah.
4. Jika jawaban akan terlalu panjang, berhenti di batas file yang rapi, tulis "BERSAMBUNG: file berikutnya = <daftar>", lalu tunggu saya mengirim "LANJUTKAN".
5. Setelah semua file: (a) cara build & install, (b) checklist tes manual beserta hasil yang diharapkan, (c) batasan/catatan OEM/Shizuku.
6. Setelah itu BERHENTI dan tunggu konfirmasi saya. Jangan mengerjakan fase berikutnya.

## CHECKLIST TES FASE INI
- [ ] Tiles muncul di Quick Settings dan bekerja.
- [ ] Intent API dari Tasker/adb menampilkan aktivitas kustom; app lain tanpa permission ditolak.
- [ ] Backend Shizuku, ADB Wireless, dan fallback manual terdeteksi benar di Diagnostics.
- [ ] Tombol "Pulihkan semua pengaturan sistem" mengembalikan nilai awal.
