# FASE 2: Notifikasi

Lanjutkan project yang sudah ada. Kerjakan HANYA Fase 2.

## TUJUAN
Semua notifikasi tampil di island sebagai kartu yang bisa dibalas, ditandai dibaca, dan ditutup, dengan filter per-app dan anti-spam.


## ATURAN BUILD (agar lolos GitHub Actions)
- Gradle 8.9, Android Gradle Plugin 8.6.1, Kotlin 2.0.20 + plugin `org.jetbrains.kotlin.plugin.compose`, Compose BOM 2024.09.00, JDK 17, compileSdk 35, targetSdk 35, minSdk 26.
- Jangan membuat gradle wrapper. Jangan memakai dependency/versi yang tidak pasti ada. Jika ragu soal versi, pilih versi stabil yang lebih lama.
- Semua file yang direferensikan (resource, XML accessibility config, ikon, string) HARUS ikut dibuat. Tidak boleh ada referensi ke file yang tidak ada.
- Package dasar: `com.ultraisland.pro`.
- Pertahankan kode yang sudah ada dari fase sebelumnya; ubah seminimal mungkin dan jangan merusak build yang sudah hijau.

- Aturan per-app disimpan di DataStore (JSON) dulu; Room tetap ditunda.
- Tambahkan dependency baru hanya bila perlu dan pilih versi stabil.

## YANG HARUS DIBUAT
1. `IslandNotificationListener` (NotificationListenerService) + deteksi listener mati lalu `requestRebind`.
2. Model `NotificationActivity` masuk ke antrian di `engine.activity` (prioritas, interupsi, antrian, timeout tampil).
3. UI: pill compact (ikon app + titik/+N), kartu expanded (foto pengirim atau ikon, judul, beberapa baris teks dengan auto-scroll, tombol aksi notifikasi, Balas via RemoteInput langsung di kartu, Mark as read, Dismiss).
4. Grup per app, bubble untuk chat lain di bawah kartu, swipe untuk menutup (opsi ikut membersihkan notifikasi sistem).
5. Auto-expand pada notifikasi baru dan saat lockscreen (opsi). Sembunyikan teks dan foto di lockscreen (opsi).
6. Filter per-app: tampil/tidak, prioritas, warna, "App Icon Only (Private)", "Always Alert", daftar aplikasi terpasang dengan pencarian.
7. Anti-spam: jika >= N notifikasi dari app yang sama dalam 30 detik, beri cooldown (dapat diatur, dengan pengecualian app).
8. Opsi menyembunyikan heads-up bawaan sistem lewat `PrivilegedBridge` (simpan nilai asli, tombol pulihkan, otomatis pulihkan saat island dimatikan).
9. Tombol "Send test notification" untuk mengetes tanpa app lain.
10. Halaman Setup menampilkan status Notification Access dan membuka layar yang tepat.

## SPESIFIKASI TERKAIT (acuan)
| # | Fitur | Sumber inspirasi | Detail |
|---|---|---|---|
| 1 | Notifikasi | semua | Banner heads-up pengganti, preview teks (beberapa baris, auto-scroll), foto pengirim/ikon app, balas langsung (RemoteInput) via kartu atau `ReplyActivity`, mark as read, dismiss, tombol aksi notifikasi, grup per app, bubble untuk chat lain di bawah kartu, indikator dot/+N, filter per-app, geser untuk hapus (opsi ikut membersihkan notifikasi sistem), sembunyikan isi teks & foto di lockscreen |

Item UI terkait (App Alerts & Sound Manager):
7. **App Alerts & Sound Manager**: daftar semua aplikasi, per-app: tampil/tidak, suara, Always Alert, prioritas, warna/ikon, "App Icon Only (Private)", Auto-fill with Recent Apps, Delete by App, Anti-Spam Cooldown (pengecualian "Apps never on cooldown"), pengaturan tampil 1 aplikasi vs semua.


## FORMAT JAWABAN (WAJIB)
1. Mulai dengan tree file yang dibuat/diubah.
2. Tiap file diawali satu baris `// FILE: path/lengkap/Nama.ext` (untuk XML: `<!-- FILE: path -->`), diikuti isi file dalam satu code block.
3. Isi file LENGKAP. Dilarang memakai "...", placeholder, atau "bagian lain tetap sama". Hanya tulis file yang baru/berubah.
4. Jika jawaban akan terlalu panjang, berhenti di batas file yang rapi, tulis "BERSAMBUNG: file berikutnya = <daftar>", lalu tunggu saya mengirim "LANJUTKAN".
5. Setelah semua file: (a) cara build & install, (b) checklist tes manual beserta hasil yang diharapkan, (c) batasan/catatan OEM/Shizuku.
6. Setelah itu BERHENTI dan tunggu konfirmasi saya. Jangan mengerjakan fase berikutnya.

## CHECKLIST TES FASE INI
- [ ] Notifikasi dari WhatsApp/Telegram/app lain muncul di island.
- [ ] Balas langsung dari kartu terkirim.
- [ ] Mark as read dan Dismiss bekerja.
- [ ] Filter per-app dan anti-spam bekerja.
- [ ] Teks disembunyikan di lockscreen bila opsi aktif.
- [ ] Heads-up sistem tersembunyi dan dapat dipulihkan.
- [ ] Layanan tetap hidup setelah layar mati beberapa menit.
