# FASE 5: Navigasi, Delivery/Ride, Kalender, Cuaca, Widget Idle, Quick Launcher

Lanjutkan project yang sudah ada. Kerjakan HANYA Fase 5.

## TUJUAN
Aktivitas berbasis konten luar dan widget saat island idle.


## ATURAN BUILD (agar lolos GitHub Actions)
- Gradle 8.9, Android Gradle Plugin 8.6.1, Kotlin 2.0.20 + plugin `org.jetbrains.kotlin.plugin.compose`, Compose BOM 2024.09.00, JDK 17, compileSdk 35, targetSdk 35, minSdk 26.
- Jangan membuat gradle wrapper. Jangan memakai dependency/versi yang tidak pasti ada. Jika ragu soal versi, pilih versi stabil yang lebih lama.
- Semua file yang direferensikan (resource, XML accessibility config, ikon, string) HARUS ikut dibuat. Tidak boleh ada referensi ke file yang tidak ada.
- Package dasar: `com.ultraisland.pro`.
- Pertahankan kode yang sudah ada dari fase sebelumnya; ubah seminimal mungkin dan jangan merusak build yang sudah hijau.

## YANG HARUS DIBUAT
1. **Navigasi**: parse notifikasi ongoing Google Maps/Waze/OsmAnd (arah, jarak, ETA, ikon belokan), proteksi false-positive, tampil compact dan expanded.
2. **Delivery/Ride**: status order/ride (Zomato, Swiggy, Uber, Gojek, Grab, dll.) dari notifikasi ongoing dengan progress; daftar app dapat diatur.
3. **Kalender**: event berikutnya ("10:30, dalam 25 menit"), `READ_CALENDAR`, baca lokal saja, pengaturan kalender mana yang dipakai.
4. **Cuaca**: suhu + ikon animasi, kualitas udara, kecepatan angin. Internet opsional; gunakan penyedia tanpa API key (mis. Open-Meteo) sebagai default, bisa dimatikan. Lokasi perkiraan opsional.
5. **Widget idle bergantian**: jam (LED/font), tanggal, cuaca, baterai, kecepatan jaringan, event berikutnya, alarm berikutnya, dengan interval bergantian yang dapat diatur dan auto-hide pill saat idle.
6. **Quick launcher**: App Shortcuts Launcher, pinned apps, kalkulator, catatan cepat, app widget, senter.
7. Waktu di kiri dan baterai di kanan kamera saat idle (opsi).

## SPESIFIKASI TERKAIT (acuan)
| # | Fitur | Sumber inspirasi | Detail |
|---|---|---|---|
| 7 | Navigasi | Islandify, SmartIsland | Live direction Google Maps/Waze/OsmAnd dari notifikasi ongoing, proteksi false-positive |
| 8 | Pengiriman & Ride | Islandify | Status order/ride (Zomato, Swiggy, Uber, Gojek, Grab, dll.) + progress |
| 14 | Kalender | Island, Islandify, SmartIsland | Event berikutnya (mis. "10:30, dalam 25 menit"), `READ_CALENDAR`, baca lokal saja |
| 15 | Cuaca & Jam | SmartIsland | Ikon cuaca animasi, suhu, jam LED/font kustom, widget idle bergantian (interval bisa diatur), lokasi opsional |
| 16 | Quick launcher | SmartIsland | App shortcuts, kalkulator, app widget, catatan cepat |
| 17 | Fokus/Idle | Islandify | Waktu di kiri & baterai di kanan saat tidak ada aktivitas, alarm/event berikutnya |

Item UI terkait:
8. **Idle & Widgets**: widget idle bergantian (jam, tanggal, cuaca animasi, kualitas udara, suhu, kecepatan jaringan, baterai, event kalender berikutnya, alarm berikutnya, kalkulator, app widget, app shortcuts), interval pergantian, durasi.
9. **Utilities & Toolbar**: toolbar cepat yang bisa dibuka/disembunyikan, "Add to Utilities", pinned apps, App Shortcuts Launcher, shortcut senter, kalkulator, catatan, screenshot, Quick Tools (dari Tooler) dan custom tiles.
10. **Calendar / Weather / Network settings**: izin & sumber kalender, pengaturan cuaca (API key opsional, lokasi perkiraan), pengaturan kecepatan jaringan.


## FORMAT JAWABAN (WAJIB)
1. Mulai dengan tree file yang dibuat/diubah.
2. Tiap file diawali satu baris `// FILE: path/lengkap/Nama.ext` (untuk XML: `<!-- FILE: path -->`), diikuti isi file dalam satu code block.
3. Isi file LENGKAP. Dilarang memakai "...", placeholder, atau "bagian lain tetap sama". Hanya tulis file yang baru/berubah.
4. Jika jawaban akan terlalu panjang, berhenti di batas file yang rapi, tulis "BERSAMBUNG: file berikutnya = <daftar>", lalu tunggu saya mengirim "LANJUTKAN".
5. Setelah semua file: (a) cara build & install, (b) checklist tes manual beserta hasil yang diharapkan, (c) batasan/catatan OEM/Shizuku.
6. Setelah itu BERHENTI dan tunggu konfirmasi saya. Jangan mengerjakan fase berikutnya.

## CHECKLIST TES FASE INI
- [ ] Navigasi Google Maps tampil dengan arah dan ETA.
- [ ] Event kalender terdekat tampil.
- [ ] Cuaca muncul (dan aman saat offline).
- [ ] Widget idle bergantian sesuai interval.
- [ ] Quick launcher membuka app/alat yang benar.
