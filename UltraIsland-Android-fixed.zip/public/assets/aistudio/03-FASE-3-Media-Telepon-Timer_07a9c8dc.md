# FASE 3: Media, Telepon, Timer/Stopwatch/Alarm

Lanjutkan project yang sudah ada. Kerjakan HANYA Fase 3.

## TUJUAN
Tiga Live Activity inti: pemutar musik lengkap, panggilan telepon, dan timer/stopwatch/alarm.


## ATURAN BUILD (agar lolos GitHub Actions)
- Gradle 8.9, Android Gradle Plugin 8.6.1, Kotlin 2.0.20 + plugin `org.jetbrains.kotlin.plugin.compose`, Compose BOM 2024.09.00, JDK 17, compileSdk 35, targetSdk 35, minSdk 26.
- Jangan membuat gradle wrapper. Jangan memakai dependency/versi yang tidak pasti ada. Jika ragu soal versi, pilih versi stabil yang lebih lama.
- Semua file yang direferensikan (resource, XML accessibility config, ikon, string) HARUS ikut dibuat. Tidak boleh ada referensi ke file yang tidak ada.
- Package dasar: `com.ultraisland.pro`.
- Pertahankan kode yang sudah ada dari fase sebelumnya; ubah seminimal mungkin dan jangan merusak build yang sudah hijau.

## YANG HARUS DIBUAT
**Media**
1. `MediaSessionManager` lewat `NotificationListener` component untuk membaca sesi aktif (judul, artis, album art, durasi, posisi).
2. Kartu: album art, progress + seek, prev/play/pause/next, buka app sumber saat tap.
3. Warna dinamis dari album art (Palette/algoritma sendiri), backdrop album blur, glow berwarna.
4. Visualizer gelombang: gunakan `Visualizer`/RECORD_AUDIO bila diizinkan; fallback animasi gelombang berbasis status play. Kartu terbuka beberapa detik saat lagu berganti.
5. Tombol media pada cutout ter-expand (opsi).

**Telepon**
1. Deteksi state panggilan (TelephonyCallback/PhoneStateListener sesuai versi Android) dan notifikasi panggilan.
2. Panggilan masuk: nama/nomor, tombol Angkat/Tolak (`TelecomManager.acceptRingingCall` / `endCall`, `ANSWER_PHONE_CALLS`), mini-call mode saat berlangsung (durasi, speaker, mute).
3. Fallback bila izin belum ada: tombol buka layar panggilan.

**Timer / Stopwatch / Alarm**
1. Timer dan stopwatch interaktif dengan `BroadcastReceiver` aksi (start/pause/reset), notifikasi selesai.
2. Alarm berikutnya ditampilkan saat idle; `SCHEDULE_EXACT_ALARM` dengan alur izin yang jelas.
3. Halaman pengaturan sederhana untuk tiap aktivitas (toggle, durasi tampil, prioritas).

## SPESIFIKASI TERKAIT (acuan)
| # | Fitur | Sumber inspirasi | Detail |
|---|---|---|---|
| 2 | Media | semua | Judul/artis/album art, progress, seek, next/prev, play/pause, visualizer gelombang (pakai `Visualizer`/RECORD_AUDIO opsional), warna dinamis dari album art (Palette), backdrop album, kartu terbuka beberapa detik saat lagu berganti, buka app sumber saat tap |
| 3 | Telepon | Islandify, ExpressiveCutout, SmartIsland | Panggilan masuk/keluar/berlangsung, Angkat/Tolak (ANSWER_PHONE_CALLS / TelecomManager), speaker, mute, durasi, mini-call mode, status "memfilter panggilan" (call screening), dukungan dialer |
| 4 | Timer / Stopwatch / Alarm | Island, SmartIsland | Timer & stopwatch interaktif (action receiver), alarm berikutnya saat idle, exact alarm (`SCHEDULE_EXACT_ALARM`), notifikasi "Timer selesai" |
| 17 | Fokus/Idle | Islandify | Waktu di kiri & baterai di kanan saat tidak ada aktivitas, alarm/event berikutnya |


## FORMAT JAWABAN (WAJIB)
1. Mulai dengan tree file yang dibuat/diubah.
2. Tiap file diawali satu baris `// FILE: path/lengkap/Nama.ext` (untuk XML: `<!-- FILE: path -->`), diikuti isi file dalam satu code block.
3. Isi file LENGKAP. Dilarang memakai "...", placeholder, atau "bagian lain tetap sama". Hanya tulis file yang baru/berubah.
4. Jika jawaban akan terlalu panjang, berhenti di batas file yang rapi, tulis "BERSAMBUNG: file berikutnya = <daftar>", lalu tunggu saya mengirim "LANJUTKAN".
5. Setelah semua file: (a) cara build & install, (b) checklist tes manual beserta hasil yang diharapkan, (c) batasan/catatan OEM/Shizuku.
6. Setelah itu BERHENTI dan tunggu konfirmasi saya. Jangan mengerjakan fase berikutnya.

## CHECKLIST TES FASE INI
- [ ] Musik dari Spotify/YouTube Music tampil dengan art, progress, dan kontrol.
- [ ] Warna island mengikuti album art.
- [ ] Panggilan masuk menampilkan Angkat/Tolak yang bekerja.
- [ ] Timer dan stopwatch berjalan dan bisa dikontrol dari island.
- [ ] Alarm berikutnya tampil saat idle.
- [ ] Antrian prioritas: panggilan menginterupsi musik, lalu musik kembali.
