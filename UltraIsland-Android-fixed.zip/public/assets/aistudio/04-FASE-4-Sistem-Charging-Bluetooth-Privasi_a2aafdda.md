# FASE 4: Aktivitas Sistem (Charging, Bluetooth, Privasi, Koneksi, Suara, Volume, Download)

Lanjutkan project yang sudah ada. Kerjakan HANYA Fase 4.

## TUJUAN
Semua Live Activity berbasis status sistem, event-driven (tanpa polling boros).


## ATURAN BUILD (agar lolos GitHub Actions)
- Gradle 8.9, Android Gradle Plugin 8.6.1, Kotlin 2.0.20 + plugin `org.jetbrains.kotlin.plugin.compose`, Compose BOM 2024.09.00, JDK 17, compileSdk 35, targetSdk 35, minSdk 26.
- Jangan membuat gradle wrapper. Jangan memakai dependency/versi yang tidak pasti ada. Jika ragu soal versi, pilih versi stabil yang lebih lama.
- Semua file yang direferensikan (resource, XML accessibility config, ikon, string) HARUS ikut dibuat. Tidak boleh ada referensi ke file yang tidak ada.
- Package dasar: `com.ultraisland.pro`.
- Pertahankan kode yang sudah ada dari fase sebelumnya; ubah seminimal mungkin dan jangan merusak build yang sudah hijau.

## YANG HARUS DIBUAT
1. **Charging/Baterai**: kartu saat charger dicolok (persen, estimasi, fast/wireless), peringatan 20% dan 10%, battery saver, fully charged; durasi kartu dapat diatur; mode "hanya saat charging/low".
2. **Bluetooth**: pop-up saat earbuds/headset terhubung (nama, baterai L/R/case bila tersedia), headset kabel; gunakan `BLUETOOTH_CONNECT` dengan alur izin.
3. **Privasi**: titik hijau/oranye/merah untuk kamera/mic/lokasi (gunakan `AppOpsManager` callbacks / `dumpsys appops` via `PrivilegedBridge` bila tersedia), deteksi perekaman layar (`DETECT_SCREEN_RECORDING`, Android 15+, dengan fallback).
4. **Koneksi**: hotspot/tethering, VPN, Wi-Fi, USB, NFC, Airplane.
5. **Mode suara & DND & senter**: ring/vibrate/silent, DND (`ACCESS_NOTIFICATION_POLICY`), senter; animasi saat berubah; toggle dari island (via `PrivilegedBridge` bila perlu).
6. **Volume & Brightness**: slider di island (`WRITE_SETTINGS`), auto brightness, auto-rotate.
7. **Download/Upload**: progress dari notifikasi ongoing.
8. Halaman pengaturan per aktivitas (toggle, durasi, prioritas) dan tombol Test untuk tiap aktivitas.

## SPESIFIKASI TERKAIT (acuan)
| # | Fitur | Sumber inspirasi | Detail |
|---|---|---|---|
| 5 | Pengisian & Baterai | semua | Kartu charger saat dicolok, fast/wireless charging, persen & estimasi, peringatan 20%/10%, battery saver, fully charged; durasi kartu bisa diatur; mode "hanya saat charging/low" |
| 6 | Bluetooth | Islandify, SmartIsland | Pop-up earbuds/headphone terhubung (nama, baterai L/R/case), animasi, headset kabel |
| 9 | Privasi | ExpressiveCutout, Island, Islandify | Titik hijau/oranye/merah (kamera/mic/lokasi), deteksi perekaman layar (`DETECT_SCREEN_RECORDING`), indikator rekam audio |
| 10 | Koneksi | SmartIsland, ExpressiveCutout | Hotspot/tethering, VPN, Wi-Fi, USB, NFC, Airplane |
| 11 | Mode suara | Islandify | Ring/vibrate/silent, DND (`ACCESS_NOTIFICATION_POLICY`), senter; animasi saat berubah |
| 12 | Volume & Brightness | SmartIsland | Slider di island, `WRITE_SETTINGS` |
| 13 | Unduhan/Unggahan | Islandify | Progress download/upload dari notifikasi |

### 14.3 Fitur yang dibuka oleh Shizuku/ADB
| Kemampuan | Cara (contoh) | Dipakai untuk |
|---|---|---|
| Auto-enable service & izin | `pm grant`, `settings put secure`, `cmd notification allow_listener` | Onboarding 1 klik, auto-recover bila service mati |
| Anti-kill | `dumpsys deviceidle whitelist`, `appops RUN_ANY_IN_BACKGROUND`, `am set-standby-bucket PKG active` | Service island tidak dimatikan OEM |
| Sembunyikan heads-up bawaan sistem | `settings put global heads_up_notifications_enabled 0` (simpan nilai asli, pulihkan saat island dimatikan/uninstall/crash) | Island menggantikan banner sistem |
| Notifikasi sensitif | `appops RECEIVE_SENSITIVE_NOTIFICATIONS` | OTP/pesan sensitif di Android 15+ |
| Screenshot & tombol sistem | `input keyevent`, `screencap` / `cmd statusbar` | Aksi gesture: screenshot, kunci layar, back/home/recents |
| Kontrol koneksi | `svc wifi`, `svc bluetooth`, `cmd connectivity`, `cmd wifi`, `settings put global airplane_mode_on` | Toggle Wi-Fi/BT/Airplane/Hotspot dari island |
| Private DNS, grayscale, dsb. | `settings put global private_dns_mode/specifier`, `settings put secure accessibility_display_daltonizer_enabled` | Quick Tools & tile (dari Tooler) |
| Keep screen on / charging limit | `svc power stayon`, `settings put global stay_on_while_plugged_in` | Quick Tools |
| Data baterai Bluetooth, status hotspot, panggilan | `dumpsys bluetooth_manager`, `dumpsys telephony.registry`, `dumpsys connectivity` | Kartu earbuds, hotspot, call state yang lebih akurat |
| Deteksi privasi (kamera/mic/lokasi aktif) | `appops get`/`dumpsys appops`, `cmd appops` | Titik hijau/oranye lebih akurat |
| Foreground app & fullscreen | `dumpsys window`, `dumpsys activity` | Auto-hide di game/video lebih tepat |
| Force-stop / bersihkan app | `am force-stop`, `KILL_BACKGROUND_PROCESSES` | Tindakan cepat per-app |
| Baca log | `READ_LOGS` | Diagnostics & deteksi event notifikasi yang terlewat |


## FORMAT JAWABAN (WAJIB)
1. Mulai dengan tree file yang dibuat/diubah.
2. Tiap file diawali satu baris `// FILE: path/lengkap/Nama.ext` (untuk XML: `<!-- FILE: path -->`), diikuti isi file dalam satu code block.
3. Isi file LENGKAP. Dilarang memakai "...", placeholder, atau "bagian lain tetap sama". Hanya tulis file yang baru/berubah.
4. Jika jawaban akan terlalu panjang, berhenti di batas file yang rapi, tulis "BERSAMBUNG: file berikutnya = <daftar>", lalu tunggu saya mengirim "LANJUTKAN".
5. Setelah semua file: (a) cara build & install, (b) checklist tes manual beserta hasil yang diharapkan, (c) batasan/catatan OEM/Shizuku.
6. Setelah itu BERHENTI dan tunggu konfirmasi saya. Jangan mengerjakan fase berikutnya.

## CHECKLIST TES FASE INI
- [ ] Colok charger memunculkan kartu charging; level rendah memunculkan peringatan.
- [ ] Sambung earbuds memunculkan pop-up.
- [ ] Buka kamera/mic memunculkan titik privasi yang benar.
- [ ] Hotspot, mode suara, senter, volume menampilkan aktivitas yang sesuai.
- [ ] Semua aktivitas bisa dites lewat tombol Test.
- [ ] Pemakaian baterai wajar (tidak ada polling terus-menerus).
