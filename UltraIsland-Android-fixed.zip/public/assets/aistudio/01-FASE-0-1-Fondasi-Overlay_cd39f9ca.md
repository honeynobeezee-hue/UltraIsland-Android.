# FASE 0 + FASE 1: Fondasi project & Engine Overlay

Kerjakan HANYA Fase 0 dan Fase 1, versi MINIMAL agar pasti bisa dibuild.

## TUJUAN
Project Android yang build hijau, terpasang di HP, dan menampilkan pill hitam ala Dynamic Island di cutout kamera dengan animasi spring, plus layar Home untuk mengaktifkan dan mengetes.

## BATASAN VERSI MINIMAL (menimpa spesifikasi multi-modul untuk fase ini)
- SATU modul Gradle saja: `app`. Tanpa Hilt, tanpa Room, tanpa KSP/kapt. Pakai DataStore Preferences dan singleton/`object` sederhana.
- Tetap susun kode dalam package yang mengikuti rencana modul agar mudah dipecah nanti: `core.datastore`, `core.designsystem`, `engine.overlay`, `engine.render`, `engine.activity`, `engine.gesture`, `privileged`, `settings`.
- Dependency yang boleh: Compose (BOM), Material3, activity-compose, lifecycle-runtime-compose, datastore-preferences, kotlinx-coroutines-android, Shizuku api+provider (`dev.rikka.shizuku:api` dan `:provider`, versi 13.1.5).

## ATURAN BUILD (agar lolos GitHub Actions)
- Gradle 8.9, Android Gradle Plugin 8.6.1, Kotlin 2.0.20 + plugin `org.jetbrains.kotlin.plugin.compose`, Compose BOM 2024.09.00, JDK 17, compileSdk 35, targetSdk 35, minSdk 26.
- Jangan membuat gradle wrapper. Jangan memakai dependency/versi yang tidak pasti ada. Jika ragu soal versi, pilih versi stabil yang lebih lama.
- Semua file yang direferensikan (resource, XML accessibility config, ikon, string) HARUS ikut dibuat. Tidak boleh ada referensi ke file yang tidak ada.
- Package dasar: `com.ultraisland.pro`.
- Pertahankan kode yang sudah ada dari fase sebelumnya; ubah seminimal mungkin dan jangan merusak build yang sudah hijau.

## YANG HARUS DIBUAT
**Fase 0**
1. File Gradle: settings.gradle.kts, build.gradle.kts (root), app/build.gradle.kts, gradle.properties, libs.versions.toml (boleh), proguard-rules.pro.
2. AndroidManifest.xml lengkap: service Accessibility (`BIND_ACCESSIBILITY_SERVICE`) + xml config, MainActivity, ShizukuProvider, izin dasar.
3. Tema Compose gelap (Material 3), komponen dasar design system, `SettingsRepository` (DataStore) dengan key: island_enabled, width_dp, height_dp, offset_x, offset_y, corner_radius, anim_speed, haptic_enabled.
4. Navigasi sederhana: Home, Test, Permissions/Setup.
5. Modul `privileged`: interface `PrivilegedBridge` (exec, isAvailable, backendName), implementasi Shizuku (deteksi binder, request permission, exec lewat UserService/`Shizuku.newProcess` bila tersedia), serta fallback "manual". Halaman **Setup** menampilkan status backend, tombol "Auto Setup" (menjalankan perintah grant bila Shizuku aktif, dengan verifikasi hasil), dan daftar perintah ADB siap-salin (tombol Copy). ADB Wireless pairing ditunda ke Fase 7.

**Fase 1**
1. `IslandAccessibilityService` yang membuat overlay `TYPE_ACCESSIBILITY_OVERLAY` (ComposeView di WindowManager), touch hanya di area island, pass-through di luar.
2. Deteksi cutout (`DisplayCutout`, portrait & landscape) lalu posisi pill menempel di lubang kamera; mode floating bila tanpa cutout; nilai kalibrasi X/Y/lebar/tinggi/radius dari DataStore.
3. State machine: Hidden, Idle, Compact, Expanded. Tap pill = expand/collapse.
4. Animasi spring (lebar, tinggi, corner radius), konten fade+scale bertahap, haptic ringan.
5. Layar Test: tombol "Show demo activity" yang memunculkan aktivitas dummy (judul + ikon + warna) agar terlihat compact → expanded.
6. Live preview kecil di halaman Home dan slider untuk ukuran/posisi/radius/kecepatan yang langsung mengubah island.
7. Deteksi rotasi layar dan perubahan konfigurasi tanpa crash.

## SPESIFIKASI TERKAIT (acuan)
## 9. IZIN YANG DIPERLUKAN (jelaskan alasan tiap izin di UI)
`BIND_ACCESSIBILITY_SERVICE`, `BIND_NOTIFICATION_LISTENER_SERVICE`, `SYSTEM_ALERT_WINDOW`, `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE`, `POST_NOTIFICATIONS`, `RECEIVE_BOOT_COMPLETED`, `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`, `VIBRATE`, `SCHEDULE_EXACT_ALARM`, `SET_ALARM`, `BLUETOOTH` + `BLUETOOTH_CONNECT`, `ANSWER_PHONE_CALLS`, `READ_PHONE_STATE`, `READ_CALENDAR`, `ACCESS_COARSE/FINE_LOCATION` (cuaca, opsional), `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE`, `INTERNET` (opsional), `PACKAGE_USAGE_STATS`, `ACCESS_NOTIFICATION_POLICY`, `WRITE_SETTINGS`, `MODIFY_AUDIO_SETTINGS`, `RECORD_AUDIO` (visualizer, opsional), `DETECT_SCREEN_RECORDING`, `QUERY_ALL_PACKAGES`, `READ_MEDIA_IMAGES`, `RECEIVE_SENSITIVE_NOTIFICATIONS` (Android 15+), izin Shizuku API. Opsional via ADB: `WRITE_SECURE_SETTINGS`, `KILL_BACKGROUND_PROCESSES`.
Setiap izin sensitif: minta hanya saat fitur diaktifkan, dengan dialog penjelasan.

## 14. LAPISAN PRIVILEGED: SHIZUKU & ADB SHELL (WAJIB DIBANGUN)

Asumsi: pengguna bersedia memakai Shizuku atau ADB. Bangun `PrivilegedBridge` sebagai interface tunggal dengan 3 backend, dipilih otomatis berdasarkan ketersediaan:
1. **Shizuku** (utama): `ShizukuProvider`, minta permission via `Shizuku.requestPermission`, jalankan perintah lewat `UserService` (AIDL) agar berjalan sebagai shell UID (2000). Tangani event binder dead/received dan restart otomatis.
2. **ADB Wireless Debugging (on-device)**: pairing code + koneksi ke `adbd` lokal (tanpa PC), sebagai pengganti bila Shizuku tidak terpasang. Sediakan wizard langkah demi langkah dan deteksi status.
3. **ADB dari PC (sekali jalan)**: tampilkan perintah siap-salin dan tombol "Copy semua", plus QR/teks. Setelah izin diberikan, aplikasi bekerja tanpa PC.
4. **Fallback non-privileged**: cara manual lewat Settings.

Semua pemanggilan lewat `PrivilegedBridge.exec(command)` yang mengembalikan `Result<String>` (timeout, logging, tidak pernah crash). Sediakan halaman **Diagnostics > Privileged** yang menampilkan backend aktif, UID, dan hasil tes tiap kemampuan.

### 14.1 Perintah ADB sekali jalan (tampilkan di Onboarding, ganti `PKG` dengan package aplikasi)
```
adb shell pm grant PKG android.permission.WRITE_SECURE_SETTINGS
adb shell pm grant PKG android.permission.READ_LOGS
adb shell pm grant PKG android.permission.PACKAGE_USAGE_STATS
adb shell pm grant PKG android.permission.POST_NOTIFICATIONS
adb shell pm grant PKG android.permission.READ_CALENDAR
adb shell pm grant PKG android.permission.BLUETOOTH_CONNECT
adb shell pm grant PKG android.permission.ANSWER_PHONE_CALLS
adb shell pm grant PKG android.permission.READ_PHONE_STATE
adb shell pm grant PKG android.permission.RECORD_AUDIO
adb shell appops set PKG SYSTEM_ALERT_WINDOW allow
adb shell appops set PKG RUN_ANY_IN_BACKGROUND allow
adb shell appops set PKG RUN_IN_BACKGROUND allow
adb shell appops set PKG RECEIVE_SENSITIVE_NOTIFICATIONS allow
adb shell appops set PKG WRITE_SETTINGS allow
adb shell appops set PKG SCHEDULE_EXACT_ALARM allow
adb shell dumpsys deviceidle whitelist +PKG
adb shell cmd notification allow_listener PKG/.services.notification.IslandNotificationListener
adb shell settings put secure enabled_accessibility_services PKG/.services.accessibility.IslandAccessibilityService
adb shell settings put secure accessibility_enabled 1
```
Catatan wajib untuk implementasi:
- Saat menulis `enabled_accessibility_services`, GABUNGKAN dengan nilai yang sudah ada (pisahkan `:`), jangan menimpa service lain.
- Verifikasi setiap perintah (baca ulang nilai) dan tampilkan hasilnya di UI (centang hijau/merah).
- Beberapa perintah bisa ditolak di OEM tertentu (HyperOS/ColorOS butuh "USB debugging (Security settings)"); tampilkan pesan bantuan spesifik.
- Pada Android 13+ aplikasi sideload mungkin kena "Restricted settings"; sediakan solusi (izinkan lewat info aplikasi, atau ADB).

### 14.2 Otomatisasi setup (satu tombol "Auto Setup")
Jika Shizuku/ADB aktif: grant semua izin di atas, aktifkan Accessibility + Notification Listener, whitelist baterai, set appops, lalu verifikasi dan tampilkan laporan. Tanpa Shizuku/ADB: arahkan ke layar pengaturan yang tepat satu per satu dengan deteksi status otomatis.

## 5. GESTURE (semua bisa dipetakan ulang per konteks)
Tap, long-press, double-tap, swipe kiri/kanan/atas/bawah pada pill ter-collapse & pada kartu, drag (floating mode), tap di luar kartu untuk menutup. Aksi: expand, collapse, buka app, ganti aktivitas, dismiss, next/prev track, senter, screenshot, kunci layar, buka launcher, aksi kustom.

Untuk fase ini hanya tap dan long-press dasar yang diimplementasikan; gesture lengkap di Fase 6.

## FORMAT JAWABAN (WAJIB)
1. Mulai dengan tree file yang dibuat/diubah.
2. Tiap file diawali satu baris `// FILE: path/lengkap/Nama.ext` (untuk XML: `<!-- FILE: path -->`), diikuti isi file dalam satu code block.
3. Isi file LENGKAP. Dilarang memakai "...", placeholder, atau "bagian lain tetap sama". Hanya tulis file yang baru/berubah.
4. Jika jawaban akan terlalu panjang, berhenti di batas file yang rapi, tulis "BERSAMBUNG: file berikutnya = <daftar>", lalu tunggu saya mengirim "LANJUTKAN".
5. Setelah semua file: (a) cara build & install, (b) checklist tes manual beserta hasil yang diharapkan, (c) batasan/catatan OEM/Shizuku.
6. Setelah itu BERHENTI dan tunggu konfirmasi saya. Jangan mengerjakan fase berikutnya.

## CHECKLIST TES FASE INI (jelaskan juga di jawabanmu)
- [ ] Build hijau di GitHub Actions, APK terpasang.
- [ ] Setelah Accessibility diaktifkan, pill hitam muncul di area kamera.
- [ ] Tap pill: animasi spring mengembang lalu mengecil, tanpa patah-patah.
- [ ] Tombol Test menampilkan aktivitas demo.
- [ ] Slider ukuran/posisi/radius langsung mengubah island.
- [ ] Rotasi layar tidak membuat crash.
- [ ] Halaman Setup menunjukkan status Shizuku dan perintah ADB bisa disalin.
